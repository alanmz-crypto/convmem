"""convmem CLI (typer).

Usage:
  convmem "query"            search (raw summaries in Step 4)
  convmem "query" --raw      explicit fallback over conversation summaries
  convmem "query" --top 10   more results
  convmem "query" --domain web_stack.security   scope to a domain (+children)
  convmem "query" --site staging2.example.com   scope to a client site
  convmem "query" --open 1        search and open result #1 in source app
  convmem index              ingest all sources, skip unchanged
  convmem index --file PATH  force re-ingest one file
  convmem ask "question"           answer from retrieved memories
  convmem ask "question" --evidence     prefer unresolved ledger findings
  convmem ask -i                   interactive multi-turn session
  convmem ask -i "first question"  start interactive with one turn
  convmem open PATH               open a hit in its native chat app
  convmem add --file observations.jsonl   batch-ingest tool-sourced findings
  convmem add --file observations.jsonl --upsert   update by stable ledger id
  convmem add --title ... --summary ... --author MODEL   ingest one finding
  convmem verify UNIT_ID --model MODEL [--confidence 0.9]  cross-model check
  convmem related LEDGER_ID        show observation/decision/verification chain
  convmem exclude PATH --reason "noise"  mark a conversation as excluded
  convmem exclude --list             show excluded conversations
  convmem exclude --undo PATH        re-include a previously excluded file
  convmem watch                    watch transcript dirs → incremental index
  convmem refine                   background index refinement (F1)
  convmem refine --once --job JOB  run one refine job
  convmem monitor                  HTTP security probes (F2b)
  convmem brief                    shared context block for all agents
  convmem brief --print            stdout only (paste into ChatGPT sessions)
  convmem doctor                   health checks (v0); --v1 for watch/systemd/canary
  convmem tldr                     one-page cheat sheet (cwd-aware)
  convmem doctor --verify          also run scripts/verify-continue.sh
  convmem record -i                record a durable fact (interactive)
  convmem record --approve-last    approve newest pending + index (searchable)
  convmem propose_decision         same as record (legacy name)
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

import typer

from chroma_readonly import collection_count
from open_source import citation_open_meta, run_open

app = typer.Typer(add_completion=False, help="Search your past AI conversations.")

_SUBCOMMANDS = {
    "index", "stats", "search", "ask", "open", "add", "verify", "related",
    "watch", "refine", "monitor", "exclude", "forget", "brief", "doctor", "propose_decision", "record",
    "unresolved", "tldr", "work", "agent-run", "scope", "shadow-inventory", "shadow-activate",
    "shadow-rollback", "shadow-canary", "writer-census-start",
    "writer-census-status", "writer-census-report",
}
# Primary search is misleading until distillation backfill catches up to summaries.
_MIN_UNITS_FOR_PRIMARY = 50


def _unit_count() -> int:
    from config import load_config

    cfg = load_config()
    return collection_count(cfg["index"]["chroma_dir"], "knowledge_units")


def _primary_search_ready() -> bool:
    return _unit_count() >= _MIN_UNITS_FOR_PRIMARY


# Lightweight telemetry for delayed-index detection (ledger-approved, Chroma-failed).
_INDEX_FAIL_LOG = Path("~/.local/share/convmem/index_failures.jsonl").expanduser()


def _log_index_failure(proposal_id: str, error: Exception) -> None:
    """Append one JSONL line when approval succeeds but Chroma indexing fails. Never raises."""
    try:
        _INDEX_FAIL_LOG.parent.mkdir(parents=True, exist_ok=True)
        entry = {
            "ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "proposal_id": proposal_id,
            "error_type": type(error).__name__,
            "error": str(error)[:200],
        }
        with _INDEX_FAIL_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass  # Telemetry must never break record


def _guard_write() -> None:
    """Refuse prod/lab cross-lane writes unless CONVMEM_CONFIRM_* is set."""
    from config import load_config
    from query import render_error
    from runtime_guard import require_write_consent

    cfg = load_config()
    try:
        require_write_consent(cfg["index"]["chroma_dir"])
    except RuntimeError as exc:
        render_error(str(exc))
        raise typer.Exit(2) from exc


@app.command()
def search(  # pylint: disable=too-many-positional-arguments
    query: str = typer.Argument(..., help="What you're trying to recall"),
    raw: bool = typer.Option(False, "--raw", help="Search conversation summaries (fallback layer)"),
    top: int = typer.Option(5, "--top", min=1, max=100, help="Number of results"),
    domain: str | None = typer.Option(
        None, "--domain", help="Scope to a domain and its children, e.g. web_stack.security"
    ),
    site: str | None = typer.Option(
        None, "--site", help="Scope to a site hostname, e.g. staging2.willowyhollow.com"
    ),
    cross_domain: bool = typer.Option(
        False,
        "--cross-domain",
        help="Widen retrieval to all domains for this call only (non-sticky)",
    ),
    open_at: int | None = typer.Option(
        None, "--open", min=1, help="Open result # in its source chat app"
    ),
):
    """Search past conversations."""
    from query import query_raw, query_units, render_search_results, render_warning
    from read_scope import resolve_retrieval_domain

    effective_domain, _scope_meta = resolve_retrieval_domain(
        domain, cross_domain=cross_domain
    )

    if raw:
        results = query_raw(
            query, top_k=top, site=site, domain=effective_domain
        )
        render_search_results(results, units=False)
    else:
        if not _primary_search_ready():
            from config import load_config
            from serving_index_repository import open_serving_index_repository

            with open_serving_index_repository(load_config()) as repo:
                n, summary_n = repo.count_units(), repo.count_summaries()
            render_warning(
                f"Only {n} knowledge unit(s) vs {summary_n} summaries — "
                "primary search is thin. Use --raw until backfill completes, or:\n"
                "rm ~/.local/share/convmem/processed.json && convmem index"
            )
        results = query_units(
            query, top_k=top, domain=effective_domain, site=site
        )
        render_search_results(results, units=True)

    from next_steps import after_search

    after_search(query=query, site=site, n_results=len(results or []))

    if open_at and results:
        idx = open_at - 1
        if 0 <= idx < len(results):
            meta = results[idx].get("metadata", {})
            target = run_open(meta)
            if target.command:
                typer.echo(f"\n{target.format_line()}", err=True)
            elif target.hint:
                typer.echo(f"\n{target.format_line()}", err=True)
        else:
            from query import render_error

            render_error(f"No result #{open_at}.")


@app.command("open")
def open_hit(
    source_path: str = typer.Argument(..., help="source_path from a search/ask result"),
    at: int | None = typer.Option(
        None, "--at", help="Message offset (helps locate Kiro sessions)"
    ),
    tool: str | None = typer.Option(None, "--tool", help="Tool name from result metadata"),
):
    """Open a hit's source chat in the native app (Kiro, Cursor, etc.)."""
    meta = {
        "source_path": source_path,
        "start_offset": at,
        "tool": tool or "",
    }
    target = run_open(meta)
    typer.echo(target.format_line())
    if not target.command and target.hint:
        raise typer.Exit(0)


@app.command("ask")
def ask_command(  # pylint: disable=too-many-arguments
    question: str | None = typer.Argument(
        None, help="Question (omit with -i for interactive mode)"
    ),
    *,
    interactive: bool = typer.Option(
        False, "-i", "--interactive", help="Multi-turn session with follow-ups"
    ),
    raw: bool = typer.Option(False, "--raw", help="Retrieve from conversation summaries"),
    top: int = typer.Option(
        5, "--top", min=1, max=100, help="Number of excerpts to use as context"
    ),
    domain: str | None = typer.Option(
        None, "--domain", help="Scope to a domain and its children, e.g. web_stack.wordpress"
    ),
    site: str | None = typer.Option(
        None, "--site", help="Scope to a site hostname, e.g. staging2.willowyhollow.com"
    ),
    evidence: bool = typer.Option(
        False,
        "--evidence",
        help="Prefer unresolved observations and failed verifications (ledger graph)",
    ),
    show_trace: bool = typer.Option(
        False,
        "--trace",
        help="Print retrieval trace JSON (convmem.ask.trace.v1) on stderr",
    ),
    cross_domain: bool = typer.Option(
        False,
        "--cross-domain",
        help="Widen retrieval to all domains for this call only (non-sticky)",
    ),
    open_at: int | None = typer.Option(
        None, "--open", min=1, help="After answering, open source citation #"
    ),
):
    """Answer questions using retrieved memories from past sessions."""
    from ask import ask, run_interactive
    from query import render_ask_output, render_error

    if interactive:
        run_interactive(top_k=top, raw=raw, first_question=question, domain=domain, site=site, evidence=evidence)
        return
    if not question:
        render_error("Provide a question, or use -i for interactive mode.")
        raise typer.Exit(1)

    out = ask(
        question,
        top_k=top,
        raw=raw,
        domain=domain,
        site=site,
        evidence=evidence,
        trace=show_trace,
        cross_domain=cross_domain,
    )
    render_ask_output(out)
    if show_trace and out.get("trace") is not None:
        # Plain stderr JSON (no Rich markup/highlight) for machine parse.
        print(json.dumps(out["trace"], indent=2, default=str), file=sys.stderr)
    from next_steps import after_ask

    after_ask(
        question=question,
        site=site,
        n_citations=len(out.get("citations") or []),
        synthesis_failed=bool(out.get("synthesis_failed")),
        synthesis_interrupted=bool(out.get("synthesis_interrupted")),
    )
    if open_at and out.get("citations"):
        idx = open_at - 1
        if 0 <= idx < len(out["citations"]):
            c = out["citations"][idx]
            run_open(citation_open_meta(c))
        else:
            render_error(f"No citation #{open_at}.")


@app.command()
def index(
    file: str = typer.Option(None, "--file", help="Ingest a single file"),
    limit: int = typer.Option(None, "--limit", help="Max files to process (debug)"),
    force: bool = typer.Option(
        False,
        "--force",
        help="With --file: bypass path/hash skip and re-ingest (clears processed entry)",
    ),
    supersede: bool = typer.Option(
        False,
        "--supersede",
        help="With --file: tombstone prior units for this path instead of deleting",
    ),
):
    """Ingest all sources (skip unchanged), or one file (--file; add --force to re-ingest)."""
    _guard_write()
    from ingest import (
        ProviderUnavailableError,
        UnsupportedSourceError,
        index as run_index,
    )
    from query import render_error

    try:
        stats = run_index(
            force_file=file,
            limit_files=limit,
            force_reindex=force,
            supersede_on_reindex=supersede,
        )
    except UnsupportedSourceError as exc:
        render_error(str(exc))
        raise typer.Exit(1) from exc
    except ProviderUnavailableError as exc:
        render_error(
            f"{exc}\nCheck the provider balance/credential, then re-run. "
            "Nothing was marked processed, so the file re-indexes cleanly."
        )
        raise typer.Exit(1) from exc
    typer.echo("")
    typer.echo(
        f"Done. files_processed={stats['files_processed']} "
        f"files_skipped={stats['files_skipped']} "
        f"chunks_indexed={stats['chunks_indexed']} "
        f"units_indexed={stats.get('units_indexed', 0)}"
    )
    from next_steps import after_index

    after_index(
        files_processed=stats["files_processed"],
        units_indexed=stats.get("units_indexed", 0),
    )


@app.command()
def stats():
    """Show collection counts and source breakdown."""
    from config import load_config
    from query import render_stats, render_warning

    cfg = load_config()
    render_stats(cfg)

    if not _primary_search_ready():
        render_warning(
            "Primary search (--raw off) needs distillation backfill.\n"
            "Use --raw now, or: rm ~/.local/share/convmem/processed.json && convmem index"
        )


@app.command()
def add(
    file: str | None = typer.Option(
        None, "--file", help="JSONL file of observation records to batch-ingest"
    ),
    title: str | None = typer.Option(None, "--title", help="Short, specific title"),
    summary: str | None = typer.Option(None, "--summary", help="1-2 self-contained sentences"),
    keyword: list[str] = typer.Option(
        [], "--keyword", help="Repeatable; needs >=3 total, e.g. --keyword wp-rocket --keyword cache"
    ),
    domain: str = typer.Option(
        "general", "--domain", help="e.g. web_stack.wordpress.plugins, web_stack.security"
    ),
    author: str | None = typer.Option(
        None, "--author", help="Which model/tool produced this (required)"
    ),
    unit_type: str = typer.Option(
        "observation", "--type", help="observation | solution | decision | explanation | pattern"
    ),
    confidence: float = typer.Option(0.8, "--confidence"),
    tool: str = typer.Option("observation", "--tool", help="Tool name, e.g. openclaw"),
    severity: str | None = typer.Option(
        None,
        "--severity",
        help="critical | high | medium | low | info — P0s need critical/high "
        "to enter the exposure-window feed (doctor standing_register)",
    ),
    source_path: str | None = typer.Option(
        None, "--source-path", help="URL, log path, or 'runtime:checkout-page'"
    ),
    upsert: bool = typer.Option(
        False,
        "--upsert",
        help="Update existing units by ledger id (document + embedding + metadata)",
    ),
):
    """Write a tool/model-sourced finding directly into the index — no chat needed.

    This is the path for non-conversational sources: security scanners, log
    parsers, HTTP probes, OpenClaw browser sessions, etc. Either pass a
    single record via flags, or --file a JSONL batch (one record per line).
    """
    _guard_write()
    from chroma_write_store import production_chroma_write_session
    from observe import ingest_observation, ingest_observation_file
    from query import render_error
    from pathlib import Path

    if upsert:
        from restic_gate import ensure_chroma_snapshot_for_live_write

        ensure_chroma_snapshot_for_live_write()

    with production_chroma_write_session(entrypoint="convmem.add") as session:
        store = session.store
        cfg = session.live_cfg
        models = cfg["models"]
        units_export = cfg["index"].get("units_export")
        units_export_path = Path(units_export).expanduser() if units_export else None

        if file:
            result = ingest_observation_file(
                file,
                store=store,
                embed_model=models["embed_model"],
                ollama_host=models["ollama_host"],
                units_export=units_export_path,
                upsert=upsert,
            )
            parts = [
                f"accepted={result['accepted']}",
                f"rejected={result['rejected']}",
            ]
            if upsert:
                parts.append(f"updated={result['updated']}")
            typer.echo(f"\nDone. {' '.join(parts)}")
            return

        if not title or not summary or not author:
            render_error(
                "Provide --title, --summary, and --author (or use --file for batch ingest)."
            )
            raise typer.Exit(1)
        if len(keyword) < 3:
            render_error("Need at least 3 --keyword values.")
            raise typer.Exit(1)
        if severity is not None:
            from ledger import _SEVERITIES

            severity = severity.strip().lower()
            if severity not in _SEVERITIES:
                render_error(
                    "--severity must be one of: " + ", ".join(sorted(_SEVERITIES)) + "."
                )
                raise typer.Exit(1)

        record = {
            "title": title,
            "summary": summary,
            "keywords": keyword,
            "type": unit_type,
            "domain": domain,
            "author_model": author,
            "confidence": confidence,
            "tool": tool,
            "source_path": source_path,
            "severity": severity,
        }
        unit = ingest_observation(
            record,
            store=store,
            embed_model=models["embed_model"],
            ollama_host=models["ollama_host"],
            units_export=units_export_path,
        )
        if unit is None:
            render_error("Record rejected — check required fields.")
            raise typer.Exit(1)
        typer.echo(
            f"Added [{unit['domain']}] {unit['title']}  "
            f"(ledger: {unit.get('ledger_id', unit['id'])})"
        )


@app.command("verify")
def verify_command(
    unit_id: str = typer.Argument(
        ..., help="Chroma unit id or ledger id (e.g. obs_20260617_001)"
    ),
    model: str = typer.Option(..., "--model", help="Verifying model/tool name"),
    confidence: float | None = typer.Option(
        None, "--confidence", help="Verifier's confidence; defaults to the existing value"
    ),
    notes: str | None = typer.Option(
        None, "--notes", help="Verification notes (also used as ledger summary)"
    ),
    result: str = typer.Option(
        "pass", "--result", help="pass | fail — outcome of the verification check"
    ),
    no_record: bool = typer.Option(
        False, "--no-record", help="Only update metadata; skip verification ledger ingest"
    ),
    emit_file: str | None = typer.Option(
        None,
        "--emit-file",
        help="Append verification JSONL to this path (in addition to ingest)",
    ),
):
    """Record a verifier's check on an existing observation (metadata + ledger record)."""
    _guard_write()
    import json
    from pathlib import Path

    from chroma_write_store import production_chroma_write_session
    from query import render_error
    from verify import verify_unit

    with production_chroma_write_session(entrypoint="convmem.verify") as session:
        store = session.store
        cfg = session.live_cfg
        models = cfg["models"]
        units_export = cfg["index"].get("units_export")
        units_export_path = Path(units_export).expanduser() if units_export else None

        meta = verify_unit(
            store,
            unit_id,
            verifier_model=model,
            confidence=confidence,
            notes=notes,
            result=result,
            record_ledger=not no_record,
            embed_model=models["embed_model"],
            ollama_host=models["ollama_host"],
            units_export=units_export_path,
        )
    if meta is None:
        render_error(f"No unit found with id {unit_id}.")
        raise typer.Exit(1)

    if emit_file:
        relates_to = meta.get("ledger_id") or unit_id
        record = {
            "id": f"ver_{relates_to}",
            "kind": "verification",
            "author_model": model,
            "relates_to": relates_to,
            "result": result,
            "summary": notes or f"Verified {meta.get('title', relates_to)}: {result}",
            "notes": notes or "",
            "domain": meta.get("domain") or "web_stack.security",
            "site": meta.get("site") or "",
            "timestamp": meta.get("verified_at"),
        }
        path = Path(emit_file).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
        typer.echo(f"Appended verification → {path}")

    typer.echo(
        f"Verified '{meta.get('title', unit_id)}' — "
        f"ledger={meta.get('ledger_id') or unit_id} "
        f"verifier={model} result={result} confidence={meta.get('verified_confidence')}"
    )


@app.command()
def watch(
    debounce: float | None = typer.Option(
        None, "--debounce", help="Seconds after last write before indexing (default from config)"
    ),
    path: list[str] = typer.Option(
        [],
        "--path",
        help="Watch roots only (repeatable); replaces [sources]/[watch] paths when set",
    ),
    no_lock: bool = typer.Option(False, "--no-lock", help="Skip PID lock (debug only)"),
):
    """Watch transcript paths and run incremental index when files change."""
    _guard_write()
    from watch import run_watch

    extra = path if path else None
    run_watch(
        debounce_seconds=debounce,
        paths=extra,
        use_lock=not no_lock,
        verbose=True,
    )


@app.command()
def refine(
    once: bool = typer.Option(False, "--once", help="Run one job batch and exit"),
    job: str | None = typer.Option(None, "--job", help=f"Job name: {', '.join(__import__('refine').JOB_NAMES)}"),
    limit: int | None = typer.Option(None, "--limit", help="Max items per job run"),
    stats_only: bool = typer.Option(False, "--stats", help="Print refine_stats.json and exit"),
    approve_dedupe: str | None = typer.Option(
        None,
        "--approve-dedupe",
        help="Apply approved dedupe_queue row (1-based line) or 'all'",
    ),
    no_lock: bool = typer.Option(False, "--no-lock", help="Skip PID lock (daemon only)"),
):
    """Background index refinement — dedupe, domain backfill, audit queue (F1)."""
    if not stats_only:
        _guard_write()
    from refine import (
        JOB_NAMES,
        apply_approved_dedupe,
        print_stats,
        run_job,
        run_refine_daemon,
    )

    if approve_dedupe is not None:
        try:
            result = apply_approved_dedupe(approve_dedupe, verbose=True)
        except ValueError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(1) from exc
        typer.echo(json.dumps(result, indent=2))
        return
    if stats_only:
        print_stats()
        return
    if once:
        if not job:
            typer.echo(f"--once requires --job. Choices: {', '.join(JOB_NAMES)}")
            raise typer.Exit(1)
        result = run_job(job, limit=limit, verbose=True)
        typer.echo(json.dumps(result, indent=2))
        return
    run_refine_daemon(verbose=True, use_lock=not no_lock)


@app.command("monitor")
def monitor_command(
    site: str = typer.Option(
        "staging2.willowyhollow.com",
        "--site",
        help="Hostname to probe (default: staging2)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Run probes and print actions without writing to the ledger",
    ),
):
    """HTTP security probes — observations or advisory verifications (F2b)."""
    if not dry_run:
        _guard_write()
    import json
    from pathlib import Path

    from config import load_config
    from chroma_write_store import production_chroma_write_session
    from chroma_store import ChromaStore
    from monitor import run_monitor

    if dry_run:
        cfg = load_config()
        models = cfg["models"]
        units_export = cfg["index"].get("units_export")
        units_export_path = Path(units_export).expanduser() if units_export else None
        store = ChromaStore(str(cfg["index"]["chroma_dir"]), mutation_sink=None)
        try:
            stats = run_monitor(
                store,
                site=site,
                embed_model=models["embed_model"],
                ollama_host=models["ollama_host"],
                units_export=units_export_path,
                dry_run=True,
                verbose=True,
            )
        finally:
            store.close()
        typer.echo(json.dumps(stats, indent=2))
        return

    with production_chroma_write_session(entrypoint="convmem.monitor") as session:
        store = session.store
        cfg = session.live_cfg
        models = cfg["models"]
        units_export = cfg["index"].get("units_export")
        units_export_path = Path(units_export).expanduser() if units_export else None
        stats = run_monitor(
            store,
            site=site,
            embed_model=models["embed_model"],
            ollama_host=models["ollama_host"],
            units_export=units_export_path,
            dry_run=False,
            verbose=True,
        )
    typer.echo(json.dumps(stats, indent=2))
    from brief import refresh_brief_after_change

    refresh_brief_after_change(cfg)


@app.command()
def tldr(
    lane: str | None = typer.Option(
        None,
        "--lane",
        help="Force lane: willowyhollow-practice | convmem (default: infer from cwd)",
    ),
    list_lanes: bool = typer.Option(False, "--list", help="List available TLDR lanes"),
):
    """Print a one-page cheat sheet for the current workspace (or --lane)."""
    from query import render_error
    from tldr import list_lanes as lanes, read_tldr, resolve_tldr_path

    if list_lanes:
        typer.echo("TLDR lanes:")
        for name in lanes():
            path = resolve_tldr_path(lane=name)
            typer.echo(f"  {name}  →  {path}")
        return

    try:
        path = resolve_tldr_path(lane=lane)
        text = read_tldr(lane=lane)
    except FileNotFoundError as exc:
        render_error(str(exc))
        raise typer.Exit(1) from exc

    typer.echo(text.rstrip())
    typer.echo("")
    typer.echo(f"(from {path})")
    from next_steps import emit_next_steps

    ctx_lane = lane or __import__("next_steps").workspace_context().get("lane", "")
    if "willowyhollow" in str(ctx_lane):
        emit_next_steps(
            [
                "Session loop: ~/Projects/convmem/docs/WILLOWYHOLLOW-SESSION-LOOP.md",
                "Full: ~/Projects/convmem/docs/WILLOWYHOLLOW-WEBDEV-GUIDE.md",
                "convmem brief --stdout-only",
            ]
        )
    else:
        emit_next_steps(
            [
                "Full: ~/Projects/convmem/docs/MODEL-WORKFLOW.md",
                "convmem brief --stdout-only",
            ]
        )


@app.command()
def brief(
    print_: bool = typer.Option(False, "--print", help="Also print brief to stdout"),
    out: str | None = typer.Option(None, "--out", help="Output path (default ~/.local/share/convmem/brief.md)"),
    with_tests: bool = typer.Option(False, "--with-tests", help="Run unit tests and include count in brief"),
    stdout_only: bool = typer.Option(False, "--stdout-only", help="Print only; do not write brief.md"),
):
    """Generate a read-only shared context block for multi-agent sessions."""
    from config import load_config
    from brief import gather_brief_data, render_brief_markdown, write_brief

    cfg = load_config()
    data = gather_brief_data(cfg, with_tests=with_tests)
    text = render_brief_markdown(data)

    if stdout_only:
        typer.echo(text)
        from next_steps import after_brief

        stale = (data.get("handoff_staleness") or {}).get("stale", False)
        after_brief(
            unresolved_count=int(data.get("unresolved_count") or 0),
            stale_handoff=bool(stale),
        )
        return

    path = write_brief(cfg, out_path=out, with_tests=with_tests, quiet=True)
    if print_:
        typer.echo(text)
    typer.echo(f"Written → {path}")
    from next_steps import after_brief

    stale = (data.get("handoff_staleness") or {}).get("stale", False)
    after_brief(
        unresolved_count=int(data.get("unresolved_count") or 0),
        stale_handoff=bool(stale),
    )


@app.command()
def doctor(
    v1: bool = typer.Option(False, "--v1", help="Include watch RSS, systemd, and lock checks"),
    verify: bool = typer.Option(False, "--verify", help="Run scripts/verify-continue.sh smoke test"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON instead of text"),
):
    """Health checks (v0=core; --v1 adds watch/systemd/canary/locks; exit 0 = PASS)."""
    import json

    from doctor import doctor_exit_code, doctor_payload, render_doctor_text, run_doctor

    try:
        checks = run_doctor(v1=v1, run_verify=verify)
    except FileNotFoundError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc

    if json_out:
        typer.echo(json.dumps(doctor_payload(checks), indent=2))
    else:
        typer.echo(render_doctor_text(checks))
        from next_steps import after_doctor

        after_doctor(passed=doctor_exit_code(checks) == 0, v1=v1)
    raise typer.Exit(doctor_exit_code(checks))


work_app = typer.Typer(help="Always-GitHub-Fallback: start/resume task branches.")
app.add_typer(work_app, name="work")

scope_app = typer.Typer(help="Session read-scope default for retrieval (read-only).")
app.add_typer(scope_app, name="scope")


@scope_app.command("set")
def scope_set_command(
    domain: str = typer.Argument(..., help="Domain for this session's default retrieval scope"),
):
    """Set session read-scope default (e.g. relocation)."""
    from read_scope import set_read_scope

    normalized = set_read_scope(domain)
    typer.echo(f"Session read scope set to: {normalized}")


@scope_app.command("clear")
def scope_clear_command():
    """Clear session read-scope default."""
    from read_scope import clear_read_scope

    clear_read_scope()
    typer.echo("Session read scope cleared.")


@scope_app.command("show")
def scope_show_command():
    """Show active session read-scope default, if any."""
    from read_scope import get_read_scope

    active = get_read_scope()
    if active:
        typer.echo(active)
    else:
        typer.echo("(none)")


@work_app.command("start")
def work_start_cmd(
    kind: str = typer.Argument(..., help="feat|fix|docs|plan|wip"),
    slug: str = typer.Argument(..., help="short-slug (no spaces)"),
    worktree: bool = typer.Option(
        False,
        "--worktree",
        help="Create under ~/.local/share/convmem/worktrees/ instead of switching shared checkout",
    ),
):
    """Create task branch from origin/main and push with explicit refspec (fail closed)."""
    from work_git import WorkError, work_start

    try:
        branch = work_start(kind, slug, worktree=worktree)
    except WorkError as exc:
        typer.echo(f"work start failed: {exc}", err=True)
        raise typer.Exit(1) from exc
    typer.echo(f"Started and pushed {branch}. Edit only on this branch; push every commit.")


@work_app.command("resume")
def work_resume_cmd(
    branch: str = typer.Argument(..., help="feat|fix|docs|plan|wip/YYYY-MM-DD-slug"),
    worktree: bool = typer.Option(
        False,
        "--worktree",
        help="Attach a dedicated worktree instead of switching shared checkout",
    ),
):
    """Resume an existing pushed task branch (origin-only safe); fail closed."""
    from work_git import WorkError, work_resume

    try:
        name = work_resume(branch, worktree=worktree)
    except WorkError as exc:
        typer.echo(f"work resume failed: {exc}", err=True)
        raise typer.Exit(1) from exc
    typer.echo(f"Resumed {name}. Push every commit; do not merge main.")



agent_run_app = typer.Typer(help="Agent run identity ledger (Arc Runway Ledger).")
app.add_typer(agent_run_app, name="agent-run")


def _agent_run_ledger_from_opts(data_dir: Path | None):
    from agent_run_ledger import AgentRunLedger

    return AgentRunLedger(data_dir=data_dir) if data_dir is not None else AgentRunLedger()


def _emit_agent_run(payload: dict, *, json_mode: bool) -> None:
    if json_mode:
        typer.echo(json.dumps(payload, sort_keys=True))
    else:
        for key in sorted(payload):
            typer.echo(f"{key}: {payload[key]}")


@agent_run_app.command("start")
def agent_run_start_cmd(  # pylint: disable=too-many-arguments,too-many-positional-arguments
    client: str = typer.Option(..., "--client", help="kiro|codex|cursor|crush|copilot|..."),
    native_session_id: str | None = typer.Option(None, "--native-session-id"),
    cwd: Path | None = typer.Option(None, "--cwd", help="Working directory for Git facts"),
    source_kind: str = typer.Option("cli", "--source-kind"),
    source_ref: str = typer.Option("agent-run start", "--source-ref"),
    event_id: str | None = typer.Option(None, "--event-id"),
    data_dir: Path | None = typer.Option(None, "--data-dir"),
    json_out: bool = typer.Option(False, "--json", help="Machine-readable JSON"),
    no_git: bool = typer.Option(False, "--no-git"),
):
    """Append run_started; returns run_id after durable append."""
    from agent_run_ledger import AgentRunLedgerError, start_run

    ledger = _agent_run_ledger_from_opts(data_dir)
    try:
        payload = start_run(
            ledger,
            client=client,
            native_session_id=native_session_id,
            source_kind=source_kind,
            source_ref=source_ref,
            cwd=cwd,
            event_id=event_id,
            collect_git=not no_git,
        )
    except AgentRunLedgerError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    _emit_agent_run(payload, json_mode=json_out)


@agent_run_app.command("stop")
def agent_run_stop_cmd(  # pylint: disable=too-many-arguments,too-many-positional-arguments
    client: str = typer.Option(..., "--client"),
    status: str = typer.Option("completed", "--status", help="completed|aborted|unknown"),
    run_id: str | None = typer.Option(None, "--run-id"),
    native_session_id: str | None = typer.Option(None, "--native-session-id"),
    repository: str | None = typer.Option(None, "--repository"),
    cwd: Path | None = typer.Option(None, "--cwd"),
    source_kind: str = typer.Option("cli", "--source-kind"),
    source_ref: str = typer.Option("agent-run stop", "--source-ref"),
    event_id: str | None = typer.Option(None, "--event-id"),
    data_dir: Path | None = typer.Option(None, "--data-dir"),
    json_out: bool = typer.Option(False, "--json"),
    no_git: bool = typer.Option(False, "--no-git"),
):
    """Append run_stopped for an exact run_id or unique identity match."""
    from agent_run_ledger import (
        AgentRunLedgerError,
        AmbiguityError,
        NotFoundError,
        stop_run,
    )

    ledger = _agent_run_ledger_from_opts(data_dir)
    try:
        payload = stop_run(
            ledger,
            client=client,
            status=status,
            source_kind=source_kind,
            source_ref=source_ref,
            run_id=run_id,
            native_session_id=native_session_id,
            repository=repository,
            cwd=cwd,
            event_id=event_id,
            collect_git=not no_git,
        )
    except AmbiguityError as exc:
        _emit_agent_run(
            {"error": "ambiguous", "detail": str(exc)},
            json_mode=bool(json_out),
        )
        raise typer.Exit(2) from exc
    except NotFoundError as exc:
        _emit_agent_run(
            {"error": "not_found", "detail": str(exc)},
            json_mode=bool(json_out),
        )
        raise typer.Exit(2) from exc
    except AgentRunLedgerError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    _emit_agent_run(payload, json_mode=json_out)


@agent_run_app.command("enrich")
def agent_run_enrich_cmd(  # pylint: disable=too-many-arguments,too-many-positional-arguments
    run_id: str = typer.Option(..., "--run-id"),
    client: str = typer.Option(..., "--client"),
    commits: list[str] = typer.Option([], "--commits", help="40-hex SHAs (explicit)"),
    files: list[str] = typer.Option([], "--files", help="Repo-relative paths (explicit)"),
    ledger_ids: list[str] = typer.Option([], "--ledger-id", help="obs_/dec_/ver_ ids"),
    source_kind: str = typer.Option("cli", "--source-kind"),
    source_ref: str = typer.Option("agent-run enrich", "--source-ref"),
    data_dir: Path | None = typer.Option(None, "--data-dir"),
    json_out: bool = typer.Option(False, "--json"),
):
    """Append explicit enrichment facts for a run."""
    from agent_run_ledger import AgentRunLedgerError, NotFoundError, enrich_run

    facts = {
        "commits": [
            {"sha": sha, "relation": "explicit", "source": "caller"} for sha in commits
        ],
        "files": [
            {
                "path": path,
                "relation": "explicit",
                "source": "caller",
                "change": "unknown",
            }
            for path in files
        ],
        "ledger_records": [
            {"ledger_id": lid, "relation": "explicit", "source": "caller"}
            for lid in ledger_ids
        ],
    }
    ledger = _agent_run_ledger_from_opts(data_dir)
    try:
        payload = enrich_run(
            ledger,
            run_id=run_id,
            client=client,
            source_kind=source_kind,
            source_ref=source_ref,
            facts=facts,
        )
    except NotFoundError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(2) from exc
    except AgentRunLedgerError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    _emit_agent_run(payload, json_mode=json_out)


@agent_run_app.command("show")
def agent_run_show_cmd(
    run_id: str = typer.Argument(...),
    data_dir: Path | None = typer.Option(None, "--data-dir"),
    json_out: bool = typer.Option(True, "--json/--human", help="JSON by default"),
):
    """Show reduced run state."""
    ledger = _agent_run_ledger_from_opts(data_dir)
    reduced = ledger.load()
    view = reduced.runs.get(run_id)
    if view is None:
        typer.echo(f"unknown run_id: {run_id}", err=True)
        raise typer.Exit(2)
    payload = view.to_dict()
    if not payload["terminal_evidence"]:
        payload["note"] = "no terminal evidence recorded"
    _emit_agent_run(payload, json_mode=json_out)


@agent_run_app.command("list")
def agent_run_list_cmd(
    data_dir: Path | None = typer.Option(None, "--data-dir"),
    status: str | None = typer.Option(None, "--status"),
    json_out: bool = typer.Option(True, "--json/--human"),
):
    """List reduced runs."""
    ledger = _agent_run_ledger_from_opts(data_dir)
    reduced = ledger.load()
    rows = []
    for view in reduced.runs.values():
        if status and view.status != status:
            continue
        rows.append(
            {
                "run_id": view.run_id,
                "client": view.client,
                "native_session_id": view.native_session_id,
                "status": view.status,
                "identity_completeness": view.identity_completeness,
                "terminal_evidence": view.terminal_evidence,
            }
        )
    payload = {"runs": rows, "diagnostics": len(reduced.diagnostics)}
    _emit_agent_run(payload, json_mode=json_out)


@agent_run_app.command("validate")
def agent_run_validate_cmd(
    data_dir: Path | None = typer.Option(None, "--data-dir"),
    json_out: bool = typer.Option(True, "--json/--human"),
):
    """Validate the event log without repairing it."""
    ledger = _agent_run_ledger_from_opts(data_dir)
    report = ledger.validate()
    _emit_agent_run(report, json_mode=json_out)
    if not report.get("ok", False):
        raise typer.Exit(1)

def _resolve_approve_signer(signer: str | None) -> str:
    return (signer or os.environ.get("CONVMEM_SIGNER") or "ryan").strip()


def _finish_record_messages(
    proposal: dict,
    ledger: dict,
    *,
    indexed: bool,
    ingest: dict | None = None,
    approved_file: str | None = None,
) -> None:
    summary = (proposal.get("summary") or "").strip()
    lid = ledger.get("id", proposal.get("id", "?"))
    site = (proposal.get("site") or "").strip()
    q = summary[:72] if summary else lid
    if site:
        q = f"{site} {q}"[:80]
    typer.echo(f"✓ Recorded: {summary or lid}")
    typer.echo(f"  Ledger id: {lid}")
    if indexed:
        if ingest:
            typer.echo(
                f"  Indexed (accepted={ingest.get('accepted', 0)}, "
                f"updated={ingest.get('updated', 0)}, "
                f"skipped={ingest.get('skipped', 0)})"
            )
        else:
            typer.echo("  Indexed — searchable via convmem search / MCP ask.")
    elif approved_file:
        typer.echo(
            f"  Skipped index (--no-index). Run: convmem add --file {approved_file} --upsert"
        )
    typer.echo(f'  Try: convmem search "{q}"')
    from next_steps import after_record_approved

    after_record_approved(summary=summary, ledger_id=lid, site=site)


def _pending_record_hint() -> None:
    from next_steps import after_record_pending

    typer.echo("  Finish recording: convmem record --approve-last")
    after_record_pending()


@app.command("propose_decision")
def propose_decision_command(
    list_: bool = typer.Option(False, "--list", help="Show pending drafts"),
    all_: bool = typer.Option(False, "--all", help="With --list: include approved/rejected"),
    json_out: bool = typer.Option(False, "--json", help="With --list: emit raw JSONL records"),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        "-i",
        help="Record a fact interactively (prompts for each field)",
    ),
    approve: str | None = typer.Option(None, "--approve", help="Approve a specific draft id"),
    approve_last: bool = typer.Option(
        False,
        "--approve-last",
        help="Approve the newest pending draft (no id to remember)",
    ),
    no_index: bool = typer.Option(
        False,
        "--no-index",
        help="On approve: skip auto-index (default indexes into search)",
    ),
    reject: str | None = typer.Option(None, "--reject", help="Reject a draft id"),
    signer: str | None = typer.Option(
        None,
        "--signer",
        help="Signer on approve/reject (default on approve: ryan or CONVMEM_SIGNER)",
    ),
    reason: str | None = typer.Option(None, "--reason", help="Required for --reject"),
    recover: str | None = typer.Option(
        None,
        "--recover",
        help="Reconcile APPROVAL_STARTED proposal (no blind retry)",
    ),
    rebase: str | None = typer.Option(
        None,
        "--rebase",
        help="Gate 9: supersede stale proposal with a new id + fresh base hash",
    ),
    ledger_id: str | None = typer.Option(
        None, "--ledger-id", help="Canonical ledger id on approve (default: proposal id)"
    ),
    parse_doc: str | None = typer.Option(
        None, "--parse-doc", help="Scan inter-model doc for DECISION PROPOSED blocks (v2)"
    ),
    relates_to: str | None = typer.Option(None, "--relates-to", help="Parent observation/decision id"),
    summary: str | None = typer.Option(None, "--summary", help="One-sentence choice"),
    rationale: str | None = typer.Option(None, "--rationale", help="Why this choice"),
    author: str | None = typer.Option(None, "--author", help="Proposing model or human id"),
    alternative: list[str] | None = typer.Option(
        None, "--alternative", help="Rejected alternative (repeatable)"
    ),
    alternatives_rejected: list[str] | None = typer.Option(
        None, "--alternatives-rejected", help="Rejected alternative (repeatable)"
    ),
    constraint: list[str] | None = typer.Option(
        None,
        "--constraint",
        help="Hard constraint (repeatable); exact 'none-identified' sentinel allowed",
    ),
    constraints: list[str] | None = typer.Option(
        None, "--constraints", help="Hard constraint (repeatable)"
    ),
    domain: str = typer.Option("coding.tooling", "--domain", help="Domain tag"),
    site: str = typer.Option("", "--site", help="Site tag (optional)"),
    confidence: float = typer.Option(0.8, "--confidence", help="Confidence 0–1"),
    proposal_id: str | None = typer.Option(None, "--id", help="Explicit proposal id"),
):
    """Record a durable fact (alias: `convmem record`).

    Draft: `record -i` or flags. Finish: `record --approve-last` (indexes automatically).
    """
    from config import load_config
    from propose_decision import (
        InteractiveLockError,
        approve as do_approve,
        approve_and_ingest,
        approved_path,
        collect_interactive_fields,
        confirm_interactive_submit,
        format_proposal_review,
        ingest_approved_ledger,
        mark_approved,
        interactive_session_lock,
        latest_pending,
        list_proposals,
        pending_proposal_for_review,
        propose as do_propose,
        recover_approval,
        rebase_proposal,
        reject as do_reject,
    )
    from query import render_error

    if parse_doc:
        render_error("--parse-doc is not yet implemented (reserved for v2)")
        raise typer.Exit(1)

    if approve and approve_last:
        render_error("Use --approve or --approve-last, not both")
        raise typer.Exit(1)

    cfg = load_config()

    if list_:
        rows = list_proposals(cfg, show_all=all_)
        if json_out:
            for row in rows:
                typer.echo(json.dumps(row, ensure_ascii=False))
            return
        if not rows:
            typer.echo(
                "No pending drafts." if not all_ else "No drafts."
            )
            if not all_:
                typer.echo("  Start one: convmem record -i")
            return
        typer.echo(f"{'PENDING' if not all_ else 'ALL'} ({len(rows)})")
        if all_:
            # Compact history view (preserves rejection_reason; avoids card sprawl).
            for row in rows:
                pid = row.get("id", "?")
                status = row.get("status", "PENDING")
                site_s = row.get("site") or "(no site)"
                typer.echo(f"  {pid}  [{status}]  {site_s}  {row.get('domain', '')}")
                typer.echo(f"    {row.get('summary', '')}")
                typer.echo(
                    f"    proposed by {row.get('proposed_by', '?')} · "
                    f"relates_to {row.get('relates_to', '?')} · {row.get('proposed_at', '?')}"
                )
                if row.get("rejection_reason"):
                    typer.echo(f"    rejected: {row['rejection_reason']}")
        else:
            for i, row in enumerate(rows):
                if i:
                    typer.echo("")
                typer.echo(format_proposal_review(row))
            typer.echo("")
            typer.echo("  Finish newest: convmem record --approve-last")
        return

    # Plain-Python callers (e.g. record → propose_decision) may leave Typer
    # Option defaults as OptionInfo; only real strings activate these paths.
    if isinstance(recover, str) and recover:
        _guard_write()
        try:
            action = recover_approval(cfg, recover)
        except ValueError as e:
            render_error(str(e))
            raise typer.Exit(1) from e
        except Exception as e:
            _log_index_failure(recover, e)
            typer.echo(f"\n⚠ Recovery deferred for review: {e}")
            raise typer.Exit(1) from e
        typer.echo(f"Recovered {recover}: {action}")
        return

    if isinstance(rebase, str) and rebase:
        _guard_write()
        try:
            draft = rebase_proposal(cfg, rebase, author=author)
        except ValueError as e:
            render_error(str(e))
            raise typer.Exit(1) from e
        typer.echo(f"Rebased {rebase} → {draft['id']}")
        typer.echo(f"  target={draft.get('target_ledger_id')} base={str(draft.get('base_content_hash') or '')[:12]}")
        return

    approve_id = approve
    if approve_last:
        pending = latest_pending(cfg)
        if pending is None:
            render_error("No pending drafts to approve. Record one with: convmem record -i")
            raise typer.Exit(1)
        approve_id = pending["id"]

    if approve_id:
        try:
            preview = pending_proposal_for_review(cfg, approve_id)
        except ValueError as e:
            render_error(str(e))
            raise typer.Exit(1) from e
        typer.echo(format_proposal_review(preview))
        try:
            confirmed = typer.confirm("Approve this draft?", default=False)
        except typer.Abort:
            typer.echo("Cancelled — draft not approved.")
            raise typer.Exit(1)
        if not confirmed:
            typer.echo("Cancelled — draft not approved.")
            raise typer.Exit(1)
        # Confirm before any restic / ledger / Chroma write (fail closed).
        _guard_write()
        resolved_signer = _resolve_approve_signer(signer)
        ingest_result = None
        try:
            if no_index:
                proposal, ledger = do_approve(cfg, approve_id, signer=resolved_signer, ledger_id=ledger_id)
            else:
                from restic_gate import ensure_chroma_snapshot_for_live_write
                ensure_chroma_snapshot_for_live_write()
                proposal, ledger, ingest_result = approve_and_ingest(cfg, approve_id, signer=resolved_signer, ledger_id=ledger_id)
        except ValueError as e:
            render_error(str(e))
            raise typer.Exit(1) from e
        except Exception as e:
            _log_index_failure(approve_id, e)
            typer.echo(f"\n⚠ Approval apply deferred for recovery: {e}")
            raise typer.Exit(1) from e
        apath = str(approved_path(cfg))
        _finish_record_messages(
            proposal,
            ledger,
            indexed=not no_index,
            ingest=ingest_result,
            approved_file=apath if no_index else None,
        )
        return

    _guard_write()

    if reject:
        if not signer:
            render_error("--signer is required with --reject")
            raise typer.Exit(1)
        try:
            proposal = do_reject(cfg, reject, signer=signer, reason=reason or "")
        except ValueError as e:
            render_error(str(e))
            raise typer.Exit(1) from e
        typer.echo(f"Rejected: {proposal['id']}")
        typer.echo(f"  Reason: {proposal.get('rejection_reason', '')}")
        return

    alts = list(alternative or []) + list(alternatives_rejected or [])
    cons = list(constraint or []) + list(constraints or [])

    if interactive:
        try:
            with interactive_session_lock(cfg):
                fields = collect_interactive_fields(
                    relates_to=relates_to or "",
                    summary=summary or "",
                    rationale=rationale or "",
                    author=author or "",
                    domain=domain,
                    site=site,
                    constraints=cons,
                    prompt=typer.prompt,
                )
                relates_to = fields["relates_to"]
                summary = fields["summary"]
                rationale = fields["rationale"]
                author = fields["author"]
                domain = fields["domain"]
                site = fields["site"]
                cons = fields["constraints"]
                if not relates_to or not summary or not rationale or not author:
                    render_error("Interactive propose requires all core fields")
                    raise typer.Exit(1)
                if not confirm_interactive_submit(
                    cfg,
                    fields,
                    confirm=typer.confirm,
                    echo=typer.echo,
                ):
                    typer.echo("Cancelled — proposal not submitted.")
                    raise typer.Exit(0)
                rec = do_propose(
                    cfg,
                    relates_to=relates_to,
                    summary=summary,
                    rationale=rationale,
                    author=author,
                    alternatives=alts,
                    constraints=cons,
                    domain=domain,
                    site=site,
                    confidence=confidence,
                    proposal_id=proposal_id,
                )
        except InteractiveLockError as e:
            render_error(str(e))
            raise typer.Exit(1) from e
        except ValueError as e:
            render_error(str(e))
            raise typer.Exit(1) from e
        typer.echo(f"Draft saved (pending): {rec['id']}")
        typer.echo(f"  Summary: {rec['summary']}")
        typer.echo(f"  Relates-to: {rec['relates_to']}")
        _pending_record_hint()
        return

    if not relates_to or not summary or not rationale or not author:
        render_error(
            "Record requires --relates-to, --summary, --rationale, and --author "
            "(or use -i / --list / --approve / --approve-last / --reject)"
        )
        raise typer.Exit(1)

    try:
        rec = do_propose(
            cfg,
            relates_to=relates_to,
            summary=summary,
            rationale=rationale,
            author=author,
            alternatives=alts,
            constraints=cons,
            domain=domain,
            site=site,
            confidence=confidence,
            proposal_id=proposal_id,
        )
    except ValueError as e:
        render_error(str(e))
        raise typer.Exit(1) from e

    typer.echo(f"Draft saved (pending): {rec['id']}")
    typer.echo(f"  Summary: {rec['summary']}")
    typer.echo(f"  Relates-to: {rec['relates_to']}")
    _pending_record_hint()


@app.command("record")
def record_command(
    list_: bool = typer.Option(False, "--list", help="Show pending drafts"),
    all_: bool = typer.Option(False, "--all", help="With --list: include approved/rejected"),
    json_out: bool = typer.Option(False, "--json", help="With --list: emit raw JSONL records"),
    interactive: bool = typer.Option(
        False,
        "--interactive",
        "-i",
        help="Record a fact interactively",
    ),
    approve: str | None = typer.Option(None, "--approve", help="Approve a specific draft id"),
    approve_last: bool = typer.Option(
        False,
        "--approve-last",
        help="Approve newest pending draft and index (default workflow)",
    ),
    no_index: bool = typer.Option(False, "--no-index", help="On approve: skip auto-index"),
    reject: str | None = typer.Option(None, "--reject", help="Reject a draft id"),
    signer: str | None = typer.Option(None, "--signer", help="Signer (default on approve: ryan)"),
    reason: str | None = typer.Option(None, "--reason", help="Required for --reject"),
    ledger_id: str | None = typer.Option(None, "--ledger-id", help="Canonical ledger id on approve"),
    parse_doc: str | None = typer.Option(None, "--parse-doc", hidden=True),
    relates_to: str | None = typer.Option(None, "--relates-to"),
    summary: str | None = typer.Option(None, "--summary"),
    rationale: str | None = typer.Option(None, "--rationale"),
    author: str | None = typer.Option(None, "--author"),
    alternative: list[str] | None = typer.Option(None, "--alternative"),
    alternatives_rejected: list[str] | None = typer.Option(None, "--alternatives-rejected"),
    constraint: list[str] | None = typer.Option(None, "--constraint"),
    constraints: list[str] | None = typer.Option(None, "--constraints"),
    domain: str = typer.Option("coding.tooling", "--domain"),
    site: str = typer.Option("", "--site"),
    confidence: float = typer.Option(0.8, "--confidence"),
    proposal_id: str | None = typer.Option(None, "--id"),
):
    """Record a durable fact for all agents (`record -i` → `record --approve-last`)."""
    # Pass recover/rebase explicitly: Typer Option defaults are OptionInfo objects
    # when this wrapper calls the shared command as a plain Python function.
    propose_decision_command(
        list_=list_,
        all_=all_,
        json_out=json_out,
        interactive=interactive,
        approve=approve,
        approve_last=approve_last,
        no_index=no_index,
        reject=reject,
        signer=signer,
        reason=reason,
        recover=None,
        rebase=None,
        ledger_id=ledger_id,
        parse_doc=parse_doc,
        relates_to=relates_to,
        summary=summary,
        rationale=rationale,
        author=author,
        alternative=alternative,
        alternatives_rejected=alternatives_rejected,
        constraint=constraint,
        constraints=constraints,
        domain=domain,
        site=site,
        confidence=confidence,
        proposal_id=proposal_id,
    )


@app.command()
def related(
    ledger_id: str = typer.Argument(..., help="Observation, decision, or verification id"),
):
    """Traverse the evidence graph around a ledger id (not semantic search)."""
    from config import load_config
    from chroma_readonly import open_readonly_unit_store
    from query import render_error
    from related import render_related

    cfg = load_config()
    store = open_readonly_unit_store(cfg["index"]["chroma_dir"])
    if not render_related(store, ledger_id):
        render_error(f"Ledger id not found: {ledger_id.strip()}")
        raise typer.Exit(1)


@app.command("unresolved")
def unresolved_command(
    site: str | None = typer.Option(None, "--site", help="Filter by site hostname"),
    domain: str | None = typer.Option(None, "--domain", help="Filter by domain"),
    json_out: bool = typer.Option(False, "--json", help="Emit JSON instead of table"),
):
    """List open observations — no LLM, just the ledger graph.

    Shows every observation without a passing verification, plus any with a
    failed check. Filter by --site and/or --domain.
    """
    import json

    from config import load_config
    from chroma_readonly import open_readonly_unit_store
    from unresolved import list_unresolved, render_unresolved, unresolved_payload

    cfg = load_config()
    store = open_readonly_unit_store(cfg["index"]["chroma_dir"])
    payload = unresolved_payload(store, site=site, domain=domain)

    if json_out:
        typer.echo(json.dumps(payload["items"], indent=2))
    else:
        items = list_unresolved(store, site=site, domain=domain)
        render_unresolved(items)
        from next_steps import after_unresolved

        after_unresolved(site=site, count=len(items))


@app.command("shadow-inventory")
def shadow_inventory_command(
    json_out: bool = typer.Option(
        False, "--json", help="Emit redacted machine-readable inventory JSON"
    ),
    report: Path | None = typer.Option(
        None,
        "--report",
        help="Write full machine-readable readiness report JSON to this path",
        path_type=Path,
    ),
    sample: int = typer.Option(
        200,
        "--sample",
        help="Max candidate rows to classify (deterministic local metadata only)",
    ),
):
    """Phase 0 read-only shadow inventory and readiness summary.

    Does not enable shadowing, mutate Chroma, or claim activation/cutover.
    """
    from config import load_config
    from shadow_inventory import (
        collect_phase0_inventory,
        redacted_stdout_view,
        write_report,
    )

    cfg = load_config()
    report_obj = collect_phase0_inventory(
        cfg, include_candidate_sample=sample
    )
    if report is not None:
        write_report(report, report_obj)
    if json_out:
        typer.echo(json.dumps(redacted_stdout_view(report_obj), indent=2, sort_keys=True))
    else:
        inv = report_obj["inventory"]
        shadow = report_obj["shadow"]
        typer.echo(report_obj["human_summary"])
        typer.echo(
            f"units={inv['active_unit_count']} chroma_only={inv['chroma_only_count']} "
            f"shadow_touched={shadow['shadow_touched_entity_count']} "
            f"health={shadow['health_status']} enabled={shadow['enabled']}"
        )
        typer.echo(f"commit={inv['code_commit']} rule_v={inv['comparison_rule_version']}")
        if report is not None:
            typer.echo(f"report={report}")


@app.command("exclude")
def exclude_command(  # pylint: disable=too-many-arguments,too-many-positional-arguments
    path: str = typer.Argument(None, help="File path to exclude from indexing"),
    reason: str = typer.Option("", "--reason", help="Why this conversation is excluded"),
    list_: bool = typer.Option(False, "--list", help="Show all excluded conversations"),
    undo: str = typer.Option(None, "--undo", help="Re-include a previously excluded file path"),
    purge: bool = typer.Option(
        False,
        "--purge",
        help="Also logically delete derived Chroma/JSONL rows for this exact source",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        help="Skip confirmation prompt for --purge",
    ),
):
    """Mark a conversation as excluded from indexing, or list/undo exclusions."""
    from config import load_config
    from exclude_cli import (
        run_exclude_list,
        run_exclude_purge,
        run_exclude_soft,
        run_exclude_undo,
    )
    from ingest import load_processed
    from query import render_error

    cfg = load_config()
    processed_path = cfg["index"]["processed_log"]
    processed = load_processed(processed_path)

    if list_:
        run_exclude_list(processed, echo=typer.echo)
        return

    _guard_write()

    if undo:
        run_exclude_undo(
            cfg, undo, echo=typer.echo, render_error=render_error
        )
        return

    if not path:
        render_error("Provide a file path to exclude, or use --list / --undo.")
        raise typer.Exit(1)

    if purge:
        run_exclude_purge(
            cfg,
            path,
            reason,
            yes,
            echo=typer.echo,
            confirm=typer.confirm,
            render_error=render_error,
        )
        return

    run_exclude_soft(
        cfg, path, reason, echo=typer.echo, render_error=render_error
    )


@app.command("forget")
def forget_command(
    unit_id: str = typer.Argument(None, help="Knowledge unit id to tombstone (from search_fast / related output)"),
    reason: str = typer.Option("", "--reason", help="Why this unit is being invalidated"),
    undo: bool = typer.Option(False, "--undo", help="Reverse a prior forget (clear superseded)"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt"),
):
    """Tombstone one stale knowledge unit (superseded=True) so it drops out of search.

    Per-unit counterpart to `exclude` (which acts on whole source files). Use when a single
    distilled fact is wrong but its source conversation still holds good units. Reversible
    with --undo; history is retained (tombstone, not delete).
    """
    from datetime import datetime, timezone

    from chroma_store import invalidate_superseded_cache, is_superseded
    from query import render_error

    if not unit_id:
        render_error("Provide a knowledge unit id (see search_fast / related output).")
        raise typer.Exit(1)

    _guard_write()
    from chroma_write_store import production_chroma_write_session

    with production_chroma_write_session(entrypoint="convmem.forget") as session:
        store = session.store
        unit = store.get_unit(unit_id)
        if unit is None:
            render_error(f"No unit found with id {unit_id}.")
            raise typer.Exit(1)

        meta = dict(unit["metadata"] or {})
        doc = unit["document"] or ""
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        typer.echo(f"unit:       {unit_id}")
        typer.echo(f"source:     {meta.get('source_path')}")
        typer.echo(f"type/title: {meta.get('type')} / {meta.get('title')}")
        typer.echo(f"superseded: {meta.get('superseded')}")
        typer.echo(f"document:   {doc[:280]}")

        if undo:
            if not is_superseded(meta):
                typer.echo("Unit is not superseded — nothing to undo.")
                return
            # Chroma update() merges metadata keys rather than replacing the dict,
            # so popping keys leaves the stored superseded=True intact. Overwrite
            # with a not-superseded value instead (is_superseded checks `is True`).
            meta["superseded"] = False
            meta["superseded_by"] = ""
            meta["updated_at"] = now
            store.update_unit_metadata(unit_id, meta)
            invalidate_superseded_cache(store.chroma_dir)
            typer.echo("Restored: unit is active again (superseded cleared).")
            return

        if is_superseded(meta):
            typer.echo("Already superseded — nothing to do.")
            return

        if not yes and not typer.confirm("Tombstone this unit (exclude from search)?"):
            typer.echo("Aborted.")
            raise typer.Exit(1)

        meta["superseded"] = True
        meta["superseded_by"] = f"forget-cli:{reason or 'manual'}"
        meta["updated_at"] = now
        store.update_unit_metadata(unit_id, meta)
        invalidate_superseded_cache(store.chroma_dir)
        typer.echo(
            f"Tombstoned {unit_id} — excluded from search results (reversible with --undo)."
        )


@app.command("shadow-activate")
def shadow_activate_command(  # pylint: disable=too-many-positional-arguments
    token: Path | None = typer.Option(
        None, "--authorization-token", help="Ryan-issued exact 0600 one-shot token"
    ),
    config_path: Path = typer.Option(
        Path("~/.config/convmem/config.toml").expanduser(), "--config"
    ),
    census_path: Path = typer.Option(
        Path("docs/plans/SHADOW-WRITER-CENSUS.json"), "--census"
    ),
    nonce_store_path: Path = typer.Option(
        Path("~/.local/share/convmem/shadow/authorization-nonces.jsonl").expanduser(),
        "--nonce-store",
    ),
    writer_lock_path: Path = typer.Option(
        Path("~/.local/share/convmem/locks/chroma_writer_gate.lock").expanduser(),
        "--writer-lock",
    ),
    attest_dir: Path = typer.Option(
        Path("~/.local/share/convmem/writer_attestations").expanduser(),
        "--attest-dir",
    ),
):
    """Run C5 activation; never controls services or mutates Chroma."""
    if token is None:
        typer.echo(
            json.dumps(
                {
                    "state": "disabled",
                    "committed": False,
                    "refusal_code": "authorization_missing",
                },
                sort_keys=True,
            )
        )
        raise typer.Exit(2)
    from shadow_activation import ActivationRefused, activate_shadow

    try:
        outcome = activate_shadow(
            token_path=token,
            config_path=config_path,
            census_path=census_path,
            nonce_store_path=nonce_store_path,
            writer_lock_path=writer_lock_path,
            attest_dir=attest_dir,
        )
    except ActivationRefused as exc:
        typer.echo(
            json.dumps(
                {
                    "state": exc.state or "disabled",
                    "committed": False,
                    "refusal_code": exc.code,
                    "detail": exc.detail,
                },
                sort_keys=True,
            )
        )
        raise typer.Exit(2) from exc
    typer.echo(json.dumps(outcome.__dict__, sort_keys=True))
    if outcome.refusal_code:
        raise typer.Exit(2)


@app.command("shadow-rollback")
def shadow_rollback_command(
    activation_id: str = typer.Option(..., "--activation-id"),
    config_path: Path = typer.Option(
        Path("~/.config/convmem/config.toml").expanduser(), "--config"
    ),
    writer_lock_path: Path = typer.Option(
        Path("~/.local/share/convmem/locks/chroma_writer_gate.lock").expanduser(),
        "--writer-lock",
    ),
    journal_path: Path | None = typer.Option(None, "--journal"),
    recover_prepared: bool = typer.Option(False, "--recover-prepared"),
):
    """Disable Shadow or recover one exact disabled precommit transaction."""
    from shadow_activation import (
        ActivationRefused,
        recover_prepared_activation,
        rollback_activation,
    )

    try:
        if recover_prepared:
            if journal_path is None:
                raise ActivationRefused(
                    "prepared_not_committed", "--recover-prepared requires --journal"
                )
            outcome = recover_prepared_activation(
                journal_path=journal_path,
                config_path=config_path,
                activation_id=activation_id,
                writer_lock_path=writer_lock_path,
            )
        else:
            outcome = rollback_activation(
                config_path=config_path,
                activation_id=activation_id,
                writer_lock_path=writer_lock_path,
                journal_path=journal_path,
            )
    except ActivationRefused as exc:
        typer.echo(
            json.dumps(
                {"committed": False, "refusal_code": exc.code, "detail": exc.detail},
                sort_keys=True,
            )
        )
        raise typer.Exit(2) from exc
    typer.echo(json.dumps(outcome.__dict__, sort_keys=True))


@app.command("shadow-canary")
def shadow_canary_command(  # pylint: disable=too-many-arguments,too-many-positional-arguments,unused-argument
    scratch_dir: Path | None = typer.Option(
        None, "--scratch-dir", help="New private scratch directory; must not exist"
    ),
    intended_ledger_path: Path | None = typer.Option(
        None, "--intended-ledger-path", help="Read-only mount reference; never opened"
    ),
    chroma_root: Path | None = typer.Option(
        None, "--chroma-root", help="Production Chroma root used only for overlap refusal"
    ),
    unit_count: int | None = typer.Option(
        None, "--unit-count", help="Fresh read-only current knowledge_units count"
    ),
    p50_event_bytes: int | None = typer.Option(
        None, "--p50-event-bytes", help="Redacted synthetic P50 encoded-event length"
    ),
    p95_event_bytes: int | None = typer.Option(
        None, "--p95-event-bytes", help="Redacted synthetic P95 encoded-event length"
    ),
    maximum_event_bytes: int | None = typer.Option(
        None, "--maximum-event-bytes", help="Synthetic maximum supported event length"
    ),
    event_size_evidence_sha256: str | None = typer.Option(
        None,
        "--event-size-evidence-sha256",
        help="SHA-256 of redacted event-size derivation evidence",
    ),
    writer_census_report: Path | None = typer.Option(
        None,
        "--writer-census-report",
        help="Final private C7 report; metrics and hash are derived, never supplied",
    ),
):
    """Run C6 only in a new same-mount scratch directory; never activates Shadow."""
    from shadow_canary import (
        CanaryRefused,
        inputs_from_cli_values,
        redacted_report,
        run_shadow_canary,
    )

    try:
        inputs = inputs_from_cli_values(locals())
        report = run_shadow_canary(inputs)
    except CanaryRefused as exc:
        typer.echo(
            json.dumps(
                {"verdict": "REFUSED", "refusal_code": exc.code, "detail": exc.detail},
                sort_keys=True,
            )
        )
        raise typer.Exit(2) from exc
    typer.echo(json.dumps(redacted_report(report), sort_keys=True))
    if report.verdict != "PASS":
        raise typer.Exit(2)


@app.command("writer-census-start")
def writer_census_start_command(
    chroma_root: Path = typer.Option(
        ..., "--chroma-root", help="Production Chroma root identity only"
    ),
    writer_gate_path: Path = typer.Option(
        Path("~/.local/share/convmem/locks/chroma_writer_gate.lock"), "--writer-gate-path"
    ),
    census_dir: Path = typer.Option(
        Path("~/.local/share/convmem/writer-census"), "--census-dir"
    ),
):
    """Arm a payload-free C7 census for the next seven complete UTC days."""
    from chroma_write_store import exclusive_writer_lease
    from writer_census import WriterCensusRefused, start_writer_census

    try:
        # The bounded exclusive acquisition proves no compliant session was
        # already open at census creation; no service is controlled here.
        with exclusive_writer_lease(lock_path=writer_gate_path, timeout_ms=30_000):
            header = start_writer_census(
                chroma_root=chroma_root,
                writer_gate_path=writer_gate_path,
                census_dir=census_dir,
            )
    except (WriterCensusRefused, TimeoutError) as exc:
        code = getattr(exc, "code", "writer_quiesce_timeout")
        typer.echo(json.dumps({"verdict": "REFUSED", "refusal_code": code}, sort_keys=True))
        raise typer.Exit(2) from exc
    typer.echo(json.dumps({"verdict": "ARMED", **header}, sort_keys=True))


@app.command("writer-census-status")
def writer_census_status_command(
    census_dir: Path = typer.Option(Path("~/.local/share/convmem/writer-census"), "--census-dir"),
):
    """Read the C7 journal status; this command never changes live state."""
    from writer_census import WriterCensusRefused, census_status

    try:
        typer.echo(json.dumps(census_status(census_dir=census_dir), sort_keys=True))
    except WriterCensusRefused as exc:
        typer.echo(json.dumps({"verdict": "REFUSED", "refusal_code": exc.code}, sort_keys=True))
        raise typer.Exit(2) from exc


@app.command("writer-census-report")
def writer_census_report_command(
    census_dir: Path = typer.Option(Path("~/.local/share/convmem/writer-census"), "--census-dir"),
):
    """Validate and finalize a completed C7 census for C6 binding."""
    from writer_census import WriterCensusRefused, build_writer_census_report

    try:
        report = build_writer_census_report(census_dir=census_dir)
    except WriterCensusRefused as exc:
        typer.echo(json.dumps({"verdict": "REFUSED", "refusal_code": exc.code}, sort_keys=True))
        raise typer.Exit(2) from exc
    typer.echo(json.dumps({"verdict": "PASS", **report}, sort_keys=True))


def main():
    # Convenience: `convmem "query"` routes to the search command when the
    # first token isn't a known subcommand.
    argv = sys.argv[1:]
    if argv and not argv[0].startswith("-") and argv[0] not in _SUBCOMMANDS:
        sys.argv = [sys.argv[0], "search"] + argv
    app()


if __name__ == "__main__":
    main()

# ---------------------------------------------------------------------------
# file at that exact line count until a larger extract lands under 1000.
# ---------------------------------------------------------------------------
# fingerprint-pad-0
# fingerprint-pad-1
# fingerprint-pad-2
