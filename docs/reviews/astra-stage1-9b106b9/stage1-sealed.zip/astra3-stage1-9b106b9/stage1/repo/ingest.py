# pylint: disable=too-many-lines
"""Ingest pipeline.

For each source file:
  - skip if its content hash is already in processed.json (idempotent)
  - parse -> canonical messages
  - chunk (size/overlap from config)
  - per chunk:
      summarize -> embed -> conversation_summaries  (fallback / --raw)
      distill   -> embed -> knowledge_units       (primary search, Step 5+)
"""

import fcntl
import hashlib
import json
import time
import uuid
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from adapters.detect import TOOL_BY_FORMAT, detect_format, get_parser
from atomic_files import atomic_write_text
from chroma_write_store import production_chroma_write_session, production_writer_boundary
from config import load_config
from distill import (
    distill_consumed_view,
    distill_prompt,
    distill as _distill,
    distill_with_response,
    normalize_unit,
)
from llm import (
    ollama_embed,
    resolve_generation_binding,
    summarize,
    summarize_consumed_view,
    summarize_prompt,
)
from provenance_binding import (
    attach_unit_provenance,
    build_ingest_envelope,
    projection_metadata,
    provenance_identity,
)

_SYNTHESIS_FAIL_LOG = Path("~/.local/share/convmem/synthesis_failures.jsonl")


class UnsupportedSourceError(ValueError):
    """`index --file` names a path no adapter can parse."""


class ProviderUnavailableError(RuntimeError):
    """The synthesis provider rejected the credential or the account balance."""


# 401/402/403 mean the credential or the balance is wrong. No amount of
# retrying fixes that mid-run, and every remaining chunk will fail identically.
_FATAL_PROVIDER_STATUS = frozenset({401, 402, 403})


def _provider_fatal(exc: BaseException) -> int | None:
    """Return the HTTP status when ``exc`` is an unrecoverable provider refusal."""
    response = getattr(exc, "response", None)
    status = getattr(response, "status_code", None)
    return status if status in _FATAL_PROVIDER_STATUS else None

# Keep the established ingest.distill patch seam for hermetic tests and other
# callers while using the response-aware path during ordinary execution.
distill = _distill


def _distill_with_provenance(*args, **kwargs) -> tuple[list[dict], str]:
    if distill is not _distill:
        units = distill(*args, **kwargs)
        return units, json.dumps(units, ensure_ascii=False, sort_keys=True)
    return distill_with_response(*args, **kwargs)


@dataclass
class _ReindexSnapshot:
    """Rows eligible for pruning after one successful file generation."""

    unit_ids: dict[str, set[str]] = field(default_factory=dict)
    summary_ids: dict[str, set[str]] = field(default_factory=dict)


@dataclass
class _ChunkBuildResult:
    """File-level build outcome and deterministic replacement manifest."""

    completed: bool = True
    chunks: int = 0
    units: int = 0
    exact_suppressed: int = 0
    semantic_queued: int = 0
    summary_ids: set[str] = field(default_factory=set)
    unit_ids: set[str] = field(default_factory=set)


@dataclass
class ChunkArtifact:  # pylint: disable=too-many-instance-attributes
    """Immutable one-chunk transform output used by both legacy and incremental commit."""

    complete: bool
    degraded: bool
    start_offset: int
    end_offset: int
    doc_id: str
    summary: str
    summary_embedding: list
    metadata: dict
    units_to_add: list
    input_digest: str
    distill_status: str


def _uuid4_from_seed(seed: str) -> uuid.UUID:
    """Return a RFC 4122 UUID4 whose bytes are a SHA-256 of ``seed``.

    Provenance minting requires UUID4. Clean-rebuild equality also requires the
    same inputs to mint the same assertion identity, so ingest derives that
    UUID4 from the chunk/unit locator instead of drawing a random value.
    """
    digest = hashlib.sha256(f"convmem-ingest-assertion-v1:{seed}".encode("utf-8")).digest()[:16]
    data = bytearray(digest)
    data[6] = (data[6] & 0x0F) | 0x40
    data[8] = (data[8] & 0x3F) | 0x80
    return uuid.UUID(bytes=bytes(data))


@contextmanager
def _mint_assertion_from_seed(seed: str):
    """Scope a content-addressed UUID4 over one provenance mint."""
    attempt = 0
    original = uuid.uuid4

    def _next() -> uuid.UUID:
        nonlocal attempt
        attempt += 1
        return _uuid4_from_seed(f"{seed}:{attempt}")

    uuid.uuid4 = _next  # type: ignore[method-assign]
    try:
        yield
    finally:
        uuid.uuid4 = original


def _log_chunk_failure(chunk_id: int, stage: str, session_file: str, error: Exception) -> None:
    """Append one JSONL line per chunk failure. Non-blocking — never raises."""  # pylint: disable=duplicate-code
    try:
        log_path = _SYNTHESIS_FAIL_LOG.expanduser()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        entry = {
            "ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "error_type": type(error).__name__,
            "error": str(error)[:200],
            "chunk_id": chunk_id,
            "stage": stage,
            "session_file": session_file,
        }
        with log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:  # pylint: disable=broad-exception-caught
        pass  # Telemetry must never break ingest


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def load_processed(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except json.JSONDecodeError as e:
        raise RuntimeError(f"processed.json corrupt at {p}: {e}") from e


def save_processed(path: str, data: dict) -> None:
    p = Path(path)
    atomic_write_text(p, json.dumps(data, indent=2), encoding="utf-8")


def processed_lock_path(processed_path: str) -> Path:
    """Stable sidecar lock path (not processed.json — atomic replace changes inode)."""
    p = Path(processed_path)
    return p.with_name(p.name + ".lock")


@contextmanager
def _processed_lock(processed_path: str):
    """Exclusive advisory lock on the processed-state sidecar."""
    lock = processed_lock_path(processed_path)
    lock.parent.mkdir(parents=True, exist_ok=True)
    with open(lock, "a+", encoding="utf-8") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def mutate_processed(processed_path: str, mutator: Callable[[dict], None]) -> dict:
    """Lock, reload on-disk state, mutate, atomic-save, unlock.

    Hold only for read+mutate+write. Never across parse/LLM/embed/Chroma work.
    Always releases the lock on exception paths (via `_processed_lock`).
    """
    with production_writer_boundary(
        entrypoint="ingest.processed",
    ):
        with _processed_lock(processed_path):
            data = load_processed(processed_path)
            mutator(data)
            save_processed(processed_path, data)
            return data


def chunk_messages(messages: list[dict], size: int, overlap: int) -> list[dict]:
    """Sliding-window chunks over a message list.

    Returns dicts with the message slice plus its start/end offsets.
    """
    if size <= 0:
        size = 60
    step = max(1, size - overlap)
    chunks = []
    i = 0
    n = len(messages)
    while i < n:
        window = messages[i : i + size]
        chunks.append(
            {
                "messages": window,
                "start_offset": i,
                "end_offset": i + len(window) - 1,
            }
        )
        if i + size >= n:
            break
        i += step
    return chunks


def render_chunk(messages: list[dict], total_budget: int = 10000) -> str:
    """Render a chunk for summarization within a bounded character budget.

    A per-message share of the budget is computed so the summarizer sees
    breadth across all turns in the chunk rather than a single huge
    head-truncated message.
    """
    if not messages:
        return ""
    return "\n".join(render_chunk_message_views(messages, total_budget=total_budget))


def render_chunk_message_views(messages: list[dict], total_budget: int = 10000) -> list[str]:
    """Return each exact per-message view used by :func:`render_chunk`."""

    if not messages:
        return []
    per_msg = max(150, total_budget // len(messages))
    lines = []
    for message in messages:
        content = message["content"].strip()
        if len(content) > per_msg:
            content = content[:per_msg] + " […]"
        lines.append(f"{message['role']}: {content}")
    return lines


def _chunk_date(messages: list[dict]) -> str:
    for m in messages:
        ts = m.get("timestamp")
        if ts:
            return str(ts)[:10]
    return ""


def _chunk_session_meta(messages: list[dict], path: str, tool: str = "") -> dict:
    from open_source import _session_id_from_path

    conv_id = next(
        (m.get("conversation_id") for m in messages if m.get("conversation_id")), ""
    )
    session_id = next(
        (m.get("session_id") for m in messages if m.get("session_id")), ""
    ) or _session_id_from_path(path) or ""
    workspace = next(
        (m.get("workspace_directory") for m in messages if m.get("workspace_directory")),
        "",
    )
    source_type = next(
        (m.get("source_type") for m in messages if m.get("source_type")), ""
    )
    meta = {
        "conversation_id": conv_id or "",
        "session_id": session_id or "",
        "workspace_directory": workspace or "",
    }
    if source_type:
        meta["source_type"] = source_type
    # Optional forward-only agent_run_id (unique exact match only).
    try:
        from agent_run_ledger import resolve_agent_run_id_for_ingest

        run_id = resolve_agent_run_id_for_ingest(
            client=tool or "unknown",
            native_session_id=session_id or None,
            repository=workspace or None,
        )
        if run_id:
            meta["agent_run_id"] = run_id
    except (OSError, ImportError, ValueError, TypeError, KeyError):
        # Unavailable/corrupt run log must not change ingest behavior.
        pass
    return meta


def _files_from_inventory(inventory_path: str) -> list[dict]:
    records = []
    with open(inventory_path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return records


def _processed_path_str(entry_path: str) -> str:
    return str(Path(entry_path).expanduser().resolve())


def _stored_hash_for_path(path_str: str, processed: dict) -> str | None:
    """Return processed.json key (content hash) for a resolved path, if any."""
    for key, entry in processed.items():
        if not isinstance(entry, dict) or entry.get("excluded"):
            continue
        ep = entry.get("path")
        if ep and _processed_path_str(ep) == path_str:
            return key
    return None


def _path_is_excluded(processed: dict, path_key: str) -> bool:
    for entry in processed.values():
        if not isinstance(entry, dict) or not entry.get("excluded"):
            continue
        ep = entry.get("path")
        if ep and _processed_path_str(ep) == path_key:
            return True
    return False


def _purge_stale_same_path(
    processed: dict,
    path_key: str,
    keep_hash: str,
    *,
    preserve_exclusions: bool = True,
) -> int:
    """Remove other same-path keys. Exclusions survive when preserve_exclusions=True."""
    removed = 0
    for key, entry in list(processed.items()):
        if key == keep_hash or not isinstance(entry, dict):
            continue
        ep = entry.get("path")
        if not ep or _processed_path_str(ep) != path_key:
            continue
        if preserve_exclusions and entry.get("excluded"):
            continue
        del processed[key]
        removed += 1
    return removed


def commit_processed_index_entry(
    processed_path: str,
    *,
    file_hash: str,
    path_key: str,
    chunks: int,
    units: int,
) -> bool:
    """Merge one file's index metadata under the processed-state lock.

    Reloads latest disk state; never writes a whole stale pre-index snapshot.
    Returns False when a path-based exclusion blocks the commit (exclusion kept).
    """
    result = {"committed": False}

    def mutator(data: dict) -> None:
        if _path_is_excluded(data, path_key):
            return
        existing = data.get(file_hash)
        if isinstance(existing, dict) and existing.get("excluded"):
            return
        data[file_hash] = {
            "path": path_key,
            "chunks": chunks,
            "units": units,
        }
        _purge_stale_same_path(data, path_key, file_hash, preserve_exclusions=True)
        result["committed"] = True

    mutate_processed(processed_path, mutator)
    return result["committed"]


def exclude_processed_path(
    processed_path: str,
    target: str,
    file_hash: str,
    reason: str = "",
    *,
    purged_at: str | None = None,
) -> None:
    """Mark a resolved path excluded under the processed-state lock.

    Canonicalizes path exclusion across content hashes: clears other active
    same-path exclusion markers, keeps one marker on ``file_hash``, and
    preserves the latest explicit reason (or carries forward a prior reason
    when re-excluding without a new reason). Optional ``purged_at`` stamps the
    surviving marker in the same transaction (purge path).
    """
    path_key = _processed_path_str(target)

    def mutator(data: dict) -> None:
        carried_reason = reason
        if not carried_reason:
            for entry in data.values():
                if not isinstance(entry, dict) or not entry.get("excluded"):
                    continue
                ep = entry.get("path")
                if ep and _processed_path_str(ep) == path_key:
                    prior = entry.get("exclude_reason") or ""
                    if prior:
                        carried_reason = prior

        for entry in data.values():
            if not isinstance(entry, dict) or not entry.get("excluded"):
                continue
            ep = entry.get("path")
            if ep and _processed_path_str(ep) == path_key:
                entry.pop("excluded", None)
                entry.pop("exclude_reason", None)
                entry.pop("purged_at", None)

        entry = data.get(file_hash, {})
        if not isinstance(entry, dict):
            entry = {}
        entry["path"] = path_key
        entry["excluded"] = True
        if carried_reason:
            entry["exclude_reason"] = carried_reason
        else:
            entry.pop("exclude_reason", None)
        if purged_at:
            entry["purged_at"] = purged_at
        else:
            entry.pop("purged_at", None)
        data[file_hash] = entry

    mutate_processed(processed_path, mutator)


def undo_exclude_processed_path(processed_path: str, target: str) -> bool:
    """Clear every active exclusion for one resolved path in one transaction.

    Returns True if at least one active marker was cleared. Other paths untouched.
    """
    path_key = _processed_path_str(target)
    found = {"ok": False}

    def mutator(data: dict) -> None:
        for entry in data.values():
            if not isinstance(entry, dict) or not entry.get("excluded"):
                continue
            ep = entry.get("path")
            if ep and _processed_path_str(ep) == path_key:
                entry.pop("excluded", None)
                entry.pop("exclude_reason", None)
                found["ok"] = True

    mutate_processed(processed_path, mutator)
    return found["ok"]


def watch_skip_reason(
    path: str | Path,
    *,
    processed: dict | None = None,
    file_hash: str | None = None,
) -> str | None:
    """Why watch should skip this file without opening Chroma. None = may ingest."""
    p = Path(path).expanduser().resolve()
    if processed is None:
        cfg = load_config()
        processed = load_processed(cfg["index"]["processed_log"])
    path_str = str(p)

    for entry in processed.values():
        if not isinstance(entry, dict) or not entry.get("excluded"):
            continue
        ep = entry.get("path")
        if ep and _processed_path_str(ep) == path_str:
            return "excluded"

    path_known_hash = _stored_hash_for_path(path_str, processed)
    if path_known_hash is not None:
        if file_hash is None:
            try:
                file_hash = sha256_file(str(p))
            except OSError:
                return "unreadable"
        if file_hash == path_known_hash:
            return "unchanged"
        # Fall through rather than returning None. This exact content may
        # already be indexed under a different path (Copilot audit copies,
        # worktrees, backups all duplicate repo trees). ingest gates on the
        # content hash alone, so short-circuiting here spawns an index
        # subprocess that immediately no-ops -- ~1,900 wasted spawns/day
        # observed on docs/inter-model/*.md.

    if file_hash is None:
        try:
            file_hash = sha256_file(str(p))
        except OSError:
            return "unreadable"

    if file_hash in processed and processed[file_hash].get("excluded"):
        return "excluded"
    if file_hash in processed:
        return "unchanged"
    return None


def _deduplicate_units_export(export_path: Path) -> int:
    """Compact the export inside the universal mutation boundary."""

    with production_writer_boundary(entrypoint="ingest.export"):
        return _deduplicate_units_export_impl(export_path)


def _deduplicate_units_export_impl(export_path: Path) -> int:
    """Rewrite knowledge_units.jsonl keeping only the last occurrence of each unit ID.

    This prevents unbounded growth from repeated re-indexing. Returns lines removed.
    Holds the export flock for the full rewrite.
    """
    from export_compaction import compact_units_export

    return compact_units_export(export_path)


def _echo_neutralize_preview(
    preview: list, display_name: str, tombstone_tag: str, verbose: bool
) -> None:
    """Unconditional provenance echo before a supersede (neutralize) run.

    Guardrail for the neutralize-provenance-confirm standing check: a supersede
    cannot execute without the affected source, unit count, timestamp range,
    and tombstone tag being printed first. One line per logical file —
    --supersede runs at every handoff sync, so this must stay compact.
    """
    if not preview:
        return
    stamps = sorted(
        t[:10]
        for unit in preview
        for t in (unit.get("created_at"), unit.get("updated_at"))
        if t
    )
    span = f" ({stamps[0]}..{stamps[-1]})" if stamps else ""
    print(
        f"  [neutralize] {len(preview)} active units for {display_name}{span}"
        f" -> tombstone as {tombstone_tag}"
    )
    if verbose:
        sample = ", ".join(
            f"{u['id']} \"{u['title']}\"" if u.get("title") else str(u["id"])
            for u in preview[:5]
        )
        more = f" (+{len(preview) - 5} more)" if len(preview) > 5 else ""
        print(f"  [neutralize]   {sample}{more}")



def _commit_chunk_to_stores(  # pylint: disable=too-many-arguments,too-many-locals,unused-argument
    *,
    cfg: dict,
    idx: dict,
    path_key: str,
    path: str,
    file_hash: str,
    chroma_dir: str,
    units_export: Path | None,
    doc_id: str,
    summary: str,
    summary_embedding: list,
    metadata: dict,
    units_to_add: list,
    verbose: bool,
    written_unit_ids: set[str] | None = None,
    write_export: bool = True,
    persist_dedupe: bool = True,
    dedupe_events: list | None = None,
) -> tuple[bool, int, int, int, int]:
    """Source/export-locked batch write with ingestion dedup statistics."""
    from ingest_dedupe import evaluate_ingest_batch, persist_ingest_dedupe
    from purge_locks import export_flock, source_flock

    with source_flock(cfg, path_key):
        processed = load_processed(idx["processed_log"])
        if _path_is_excluded(processed, path_key) or (
            file_hash in processed and processed[file_hash].get("excluded")
        ):
            if verbose:
                print(f"  [skip] excluded during batch-write {Path(path).name}")
            return False, 0, 0, 0, 0
        n_units = 0
        with production_chroma_write_session(entrypoint="ingest.write") as _pw:
            store = _pw.store
            cfg = _pw.live_cfg
            store.add_summary(doc_id, summary, summary_embedding, metadata)
            dedupe = evaluate_ingest_batch(store, cfg, units_to_add)
            written_projection_ids: set[str] = set()
            for unit, doc, unit_embedding, unit_meta in dedupe.accepted:
                projection_unit = dict(unit)
                projection_meta = dict(unit_meta)
                existing = store.get_unit(unit["id"])
                existing_identity = (
                    provenance_identity(existing.get("metadata") or {})
                    if existing is not None
                    else None
                )
                candidate_identity = provenance_identity(unit_meta)
                if (
                    existing is not None
                    and candidate_identity is not None
                    and existing_identity != candidate_identity
                    and (existing_identity is not None or candidate_identity is not None)
                ):
                    # A stable source/chunk id is a projection address, not
                    # provenance authority. Keep the old assertion intact
                    # while staging a distinct assertion for this generation.
                    projection_id = hashlib.sha256(
                        (
                            "convmem-p3-projection-v1:"
                            f"{unit['id']}:{candidate_identity[0]}:{candidate_identity[1]}"
                        ).encode("utf-8")
                    ).hexdigest()
                    projection_unit["id"] = projection_id
                    projection_meta["id"] = projection_id
                store.add_unit(
                    projection_unit["id"], doc, unit_embedding, projection_meta
                )
                written_projection_ids.add(projection_unit["id"])
                if units_export and write_export:
                    units_export.parent.mkdir(parents=True, exist_ok=True)
                    with export_flock(cfg):
                        with open(units_export, "a", encoding="utf-8") as uf:
                            uf.write(json.dumps(projection_unit) + "\n")
                n_units += 1
            if written_unit_ids is not None:
                written_unit_ids.update(written_projection_ids)
        if dedupe_events is not None:
            dedupe_events.append(dedupe)
        if persist_dedupe:
            dedupe_stats = persist_ingest_dedupe(cfg, dedupe)
        else:
            dedupe_stats = {
                "exact_suppressed": len(dedupe.exact_suppressions),
                "semantic_candidates_queued": len(dedupe.semantic_candidates),
            }
        if verbose:
            for row in dedupe.exact_suppressions:
                print(
                    f"    [dedupe] exact {row['suppressed_id'][:8]} "
                    f"= {row['matched_id'][:8]} (suppressed)"
                )
            for row in dedupe.semantic_candidates:
                print(
                    f"    [dedupe?] {row['similarity']:.3f} "
                    f"{row['id_a'][:8]} ~ {row['id_b'][:8]} (queued)"
                )
        return (
            True,
            1,
            n_units,
            dedupe_stats["exact_suppressed"],
            dedupe_stats["semantic_candidates_queued"],
        )


def _index_inter_model_file(  # pylint: disable=too-many-arguments,too-many-locals
    *,
    cfg: dict,
    idx: dict,
    path: str,
    path_key: str,
    messages: list,
    models: dict,
    units_export: Path | None,
    verbose: bool,
    fmt: str = "inter_model_doc",
) -> tuple[bool, int, set[str]]:
    """Build one inter-model or Kiro steering file without pruning old rows."""
    from inter_model_index import index_inter_model_messages

    tool, source_type, author_model = {
        "kiro_steering": ("kiro", "kiro_steering", "kiro-steering-index"),
    }.get(fmt, ("inter-model", "inter_model_doc", "inter-model-index"))
    chroma_dir = idx["chroma_dir"]
    unit_ids: set[str] = set()
    try:
        n_units = index_inter_model_messages(
            path,
            messages,
            path_key=path_key,
            chroma_dir=chroma_dir,
            embed_model=models["embed_model"],
            ollama_host=models["ollama_host"],
            cfg=cfg,
            verbose=verbose,
            units_export=units_export if units_export else None,
            tool=tool,
            source_type=source_type,
            author_model=author_model,
            unit_ids_out=unit_ids,
        )
    except Exception as e:
        if verbose:
            print(f"  [skip] inter-model index failed {path}: {e}")
        return False, 0, set()
    return True, n_units, unit_ids


def _bump_counter(counters: object | None, name: str) -> None:
    if counters is None:
        return
    setattr(counters, name, int(getattr(counters, name, 0)) + 1)


def build_chunk_artifact(  # pylint: disable=too-many-arguments,too-many-locals
    *,
    chunk: dict,
    path: str,
    path_key: str,
    models: dict,
    tool: str,
    chunk_size: int,
    overlap: int,
    min_confidence: float,
    verbose: bool,
    counters: object | None = None,
    retry_sleep: bool = True,
) -> ChunkArtifact | None:
    """Transform one chunk into a complete artifact. Performs no Chroma writes."""
    text = render_chunk(chunk["messages"])
    if not text.strip():
        return None
    chunk_date = _chunk_date(chunk["messages"])
    summary = ""
    summary_embedding: list = []
    for attempt in range(3):
        try:
            _bump_counter(counters, "summarize")
            summary = summarize(
                text,
                model=models["summarize_model"],
                ollama_host=models["ollama_host"],
                deepseek_base_url=models.get(
                    "deepseek_base_url", "https://api.deepseek.com"
                ),
            )
            _bump_counter(counters, "summary_embed")
            summary_embedding = ollama_embed(
                summary,
                model=models["embed_model"],
                host=models["ollama_host"],
            )
            break
        except Exception as exc:  # pylint: disable=broad-exception-caught
            fatal_status = _provider_fatal(exc)
            if fatal_status is not None:
                _log_chunk_failure(chunk["start_offset"], "summarize", path, exc)
                raise ProviderUnavailableError(
                    f"provider refused summarize with HTTP {fatal_status}; "
                    "aborting this run instead of retrying every remaining chunk"
                ) from exc
            if verbose:
                print(f"    [warn] chunk {chunk['start_offset']} summarize failed: {exc}")
            if attempt == 2:
                _log_chunk_failure(chunk["start_offset"], "summarize", path, exc)
            if attempt < 2 and retry_sleep:
                time.sleep(5 if attempt == 0 else 10)
    else:
        return None

    distill_failed = False
    distill_response = ""
    raw_units: list = []
    for attempt in range(3):
        try:
            _bump_counter(counters, "distill")
            raw_units, distill_response = _distill_with_provenance(
                text,
                model=models["distill_model"],
                ollama_host=models["ollama_host"],
                deepseek_base_url=models.get(
                    "deepseek_base_url", "https://api.deepseek.com"
                ),
            )
            break
        except Exception as exc:  # pylint: disable=broad-exception-caught
            fatal_status = _provider_fatal(exc)
            if fatal_status is not None:
                _log_chunk_failure(chunk["start_offset"], "distill", path, exc)
                raise ProviderUnavailableError(
                    f"provider refused distill with HTTP {fatal_status}; "
                    "aborting this run instead of retrying every remaining chunk"
                ) from exc
            if verbose:
                print(f"    [warn] chunk {chunk['start_offset']} distill failed: {exc}")
            if attempt == 2:
                _log_chunk_failure(chunk["start_offset"], "distill", path, exc)
            if attempt < 2 and retry_sleep:
                time.sleep(5 if attempt == 0 else 10)
    else:
        raw_units = []
        distill_failed = True
    distill_status = (
        "degraded" if distill_failed else "empty" if not raw_units else "done"
    )

    session_meta = _chunk_session_meta(chunk["messages"], path, tool=tool)
    summary_binding = resolve_generation_binding(models["summarize_model"])
    distill_binding = resolve_generation_binding(models["distill_model"])
    message_views = render_chunk_message_views(chunk["messages"])
    selection_parameters = {
        "chunk_start": chunk["start_offset"],
        "chunk_end": chunk["end_offset"],
        "chunk_size": chunk_size,
        "overlap": overlap,
        "message_order": list(range(chunk["start_offset"], chunk["end_offset"] + 1)),
        "rendered_chunk_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "summary_consumed_view_sha256": hashlib.sha256(
            summarize_consumed_view(text).encode("utf-8")
        ).hexdigest(),
        "distill_consumed_view_sha256": hashlib.sha256(
            distill_consumed_view(text).encode("utf-8")
        ).hexdigest(),
        "summary_provider": summary_binding,
        "distill_provider": distill_binding,
    }
    provider_payload = {
        "summary": {
            **summary_binding,
            "temperature": 0.2,
            "prompt": summarize_prompt(text),
            "response_sha256": hashlib.sha256(summary.encode("utf-8")).hexdigest(),
        },
        "distill": {
            **distill_binding,
            "temperature": 0.2,
            "prompt": distill_prompt(text),
            "response_sha256": hashlib.sha256(
                distill_response.encode("utf-8")
            ).hexdigest(),
        },
    }
    recipe_spec = {
        "kind": "normal-ingest-distill-v1",
        "summary_prompt_version": "locked-summarize-prompt-v1",
        "distill_prompt_version": "locked-distill-prompt-v1",
        "summary_temperature": 0.2,
        "distill_temperature": 0.2,
        "chunk_size": chunk_size,
        "overlap": overlap,
        "summary_max_chars": 8000,
        "distill_max_chars": 8000,
    }
    units_to_add: list[tuple] = []
    embed_failed = False
    for unit_idx, raw in enumerate(raw_units):
        unit = normalize_unit(
            raw,
            source_path=path_key,
            tool=tool,
            date=chunk_date,
            min_confidence=min_confidence,
            author_model=models["distill_model"],
            start_offset=chunk["start_offset"],
            unit_index=unit_idx,
        )
        if unit is None:
            continue
        unit["source_type"] = session_meta.get("source_type", "")
        output_locator = (
            f"{path_key}#chunk:{chunk['start_offset']}:unit:{unit_idx}"
        )
        assertion_seed = (
            f"{output_locator}|"
            f"{selection_parameters['rendered_chunk_sha256']}|"
            f"{hashlib.sha256(json.dumps(raw, sort_keys=True, default=str).encode()).hexdigest()}"
        )
        with _mint_assertion_from_seed(assertion_seed):
            envelope = build_ingest_envelope(
                records=chunk["messages"],
                consumed_views=message_views,
                source_identity=path_key,
                locator_prefix=f"chunk:{chunk['start_offset']}",
                source_type=session_meta.get("source_type"),
                transformer_class="distill",
                transformer_identity=str(distill_binding["resolved_model"]),
                transformer_version="distill-v1",
                derivation_kind="distill",
                producer_class="agent",
                producer_assurance="claimed",
                selection_parameters=selection_parameters,
                provider_payload=provider_payload,
                recipe_id="normal-ingest-distill-v1",
                recipe_spec=recipe_spec,
                output_locator=output_locator,
                output_value=raw,
            )
        unit = attach_unit_provenance(unit, envelope)
        doc = unit["summary"] + " " + " ".join(unit["keywords"])
        try:
            _bump_counter(counters, "unit_embed")
            unit_embedding = ollama_embed(
                doc,
                model=models["embed_model"],
                host=models["ollama_host"],
            )
        except Exception as exc:  # pylint: disable=broad-exception-caught
            fatal_status = _provider_fatal(exc)
            if fatal_status is not None:
                _log_chunk_failure(chunk["start_offset"], "embed", path, exc)
                raise ProviderUnavailableError(
                    f"provider refused embed with HTTP {fatal_status}; "
                    "aborting this run instead of retrying every remaining chunk"
                ) from exc
            if verbose:
                print(f"    [warn] unit embed failed: {exc}")
            _log_chunk_failure(chunk["start_offset"], "embed", path, exc)
            embed_failed = True
            continue
        unit_meta = {
            "id": unit["id"],
            "type": unit["type"],
            "title": unit["title"],
            "source_path": unit["source_path"],
            "confidence": unit["confidence"],
            "timestamp": unit["timestamp"] or "",
            "tool": unit["tool"],
            "start_offset": chunk["start_offset"],
            "domain": unit["domain"],
            "author_model": unit["author_model"],
            "verifier_model": unit["verifier_model"] or "",
            **projection_metadata(unit),
            **session_meta,
        }
        units_to_add.append((unit, doc, unit_embedding, unit_meta))

    doc_id = hashlib.sha256(f"{path_key}:{chunk['start_offset']}".encode()).hexdigest()
    metadata = {
        "source_path": path_key,
        "tool": tool,
        "date": _chunk_date(chunk["messages"]),
        "message_count": len(chunk["messages"]),
        "start_offset": chunk["start_offset"],
        "end_offset": chunk["end_offset"],
        "distill_status": distill_status,
        **session_meta,
    }
    input_digest = hashlib.sha256(
        json.dumps(
            {
                "start": chunk["start_offset"],
                "end": chunk["end_offset"],
                "text": text,
                "messages": chunk["messages"],
            },
            sort_keys=True,
            default=str,
        ).encode("utf-8")
    ).hexdigest()
    complete = not distill_failed and not embed_failed
    return ChunkArtifact(
        complete=complete,
        degraded=distill_failed or embed_failed,
        start_offset=chunk["start_offset"],
        end_offset=chunk["end_offset"],
        doc_id=doc_id,
        summary=summary,
        summary_embedding=list(summary_embedding),
        metadata=metadata,
        units_to_add=units_to_add,
        input_digest=input_digest,
        distill_status=distill_status,
    )


def commit_chunk_artifact(  # pylint: disable=too-many-arguments
    artifact: ChunkArtifact,
    *,
    cfg: dict,
    idx: dict,
    path_key: str,
    path: str,
    file_hash: str,
    chroma_dir: str,
    units_export: Path | None,
    verbose: bool,
    written_unit_ids: set[str] | None = None,
    write_export: bool = True,
    persist_dedupe: bool = True,
    dedupe_events: list | None = None,
) -> tuple[bool, int, int, int, int]:
    """Commit one built artifact. Performs no model/provider work."""
    return _commit_chunk_to_stores(
        cfg=cfg,
        idx=idx,
        path_key=path_key,
        path=path,
        file_hash=file_hash,
        chroma_dir=chroma_dir,
        units_export=units_export,
        doc_id=artifact.doc_id,
        summary=artifact.summary,
        summary_embedding=artifact.summary_embedding,
        metadata=artifact.metadata,
        units_to_add=artifact.units_to_add,
        verbose=verbose,
        written_unit_ids=written_unit_ids,
        write_export=write_export,
        persist_dedupe=persist_dedupe,
        dedupe_events=dedupe_events,
    )


def _process_file_chunks(  # pylint: disable=too-many-arguments,too-many-locals
    *,
    cfg: dict,
    idx: dict,
    path: str,
    path_key: str,
    file_hash: str,
    messages: list,
    models: dict,
    tool: str,
    chroma_dir: str,
    units_export: Path | None,
    chunk_size: int,
    overlap: int,
    min_confidence: float,
    verbose: bool,
) -> _ChunkBuildResult:
    """Build a file unlocked and return its complete replacement manifest."""
    chunks = chunk_messages(messages, chunk_size, overlap)
    if verbose:
        print(f"  [index] {Path(path).name}  ({len(messages)} msgs, {len(chunks)} chunks)")

    result = _ChunkBuildResult()
    for ch in chunks:
        artifact = build_chunk_artifact(
            chunk=ch,
            path=path,
            path_key=path_key,
            models=models,
            tool=tool,
            chunk_size=chunk_size,
            overlap=overlap,
            min_confidence=min_confidence,
            verbose=verbose,
        )
        if artifact is None:
            result.completed = False
            continue
        if not artifact.complete:
            result.completed = False
        chunk_unit_ids: set[str] = set()
        try:
            ok, d_idx, d_units, d_exact, d_semantic = commit_chunk_artifact(
                artifact,
                cfg=cfg,
                idx=idx,
                path_key=path_key,
                path=path,
                file_hash=file_hash,
                chroma_dir=chroma_dir,
                units_export=units_export if units_export else None,
                verbose=verbose,
                written_unit_ids=chunk_unit_ids,
            )
        except Exception as exc:  # noqa: BLE001  # pylint: disable=broad-exception-caught
            if verbose:
                print(f"    [warn] chunk {ch['start_offset']} write failed: {exc}")
            _log_chunk_failure(ch["start_offset"], "write", path, exc)
            result.completed = False
            continue
        if not ok:
            result.completed = False
            return result
        result.summary_ids.add(artifact.doc_id)
        result.unit_ids.update(chunk_unit_ids)
        result.chunks += d_idx
        result.units += d_units
        result.exact_suppressed += d_exact
        result.semantic_queued += d_semantic
    return result


def _snapshot_reindex_rows(
    *,
    path: str,
    path_key: str,
) -> _ReindexSnapshot:
    """Snapshot only the rows a completed replacement may later prune."""
    snapshot = _ReindexSnapshot()
    with production_chroma_write_session(entrypoint="ingest.write") as _pw:
        store = _pw.store
        for source_path in dict.fromkeys([path, path_key]):
            snapshot.unit_ids[source_path] = store.ids_for_source(
                "knowledge_units", source_path
            )
            snapshot.summary_ids[source_path] = store.ids_for_source(
                "conversation_summaries", source_path
            )
    return snapshot


def _prune_completed_reindex(  # pylint: disable=too-many-arguments
    *,
    cfg: dict,
    idx: dict,
    path: str,
    path_key: str,
    file_hash: str,
    snapshot: _ReindexSnapshot,
    keep_unit_ids: set[str],
    keep_summary_ids: set[str],
    supersede_on_reindex: bool,
    verbose: bool,
) -> bool:
    """Prune the snapshotted generation only after a complete replacement."""
    from purge_locks import source_flock

    with source_flock(cfg, path_key):
        if sha256_file(path) != file_hash:
            if verbose:
                print(f"  [skip] changed during index {Path(path).name}")
            return False
        processed = load_processed(idx["processed_log"])
        if _path_is_excluded(processed, path_key):
            if verbose:
                print(f"  [skip] excluded before reindex prune {Path(path).name}")
            return False
        with production_chroma_write_session(entrypoint="ingest.write") as _pw:
            store = _pw.store
            n_units = 0
            n_summaries = 0
            tombstone_tag = f"{path_key}#{file_hash[:12]}"
            if supersede_on_reindex:
                merged: dict[str, dict] = {}
                for source_path, candidate_ids in snapshot.unit_ids.items():
                    for unit in store.preview_supersede_for_source(
                        source_path,
                        keep_ids=keep_unit_ids,
                        candidate_ids=candidate_ids,
                    ):
                        merged.setdefault(unit["id"], unit)
                _echo_neutralize_preview(
                    list(merged.values()), Path(path).name, tombstone_tag, verbose
                )
            for source_path, candidate_ids in snapshot.unit_ids.items():
                if supersede_on_reindex:
                    n_units += store.supersede_units_for_source(
                        source_path,
                        superseded_by=tombstone_tag,
                        keep_ids=keep_unit_ids,
                        candidate_ids=candidate_ids,
                    )
                else:
                    n_units += store.delete_units_for_source(
                        source_path,
                        keep_ids=keep_unit_ids,
                        candidate_ids=candidate_ids,
                    )
            for source_path, candidate_ids in snapshot.summary_ids.items():
                n_summaries += store.delete_summaries_for_source(
                    source_path,
                    keep_ids=keep_summary_ids,
                    candidate_ids=candidate_ids,
                )
            if verbose and (n_units or n_summaries):
                verb = "superseded" if supersede_on_reindex else "pruned"
                print(
                    f"  [reindex] {verb} {n_units} stale units, "
                    f"{n_summaries} stale summaries for {Path(path).name}"
                )
    return True




def _index_one_file(  # pylint: disable=too-many-arguments,too-many-locals,too-many-branches,too-many-statements,too-many-return-statements
    *,
    cfg: dict,
    idx: dict,
    path: str,
    parser,
    processed: dict,
    models: dict,
    units_export: Path | None,
    chunk_size: int,
    overlap: int,
    min_confidence: float,
    force_file: str | None,
    force_reindex: bool,
    supersede_on_reindex: bool,
    verbose: bool,
) -> tuple[str, int, int, int, int]:
    """Return status, chunks, units, exact suppressions, semantic candidates.

    status:
      - ``ignored`` — unreadable or parse-failed (does not increment files_skipped)
      - ``skipped`` — excluded / unchanged / inter-model or commit exclusion
      - ``processed`` — durable commit succeeded
    """
    try:
        file_hash = sha256_file(path)
    except OSError as e:
        if verbose:
            print(f"  [skip] cannot read {path}: {e}")
        return "ignored", 0, 0, 0, 0

    path_key = str(Path(path).expanduser().resolve())

    if _path_is_excluded(processed, path_key) or (
        file_hash in processed and processed[file_hash].get("excluded")
    ):
        if verbose:
            print(f"  [skip] excluded {Path(path).name}")
        return "skipped", 0, 0, 0, 0

    if not force_reindex:
        if file_hash in processed:
            if verbose:
                print(f"  [skip] unchanged {Path(path).name}")
            return "skipped", 0, 0, 0, 0

    fmt = detect_format(path)
    tool = TOOL_BY_FORMAT.get(fmt, fmt or "unknown")
    chroma_dir = idx["chroma_dir"]

    from incremental_jsonl import maybe_route_incremental

    routed = maybe_route_incremental(
        cfg=cfg,
        idx=idx,
        path=path,
        path_key=path_key,
        file_hash=file_hash,
        processed=processed,
        models=models,
        tool=tool,
        units_export=units_export,
        chunk_size=chunk_size,
        overlap=overlap,
        min_confidence=min_confidence,
        force_reindex=force_reindex,
        supersede_on_reindex=supersede_on_reindex,
        verbose=verbose,
        detected_format=fmt,
    )
    if routed is not None:
        return routed

    snapshot = (
        _snapshot_reindex_rows(path=path, path_key=path_key)
        if force_file
        else None
    )

    try:
        messages = parser(path)
    except Exception as e:
        if verbose:
            print(f"  [skip] parse failed {path}: {e}")
        return "ignored", 0, 0, 0, 0

    if fmt in ("inter_model_doc", "kiro_steering"):
        completed, n_units, unit_ids = _index_inter_model_file(
            cfg=cfg,
            idx=idx,
            path=path,
            path_key=path_key,
            messages=messages,
            models=models,
            units_export=units_export,
            verbose=verbose,
            fmt=fmt,
        )
        if not completed:
            if verbose and n_units == 0:
                print(
                    "  [skip] inter-model index failed or excluded "
                    f"{Path(path).name}"
                )
            return "skipped", 0, 0, 0, 0
        if snapshot is not None and not _prune_completed_reindex(
            cfg=cfg,
            idx=idx,
            path=path,
            path_key=path_key,
            file_hash=file_hash,
            snapshot=snapshot,
            keep_unit_ids=unit_ids,
            keep_summary_ids=set(),
            supersede_on_reindex=supersede_on_reindex,
            verbose=verbose,
        ):
            return "skipped", 0, n_units, 0, 0
        committed = commit_processed_index_entry(
            idx["processed_log"],
            file_hash=file_hash,
            path_key=path_key,
            chunks=0,
            units=n_units,
        )
        if not committed:
            if verbose:
                print(f"  [skip] excluded during index {Path(path).name}")
            return "skipped", 0, n_units, 0, 0
        return "processed", 0, n_units, 0, 0

    result = _process_file_chunks(
        cfg=cfg,
        idx=idx,
        path=path,
        path_key=path_key,
        file_hash=file_hash,
        messages=messages,
        models=models,
        tool=tool,
        chroma_dir=chroma_dir,
        units_export=units_export,
        chunk_size=chunk_size,
        overlap=overlap,
        min_confidence=min_confidence,
        verbose=verbose,
    )
    if not result.completed:
        return (
            "skipped",
            result.chunks,
            result.units,
            result.exact_suppressed,
            result.semantic_queued,
        )

    if snapshot is not None and not _prune_completed_reindex(
        cfg=cfg,
        idx=idx,
        path=path,
        path_key=path_key,
        file_hash=file_hash,
        snapshot=snapshot,
        keep_unit_ids=result.unit_ids,
        keep_summary_ids=result.summary_ids,
        supersede_on_reindex=supersede_on_reindex,
        verbose=verbose,
    ):
        return (
            "skipped",
            result.chunks,
            result.units,
            result.exact_suppressed,
            result.semantic_queued,
        )

    committed = commit_processed_index_entry(
        idx["processed_log"],
        file_hash=file_hash,
        path_key=path_key,
        chunks=result.chunks,
        units=result.units,
    )
    if not committed:
        if verbose:
            print(f"  [skip] excluded during index {Path(path).name}")
        return (
            "skipped",
            result.chunks,
            result.units,
            result.exact_suppressed,
            result.semantic_queued,
        )
    return (
        "processed",
        result.chunks,
        result.units,
        result.exact_suppressed,
        result.semantic_queued,
    )


def index(
    force_file: str | None = None,
    limit_files: int | None = None,
    verbose: bool = True,
    force_reindex: bool = False,
    supersede_on_reindex: bool = False,
) -> dict:
    """Run ingest under one universal mutation/capture boundary."""

    with production_writer_boundary(entrypoint="ingest.write"):
        return _index_impl(
            force_file=force_file,
            limit_files=limit_files,
            verbose=verbose,
            force_reindex=force_reindex,
            supersede_on_reindex=supersede_on_reindex,
        )


def _index_impl(
    force_file: str | None = None,
    limit_files: int | None = None,
    verbose: bool = True,
    force_reindex: bool = False,
    supersede_on_reindex: bool = False,
) -> dict:
    """Run the summary ingest. Returns a stats dict."""
    cfg = load_config()
    idx = cfg["index"]
    models = cfg["models"]
    distill_cfg = cfg.get("distill", {})
    min_confidence = float(distill_cfg.get("min_confidence", 0.6))
    units_export = Path(idx.get("units_export", "")).expanduser()
    processed = load_processed(idx["processed_log"])
    chunk_size = idx.get("chunk_size", 60)
    overlap = idx.get("chunk_overlap", 10)

    if force_file:
        targets = [{"path": str(Path(force_file).expanduser())}]
    else:
        targets = _files_from_inventory(cfg["sources"]["inventory"])

    stats = {
        "files_processed": 0,
        "files_skipped": 0,
        "chunks_indexed": 0,
        "units_indexed": 0,
        "exact_duplicates_suppressed": 0,
        "semantic_candidates_queued": 0,
    }
    seen_files = 0

    for rec in targets:
        path = rec["path"]
        parser = get_parser(path)
        if parser is None:
            if force_file:
                # An explicitly named file that no adapter recognizes is a
                # user-visible failure, not a silent no-op. `index --file` is
                # the documented session-handoff step, and reporting
                # files_processed=0 with exit 0 has silently dropped whole
                # transcripts that callers believed were ingested.
                raise UnsupportedSourceError(
                    f"No adapter recognizes {path!r} — nothing was ingested.\n"
                    f"Supported: {', '.join(sorted(TOOL_BY_FORMAT))}.\n"
                    "If this is a session transcript, its adapter is missing; "
                    "indexing it is a no-op until one exists."
                )
            continue  # unsupported / deferred — ignore, do not consume limit_files

        if limit_files is not None and seen_files >= limit_files:
            break
        seen_files += 1
        status, n_chunks, n_units, n_exact, n_semantic = _index_one_file(
            cfg=cfg,
            idx=idx,
            path=path,
            parser=parser,
            processed=processed,
            models=models,
            units_export=units_export,
            chunk_size=chunk_size,
            overlap=overlap,
            min_confidence=min_confidence,
            force_file=force_file,
            force_reindex=force_reindex,
            supersede_on_reindex=supersede_on_reindex,
            verbose=verbose,
        )
        processed = load_processed(idx["processed_log"])
        if status == "processed":
            stats["files_processed"] += 1
            stats["chunks_indexed"] += n_chunks
            stats["units_indexed"] += n_units
            stats["exact_duplicates_suppressed"] += n_exact
            stats["semantic_candidates_queued"] += n_semantic
        elif status == "skipped":
            stats["files_skipped"] += 1
        # status == "ignored": unreadable / parse-failed — prior behavior: no files_skipped

    if stats["files_processed"] > 0:
        try:
            from brief import refresh_brief_after_change

            refresh_brief_after_change(cfg)
        except Exception:
            pass

    # Compact the JSONL export to remove duplicate unit IDs from re-indexing.
    if units_export and units_export.is_file():
        removed = _deduplicate_units_export(units_export)
        if removed:
            stats["export_duplicates_removed"] = removed

    return stats
