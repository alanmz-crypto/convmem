"""Generate a read-only shared context block for multi-agent sessions."""

from __future__ import annotations

import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from chroma_readonly import (
    collection_count,
    iter_collection_metadata_rows,
)
from config import load_config
from ingest import load_processed
from query import _coverage_counts

DEFAULT_BRIEF_PATH = Path("~/.local/share/convmem/brief.md").expanduser()
CRUSH_VERIFIED_FLAG = Path("~/.local/share/convmem/mcp_crush_verified").expanduser()
KIRO_DB = Path("~/.local/share/kiro-cli/data.sqlite3").expanduser()
_INTER_MODEL_SKIP = frozenset({"README.md", "LATEST.md", "HANDOFF-TEMPLATE.md"})
_CURSOR_PROJECT_PREFIX = "home-lauer-"
_REPO_ROOT_NAMES = ("GitClones", "Projects", "WordPress")
_UPDATED_LINE = re.compile(
    r"^\*\*Updated:\*\*\s*(?P<date>\S+)(?:\s+by\s+(?P<author>.+))?\s*$",
    re.IGNORECASE,
)


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _systemd_state(unit: str) -> str:
    """Return enabled/active state or 'unknown'."""
    try:
        enabled = subprocess.run(
            ["systemctl", "--user", "is-enabled", unit],
            capture_output=True,
            text=True,
            timeout=3,
        )
        active = subprocess.run(
            ["systemctl", "--user", "is-active", unit],
            capture_output=True,
            text=True,
            timeout=3,
        )
        en = (enabled.stdout or "").strip()
        ac = (active.stdout or "").strip()
        if enabled.returncode != 0 or active.returncode != 0:
            return "unknown"
        if not en or not ac:
            return "unknown"
        return f"{en}/{ac}"
    except (OSError, subprocess.TimeoutExpired):
        return "unknown"


def _run_test_count() -> int | None:
    repo = Path(__file__).resolve().parent
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"],
            cwd=repo,
            capture_output=True,
            text=True,
            timeout=120,
        )
        combined = (proc.stdout or "") + (proc.stderr or "")
        for line in combined.splitlines():
            if line.startswith("Ran ") and " test" in line:
                return int(line.split()[1])
    except (OSError, subprocess.TimeoutExpired, ValueError):
        pass
    return None


def _watch_main_pid() -> int | None:
    """Resolve convmem-watch PID via systemctl, else pgrep (Crush-safe fallback)."""
    try:
        out = subprocess.run(
            ["systemctl", "--user", "show", "convmem-watch", "-p", "MainPID", "--value"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if out.returncode == 0:
            pid = int((out.stdout or "").strip())
            if pid > 0:
                return pid
    except (OSError, subprocess.TimeoutExpired, ValueError):
        pass
    try:
        out = subprocess.run(
            ["pgrep", "-f", "convmem.py watch"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if out.returncode == 0:
            for line in (out.stdout or "").splitlines():
                line = line.strip()
                if line:
                    return int(line)
    except (OSError, subprocess.TimeoutExpired, ValueError):
        pass
    return None


def _watch_process_memory() -> dict[str, int] | None:
    """VmPeak/VmRSS/VmData for convmem-watch main pid (from /proc)."""
    pid = _watch_main_pid()
    if pid is None:
        return None
    try:
        status = Path(f"/proc/{pid}/status").read_text(encoding="utf-8")
    except OSError:
        return None
    vals: dict[str, int] = {}
    for key in ("VmPeak", "VmRSS", "VmData"):
        for line in status.splitlines():
            if line.startswith(f"{key}:"):
                vals[key] = int(line.split()[1])
                break
    return vals or None


def _kiro_excluded(cfg: dict) -> bool:
    target = str(KIRO_DB.expanduser().resolve())
    processed = load_processed(cfg["index"]["processed_log"])
    for entry in processed.values():
        if not isinstance(entry, dict):
            continue
        if entry.get("path") == target and entry.get("excluded"):
            return True
    return False


BRIEF_METADATA_KEYS = (
    "ledger_id",
    "ledger_kind",
    "type",
    "relates_to",
    "timestamp",
    "result",
    "verification_result",
    "severity",
    "site",
    "domain",
    "title",
    "summary",
    "rationale",
    "tool",
    "source_path",
    "superseded",
    "deleted",
)
BRIEF_LEDGER_GRAPH_KEYS = (
    "id",
    "ledger_id",
    "ledger_kind",
    "type",
    "relates_to",
    "timestamp",
    "result",
    "verification_result",
    "severity",
    "site",
    "domain",
    "title",
    "summary",
)
_EXPOSURE_WINDOW_METADATA_KEY_SET = frozenset(
    {
        "ledger_id",
        "ledger_kind",
        "type",
        "relates_to",
        "timestamp",
        "result",
        "verification_result",
        "severity",
        "superseded",
    }
)
EXPOSURE_WINDOW_METADATA_KEYS = tuple(
    key for key in BRIEF_METADATA_KEYS if key in _EXPOSURE_WINDOW_METADATA_KEY_SET
)
BRIEF_PROJECTION_FIELDS = ("id",) + BRIEF_METADATA_KEYS + ("document",)
_BRIEF_METADATA_KEYS = BRIEF_METADATA_KEYS
_LEDGER_GRAPH_KEYS = BRIEF_LEDGER_GRAPH_KEYS


class _NewerFirst:
    """Sort key: newer timestamp first, then embedding id ascending."""

    __slots__ = ("ts", "eid")

    def __init__(self, meta: dict, extra: str = ""):
        self.ts = meta.get("timestamp") or extra or ""
        self.eid = meta.get("id") or ""

    def __lt__(self, other: "_NewerFirst") -> bool:
        if self.ts != other.ts:
            return self.ts > other.ts
        return self.eid < other.eid


def _retain_newest(bucket: list[dict], meta: dict, limit: int) -> None:
    if limit <= 0:
        return
    if len(bucket) < limit:
        bucket.append(meta)
        bucket.sort(key=_NewerFirst)
        return
    if _NewerFirst(meta) < _NewerFirst(bucket[-1]):
        bucket.append(meta)
        bucket.sort(key=_NewerFirst)
        del bucket[limit:]


def _retain_newest_titles(
    bucket: list[tuple[str, str, str]], ts: str, eid: str, title: str, limit: int
) -> None:
    item = {"timestamp": ts, "id": eid, "title": title}
    tagged = (ts, eid, title)
    if limit <= 0:
        return
    if len(bucket) < limit:
        bucket.append(tagged)
        bucket.sort(key=lambda t: _NewerFirst({"timestamp": t[0], "id": t[1]}))
        return
    worst = {"timestamp": bucket[-1][0], "id": bucket[-1][1]}
    if _NewerFirst(item) < _NewerFirst(worst):
        bucket.append(tagged)
        bucket.sort(key=lambda t: _NewerFirst({"timestamp": t[0], "id": t[1]}))
        del bucket[limit:]


def _copy_brief_row(meta: dict) -> dict:
    return dict(meta)


def _copy_ledger_row(meta: dict) -> dict:
    return {key: meta.get(key) for key in _LEDGER_GRAPH_KEYS if key in meta or key == "id"}


def _recent_decisions(chroma_dir: str | Path, *, limit: int = 5) -> list[dict]:
    return _aggregate_brief_chroma(chroma_dir, None)["recent_decisions"][:limit]


def _brief_row_matches_project(row: dict, project_slug: str) -> bool:
    """True if a brief ledger row plausibly belongs to the focused project slug."""
    needle = project_slug.strip().lower()
    if not needle:
        return True
    haystacks = (
        row.get("title") or "",
        row.get("document") or "",
        row.get("site") or "",
        row.get("source_path") or "",
    )
    blob = " ".join(str(h) for h in haystacks).lower()
    if needle in blob:
        return True
    # Slug tokens: pavlomassage-practice → also match pavlomassage, practice-local-pavo
    for token in needle.replace("_", "-").split("-"):
        if len(token) >= 4 and token in blob:
            return True
    return False


def _pending_decision_ingest() -> list[str]:
    """JSONL decision files on disk not yet represented in Chroma."""
    repo = Path(__file__).resolve().parent
    candidates = sorted(repo.glob("examples/decisions-*.jsonl"))
    return [str(p.relative_to(repo)) for p in candidates if p.is_file()]


def _format_age(seconds: float) -> str:
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        return f"{int(seconds // 60)}m ago"
    if seconds < 86400:
        return f"{int(seconds // 3600)}h ago"
    return f"{int(seconds // 86400)}d ago"


def _latest_handoff_info(inbox: Path) -> dict | None:
    """LATEST.md mtime + optional **Updated:** line from the pointer file."""
    latest = inbox / "LATEST.md"
    if not latest.is_file():
        return None
    try:
        stat = latest.stat()
    except OSError:
        return None
    mtime = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)
    age_s = max(0.0, (datetime.now(timezone.utc) - mtime).total_seconds())
    author = None
    date_label = None
    try:
        for line in latest.read_text(encoding="utf-8").splitlines()[:8]:
            m = _UPDATED_LINE.match(line.strip())
            if m:
                date_label = m.group("date")
                author = (m.group("author") or "").strip() or None
                break
    except OSError:
        pass
    return {
        "path": str(latest),
        "mtime_iso": mtime.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "age_label": _format_age(age_s),
        "age_seconds": age_s,
        "date_label": date_label,
        "author": author,
    }


def _recent_inter_model_titles(inbox: Path, *, limit: int = 3) -> list[str]:
    if not inbox.is_dir():
        return []
    files = [p for p in inbox.glob("*.md") if p.name not in _INTER_MODEL_SKIP]
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return [p.name for p in files[:limit]]


def _newest_inter_model_file(inbox: Path) -> tuple[str, float] | None:
    """Return (filename, mtime) for newest inter-model note (excl. LATEST/README)."""
    if not inbox.is_dir():
        return None
    newest: tuple[str, float] | None = None
    for p in inbox.glob("*.md"):
        if p.name in _INTER_MODEL_SKIP:
            continue
        try:
            mt = p.stat().st_mtime
        except OSError:
            continue
        if newest is None or mt > newest[1]:
            newest = (p.name, mt)
    return newest


def _handoff_staleness(inbox: Path) -> dict | None:
    """True when an inter-model file is newer than LATEST.md (DeepSeek stale-context alarm)."""
    latest = inbox / "LATEST.md"
    if not latest.is_file():
        return None
    try:
        latest_mtime = latest.stat().st_mtime
    except OSError:
        return None
    newest = _newest_inter_model_file(inbox)
    if not newest:
        return {"stale": False}
    name, newest_mtime = newest
    if newest_mtime <= latest_mtime:
        return {"stale": False, "newest_file": name}
    age_s = max(0.0, datetime.now(timezone.utc).timestamp() - newest_mtime)
    return {
        "stale": True,
        "newest_file": name,
        "newest_age_label": _format_age(age_s),
    }


def _recent_monitor_units(chroma_dir: str | Path, *, limit: int = 3) -> list[dict]:
    return _aggregate_brief_chroma(chroma_dir, None)["recent_monitor"][:limit]


def _mcp_registration() -> dict[str, str]:
    out: dict[str, str] = {}
    cursor_mcp = Path("~/.cursor/mcp.json").expanduser()
    if cursor_mcp.is_file():
        try:
            data = json.loads(cursor_mcp.read_text(encoding="utf-8"))
            servers = data.get("mcpServers") or {}
            out["cursor"] = "registered" if "convmem" in servers else "missing"
        except (OSError, json.JSONDecodeError):
            out["cursor"] = "unknown"
    else:
        out["cursor"] = "no config"

    crush_cfg = Path("~/.config/crush/crush.json").expanduser()
    if crush_cfg.is_file():
        try:
            data = json.loads(crush_cfg.read_text(encoding="utf-8"))
            mcp = data.get("mcp") or {}
            out["crush"] = "registered" if "convmem" in mcp else "missing"
        except (OSError, json.JSONDecodeError):
            out["crush"] = "unknown"
    else:
        out["crush"] = "no config"

    if CRUSH_VERIFIED_FLAG.is_file():
        out["crush_live"] = CRUSH_VERIFIED_FLAG.read_text(encoding="utf-8").strip() or "verified"
    else:
        out["crush_live"] = "unverified"

    out["stdio"] = "verified (Cursor dev machine 2026-06-22)"
    return out


def resolve_project_from_path(path: str) -> tuple[str, str] | None:
    """Map a source path to (slug, repo_path). slug is the repo directory name."""
    try:
        p = Path(path).expanduser().resolve()
    except (OSError, ValueError):
        p = Path(path).expanduser()

    parts = p.parts
    if ".cursor" in parts and "projects" in parts:
        idx = parts.index("projects")
        if idx + 1 < len(parts):
            folder = parts[idx + 1]
            if folder.startswith(_CURSOR_PROJECT_PREFIX):
                rest = folder[len(_CURSOR_PROJECT_PREFIX) :]
                for root in _REPO_ROOT_NAMES:
                    prefix = f"{root}-"
                    if rest.startswith(prefix):
                        slug = rest[len(prefix) :]
                        repo = Path.home() / root / slug
                        return slug, str(repo)
                return rest.replace("-", "_"), ""

    s = str(p)
    for root in _REPO_ROOT_NAMES:
        needle = f"/{root}/"
        if needle in s:
            slug = s.split(needle, 1)[1].split("/")[0]
            if slug and slug not in (".crush", ".git"):
                return slug, str(Path.home() / root / slug)

    return None


def _inventory_path(cfg: dict) -> Path:
    raw = cfg.get("sources", {}).get("inventory") or "~/.local/share/convmem/inventory.jsonl"
    return Path(raw).expanduser()


def _load_inventory_records(cfg: dict) -> list[dict]:
    path = _inventory_path(cfg)
    if not path.is_file():
        return []
    rows: list[dict] = []
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except OSError:
        return []
    return rows


def _empty_project_bucket(slug: str, repo: str) -> dict:
    return {
        "slug": slug,
        "repo_path": repo,
        "indexed_sources": 0,
        "newest_source_at": "",
        "newest_source_mtime": 0.0,
        "newest_source_path": "",
        "formats": set(),
        "unit_titles": [],
        "knowledge_units": 0,
    }


def _seed_projects_from_inventory(cfg: dict | None, filt: str) -> dict[str, dict]:
    by_slug: dict[str, dict] = {}
    if not cfg:
        return by_slug
    for row in _load_inventory_records(cfg):
        src = row.get("path") or ""
        resolved = resolve_project_from_path(src)
        if not resolved:
            continue
        slug, repo = resolved
        if filt and filt not in slug.lower():
            continue
        try:
            mtime = Path(src).stat().st_mtime
            mtime_iso = datetime.fromtimestamp(mtime, tz=timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            )
        except OSError:
            mtime = 0.0
            mtime_iso = ""
        bucket = by_slug.setdefault(slug, _empty_project_bucket(slug, repo))
        if repo and not bucket.get("repo_path"):
            bucket["repo_path"] = repo
        bucket["indexed_sources"] += 1
        fmt = row.get("format") or ""
        if fmt:
            bucket["formats"].add(fmt)
        if mtime >= bucket["newest_source_mtime"]:
            bucket["newest_source_mtime"] = mtime
            bucket["newest_source_at"] = mtime_iso
            bucket["newest_source_path"] = src
    return by_slug


def _iter_brief_rows(chroma_dir: str | Path):
    return iter_collection_metadata_rows(
        chroma_dir,
        "knowledge_units",
        metadata_keys=_BRIEF_METADATA_KEYS,
        include_document=True,
    )


def _finalize_projects(by_slug: dict[str, dict], limit: int) -> list[dict]:
    out: list[dict] = []
    for slug, bucket in by_slug.items():
        repo_path = bucket.get("repo_path") or ""
        agents_md = str(Path(repo_path) / "AGENTS.md") if repo_path else ""
        agents_exists = bool(repo_path and Path(agents_md).is_file())
        titles = bucket.get("unit_titles") or []
        recent_titles = [t[2] for t in titles]
        newest_age = (
            _format_age(
                max(
                    0.0,
                    datetime.now(timezone.utc).timestamp()
                    - bucket.get("newest_source_mtime", 0.0),
                )
            )
            if bucket.get("newest_source_mtime")
            else "unknown"
        )
        out.append(
            {
                "slug": slug,
                "repo_path": repo_path,
                "agents_md": agents_md if agents_exists else "",
                "indexed_sources": bucket.get("indexed_sources", 0),
                "knowledge_units": bucket.get("knowledge_units", 0),
                "newest_source_at": bucket.get("newest_source_at") or "",
                "newest_source_age": newest_age,
                "newest_source_path": bucket.get("newest_source_path") or "",
                "formats": sorted(bucket.get("formats") or []),
                "recent_unit_titles": recent_titles,
                "entry_search": f"{slug} handoff next steps",
            }
        )
    out.sort(key=lambda r: r.get("newest_source_at") or "", reverse=True)
    return out[:limit] if limit else out


def _aggregate_brief_chroma(
    chroma_dir: str | Path,
    cfg: dict | None,
    *,
    project_filter: str = "",
    project_limit: int = 12,
    decision_limit: int = 5,
    monitor_limit: int = 3,
) -> dict:
    """One projected metadata pass for decisions, monitor, projects, unresolved."""
    filt = project_filter.strip().lower()
    by_slug = _seed_projects_from_inventory(cfg, filt)
    decisions: list[dict] = []
    monitor: list[dict] = []
    ledger_rows: list[dict] = []
    for meta in _iter_brief_rows(chroma_dir):
        kind = str(meta.get("ledger_kind") or "").strip().lower()
        if kind == "decision":
            _retain_newest(decisions, _copy_brief_row(meta), decision_limit)
        if meta.get("tool") == "convmem-monitor":
            _retain_newest(monitor, _copy_brief_row(meta), monitor_limit)
        src = meta.get("source_path") or ""
        resolved = resolve_project_from_path(src)
        if resolved:
            slug, repo = resolved
            if not (filt and filt not in slug.lower()):
                bucket = by_slug.setdefault(slug, _empty_project_bucket(slug, repo))
                bucket["knowledge_units"] = bucket.get("knowledge_units", 0) + 1
                title = (meta.get("title") or "").strip()
                if title:
                    if not (
                        filt
                        and not _brief_row_matches_project(
                            {"title": title, "document": title}, slug
                        )
                    ):
                        _retain_newest_titles(
                            bucket.setdefault("unit_titles", []),
                            meta.get("timestamp") or "",
                            meta.get("id") or "",
                            title,
                            3,
                        )
        if meta.get("superseded") is True:
            continue
        lid = (meta.get("ledger_id") or "").strip()
        if lid:
            ledger_rows.append(_copy_ledger_row(meta))
    from unresolved import list_unresolved_from_metadata

    try:
        unresolved = list_unresolved_from_metadata(ledger_rows)
        unresolved_count: int | None = len(unresolved)
    except Exception:
        unresolved = None
        unresolved_count = None
    return {
        "recent_decisions": decisions,
        "recent_monitor": monitor,
        "projects": _finalize_projects(by_slug, project_limit),
        "unresolved_count": unresolved_count,
        "unresolved": unresolved,
    }


def gather_project_activity(
    cfg: dict,
    chroma_dir: str | Path,
    *,
    project_filter: str = "",
    limit: int = 12,
) -> list[dict]:
    """Per-repo rollup from inventory paths + Chroma unit metadata."""
    return _aggregate_brief_chroma(
        chroma_dir,
        cfg,
        project_filter=project_filter,
        project_limit=limit,
    )["projects"]


def gather_brief_payload(
    cfg: dict | None = None,
    *,
    with_tests: bool = False,
    project: str = "",
) -> dict:
    """Structured brief for MCP and programmatic callers."""
    data = gather_brief_data(cfg, with_tests=with_tests, project=project)
    stale = data.get("handoff_staleness") or {}
    data["coordination"] = {
        "protocol_ledger": "dec_prop_20260623_161428_c311",
        "mcp_tools": ["brief", "search", "search_fast", "ask", "related", "stats"],
        "mcp_writes": False,
        "durable_writes": "CLI only: record -i → record --approve-last (auto-indexes)",
        "session_close": "SESSION-CLOSE-RECORD.md — --relates-to must be ledger id (dec_prop_…/obs_…); never topic slugs like system-maintenance; fallback c311",
        "inter_model_pointer": str(
            (Path(__file__).resolve().parent / "docs" / "inter-model" / "LATEST.md")
        ),
    }
    data["stale_handoff"] = bool(stale.get("stale"))
    if stale.get("newest_file"):
        data["stale_handoff_file"] = stale["newest_file"]
    return data


def gather_brief_data(
    cfg: dict | None = None,
    *,
    with_tests: bool = False,
    project: str = "",
) -> dict:
    if cfg is None:
        cfg = load_config()
    total_inv, indexed, pending, deferred = _coverage_counts(cfg)
    test_count = _run_test_count() if with_tests else None
    chroma_dir = cfg["index"]["chroma_dir"]

    inbox = Path(__file__).resolve().parent / "docs" / "inter-model"
    proj_limit = 12 if project.strip() else 8

    # Layer 2 standing checks due at session start. Lazy import: doctor imports
    # from brief at module load, so a top-level import here would be circular.
    try:
        from doctor import standing_register_status

        open_n, due = standing_register_status(cfg)
        standing_due = {"open": open_n, "due": due}
    except Exception:
        standing_due = None

    project_slug = project.strip()
    agg = _aggregate_brief_chroma(
        chroma_dir,
        cfg,
        project_filter=project,
        project_limit=proj_limit,
    )
    recent_decisions = agg["recent_decisions"]
    recent_monitor = agg["recent_monitor"]
    if project_slug:
        recent_decisions = [
            row
            for row in recent_decisions
            if _brief_row_matches_project(row, project_slug)
        ]
        recent_monitor = [
            row
            for row in recent_monitor
            if _brief_row_matches_project(row, project_slug)
        ]
    unresolved_count = agg["unresolved_count"]

    payload = {
        "generated_at": _now_iso(),
        "units": collection_count(chroma_dir, "knowledge_units"),
        "summaries": collection_count(chroma_dir, "conversation_summaries"),
        "inventory": {
            "total": total_inv,
            "indexed": indexed,
            "pending": pending,
            "deferred": deferred,
        },
        "tests": test_count,
        "rerank": (cfg.get("query") or {}).get("rerank"),
        "services": {
            "watch": _systemd_state("convmem-watch"),
            "refine": _systemd_state("convmem-refine"),
            "monitor_timer": _systemd_state("convmem-monitor.timer"),
        },
        "kiro_db_excluded": _kiro_excluded(cfg),
        "mcp": _mcp_registration(),
        "watch_memory_kb": _watch_process_memory(),
        "recent_decisions": recent_decisions,
        "recent_monitor": recent_monitor,
        "pending_decision_files": _pending_decision_ingest(),
        "inter_model_inbox": inbox,
        "unresolved_count": unresolved_count,
        "standing_due": standing_due,
        "latest_handoff": _latest_handoff_info(inbox),
        "handoff_staleness": _handoff_staleness(inbox),
        "recent_inter_model_titles": _recent_inter_model_titles(inbox),
        "projects": agg["projects"],
    }
    if project_slug:
        payload["brief_scope"] = "project"
        payload["focus_project"] = project_slug
        payload["recent_inter_model_titles"] = []
        payload["answer_from"] = (
            "Project-state answers must come from projects[] and files in this repo. "
            "Do not call search_fast for Continue IDE, VS Code extensions, Docker Compose, "
            "or Composer unless the user explicitly asked. Do not invent search queries."
        )
        payload["search_policy"] = (
            "search_fast queries must include this project slug or user-stated terms. "
            "Forbidden for unprompted project-state: Continue, VS Code extension, Docker Compose plugin, Compose UI."
        )
        if project_slug.lower() == "convmem":
            payload["project_slug_warning"] = (
                "project=convmem only when cwd IS ~/Projects/convmem. "
                "If cwd is another repo, use its directory basename (e.g. comfyuiimprov)."
            )
    return payload


def _clip(text: str, n: int = 120) -> str:
    s = (text or "").replace("\n", " ").strip()
    if len(s) <= n:
        return s
    return s[: n - 1].rstrip() + "…"


def render_brief_markdown(data: dict) -> str:
    inv = data["inventory"]
    tests_line = (
        str(data["tests"]) + " passing"
        if data.get("tests") is not None
        else "unknown (run: convmem brief --with-tests)"
    )
    mcp = data.get("mcp") or {}

    lines = [
        "# CONVMEM BRIEF",
        "",
        f"Generated: {data['generated_at']}",
        "",
        "## State",
        f"- Corpus: **{data['units']}** units, **{data['summaries']}** summaries",
        f"- Inventory: {inv['indexed']} indexed, {inv['pending']} pending, {inv['deferred']} deferred",
        f"- Tests: {tests_line}",
        f"- rerank: {data.get('rerank')}",
        f"- Services: watch={data['services']['watch']} refine={data['services']['refine']} monitor.timer={data['services']['monitor_timer']}",
        f"- Kiro live DB excluded: **{'yes' if data['kiro_db_excluded'] else 'no'}**",
        f"- MCP: cursor={mcp.get('cursor', '?')} crush={mcp.get('crush', '?')} crush_live={mcp.get('crush_live', '?')}",
        f"- MCP stdio: {mcp.get('stdio', 'unknown')}",
    ]
    wm = data.get("watch_memory_kb") or {}
    if wm:
        peak_m = wm.get("VmPeak", 0) / (1024 * 1024)
        rss_m = wm.get("VmRSS", 0) / (1024 * 1024)
        lines.append(
            f"- Watch memory: VmPeak **{peak_m:.2f}G**, VmRSS **{rss_m:.2f}G** (from /proc; not ps)"
        )
    handoff = data.get("latest_handoff")
    if handoff:
        who = f", {handoff['author']}" if handoff.get("author") else ""
        when = handoff.get("date_label") or handoff.get("mtime_iso", "")[:10]
        stale = " **(stale)**" if handoff.get("age_seconds", 0) > 86400 else ""
        lines.append(
            f"- LATEST.md: updated **{handoff['age_label']}** ({when}{who}){stale}"
        )
    titles = data.get("recent_inter_model_titles") or []
    if titles:
        lines.append(f"- Recent inter-model: {', '.join(titles)}")
    ur_count = data.get("unresolved_count")
    if ur_count is not None:
        lines.append(f"- Unresolved observations: **{ur_count}** (run `convmem unresolved`)")
    sd = data.get("standing_due") or {}
    if sd.get("due"):
        ids = ", ".join(r["id"] for r in sd["due"])
        lines.append(
            f"- **⚠ STANDING CHECKS DUE ({len(sd['due'])}):** {ids} (run `convmem doctor`)"
        )
    stale = data.get("handoff_staleness") or {}
    if stale.get("stale"):
        lines.append(
            f"- **⚠ STALE HANDOFF:** `LATEST.md` is older than `{stale['newest_file']}` "
            f"(newest {stale.get('newest_age_label', '?')}) — read newest file or update LATEST"
        )
    lines.append(f"- brief @ `{data['generated_at']}`")

    lines.extend(["", "## Projects (indexed activity)"])
    projects = data.get("projects") or []
    if not projects:
        lines.append("- (none matched)")
    else:
        for p in projects:
            slug = p.get("slug", "?")
            repo = p.get("repo_path") or ""
            age = p.get("newest_source_age") or "?"
            src_n = p.get("indexed_sources", 0)
            units = p.get("knowledge_units", 0)
            entry = p.get("entry_search") or slug
            lines.append(
                f"- **{slug}** — {src_n} sources, {units} units, last activity {age}"
            )
            if repo:
                lines.append(f"  - repo: `{repo}`")
            if p.get("agents_md"):
                lines.append(f"  - agents: `{p['agents_md']}`")
            if p.get("newest_source_path"):
                lines.append(f"  - newest: `{_clip(p['newest_source_path'], 90)}`")
            lines.append(f"  - try: `search_fast(\"{entry}\")`")

    lines.extend(["", "## Active P0"])

    p0: list[str] = []
    if stale.get("stale"):
        p0.append(
            f"Update LATEST.md or read `{stale['newest_file']}` before cross-model handoff"
        )
    watch_state = str(data["services"].get("watch") or "")
    watch_active = not watch_state.startswith("disabled")
    # Watch hard-skips kiro-cli/data.sqlite3 (watch._LIVE_WATCH_SKIP_SUFFIXES); the
    # processed.json exclude is hygiene only when watch is already running.
    if not data["kiro_db_excluded"] and not watch_active:
        p0.append("Apply Kiro sqlite exclude before re-enabling watch")
    if inv["pending"] > 0:
        p0.append(f"Ingest {inv['pending']} pending inventory file(s)")
    if mcp.get("crush_live") == "unverified":
        p0.append("Crush live MCP session test (search_fast from agent)")
    if watch_state.startswith("disabled"):
        if data["kiro_db_excluded"]:
            p0.append("Re-enable convmem-watch after Crush MCP verify")
        else:
            p0.append("Do not re-enable watch until Kiro DB is excluded")

    if not p0:
        lines.append("- (none)")
    else:
        for i, item in enumerate(p0, 1):
            lines.append(f"{i}. {item}")

    lines.extend(["", "## Recent Decisions"])
    decisions = data.get("recent_decisions") or []
    if not decisions:
        pending_files = data.get("pending_decision_files") or []
        if pending_files and not decisions:
            lines.append(
                f"- (none in ledger — run: convmem add --file {pending_files[0]} --upsert)"
            )
        else:
            lines.append("- (none in ledger)")
    else:
        for d in decisions:
            lid = d.get("ledger_id") or d.get("id") or "?"
            title = d.get("title") or _clip(d.get("summary", ""), 80)
            rationale = _clip(d.get("rationale") or d.get("summary") or "", 100)
            lines.append(f"- **{lid}**: {title}")
            if rationale:
                lines.append(f"  - Rationale: {rationale}")

    lines.extend(["", "## Recent Monitor"])
    monitor = data.get("recent_monitor") or []
    if not monitor:
        lines.append("- (none)")
    else:
        for m in monitor:
            title = (m.get("title") or "").strip() or _clip(m.get("summary", ""), 100)
            result = m.get("result") or ""
            site = m.get("site") or ""
            suffix = f" [{result}]" if result else ""
            lines.append(f"- {site}: {_clip(title, 100)}{suffix}")

    lines.extend(
        [
            "",
            "## Open Risks",
            "- Watch OOM if live DBs indexed (Kiro sqlite, Cursor store.db) — both skipped in watch",
            "- Watch RSS high (~3–4G) — little headroom under MemoryMax=4G",
            "- Crush MCP live path still unverified until `mcp_crush_verified` flag set",
            "",
            "## Before Working",
            "- Protocol: `brief` → `convmem ask` → `LATEST.md` → `convmem record -i` → `convmem record --approve-last`",
            "- Session close: `SESSION-CLOSE-RECORD.md` — `convmem record --relates-to … --summary … --rationale … --author …`; then `--approve-last`; never `record` alone or fake flags",
            "- Agent roles: `docs/AGENT-ROLES.md`",
            "- Use `convmem search` / MCP `search_fast` for targeted prior art",
            "- Drafts are not searchable until `record --approve-last`",
            "",
            "## Inter-Model Inbox",
            f"- `{data.get('inter_model_inbox', 'docs/inter-model')}/`",
            "",
        ]
    )
    return "\n".join(lines)


def write_brief(
    cfg: dict | None = None,
    *,
    out_path: Path | str | None = None,
    with_tests: bool = False,
    quiet: bool = False,
) -> Path:
    if cfg is None:
        cfg = load_config()
    path = Path(out_path or DEFAULT_BRIEF_PATH).expanduser()
    data = gather_brief_data(cfg, with_tests=with_tests)
    text = render_brief_markdown(data)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    if not quiet:
        print(f"Brief written → {path}", file=sys.stderr)
    return path


def refresh_brief_after_change(cfg: dict | None = None) -> None:
    """Lightweight auto-refresh after index/refine/monitor (no test run)."""
    try:
        write_brief(cfg, with_tests=False, quiet=True)
    except Exception as e:
        print(f"[brief] refresh skipped: {e}", file=sys.stderr)
