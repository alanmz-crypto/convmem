# convmem — Local knowledge corpus protocol

convmem is a local-first knowledge corpus on this machine. It indexes AI chat transcripts, security observations, and decision records into ChromaDB (Ollama nomic-embed-text embeddings). CLI and MCP access. Read-only to agents by default.

**Do not ask "what is convmem" or suggest alternatives.** It exists on this machine. Use it.

**Wired surfaces:** Cursor, Codex, Kiro, Continue, Copilot CLI, opencode, Crush, and **Claude Code** (user memory `~/.claude/CLAUDE.md` + user-scope MCP `mcpServers.convmem` in `~/.claude.json`; `convmem doctor` reports `mcp_claude`).

---

## Tier A — shell-capable (Cursor, Codex, Kiro, Continue-with-Bash, Crush, Copilot CLI, Claude Code)

<!-- TIER_A_START -->

1. **`convmem doctor`** — the only tool call in the first batch. Wait for exit 0 before
   calling anything else.
2. **`convmem brief --stdout-only`** — session orientation: corpus state, recent decisions, monitor results, unresolved count.
3. **`convmem unresolved`** — check open observations. Add `--site <hostname>` for client-specific issues (e.g. `--site staging2.willowyhollow.com`). For multiple sites, prefer **separate** `convmem unresolved --site …` calls (or one call without `--site`). Avoid `echo` separators unless comparing output side-by-side.
4. **Before answering history/architecture questions:** use `convmem "search query"` or `convmem ask "question"` to ground responses in the ledger.

**Branching (convmem prod — Always-Available GitHub Fallback):** After doctor/brief/unresolved, when cwd is `~/Projects/convmem`, run `git branch --show-current`. **Do not edit tracked files on `main`** (no single-file typo exception). Before the first tracked-file edit: `convmem work start <feat|fix|docs|plan|wip> <slug>` (or resume with `convmem work resume <branch>`). Taxonomy `feat|fix|docs|plan|wip/YYYY-MM-DD-slug` — validate before switch. Push with an **explicit** refspec (`git push -u origin "$branch:refs/heads/$branch"`); never `git push -u origin HEAD`. **Push immediately after every commit** — the remote branch is the fallback. Graduate `wip/` with `git branch -m` before review — never merge `wip/` directly. Pre-commit/pre-push reject work on `main`; local `CONVMEM_SKIP_MAIN_HOOK` is hook-skip/audit only (not GitHub authz; never in agent instructions). Agents never merge, force-push, or push `main` — Ryan owns merges (PR required when GitHub protection allows). **Single active writer:** use `--worktree` if contested; do not switch a shared checkout under another agent. Handoff: branch name + `git log origin/main..HEAD --oneline` + push status.

**Forward announcement (required at phase completion).** When finishing a phase (implementation, plan, verification, review), end with:

    I finished: [phase name]
    Next step:  [what needs to happen next]
    Next lane:  [who does it — e.g. Kiro, Cursor, Ryan]
    See my work: [single easiest path to evaluate — PR URL, file path, or diff command]

"See my work" must be the lowest-effort viewing path — a PR diff URL, a single file to read, or a targeted `git diff` command. Not a branch name and SHA that requires spelunking. Trivial work (one-line fix, single ack) scales down to one sentence naturally.

Full rules: `docs/plans/ARCHITECTURE-always-github-fallback.md`.

**Push immediately after commit.** Do not wait for Ryan to say "push." The remote branch IS the backup — unpushed work is unrecoverable. Use explicit `"$branch:refs/heads/$branch"` on first push. Commit often, push every commit.

**DB backups (WordPress repos).** Before any DB mutation (`eval-file`, direct SQL, sync scripts) — take a `practice_backup` or `mysqldump`. This is operational safety for content, separate from git.

**Git hygiene (convmem prod — Git Hygiene Baseline):** After cloning `~/Projects/convmem`, run `bash scripts/install-repo-config.sh` (sets `core.hooksPath`, `pull.ff only`, `rerere.enabled`, `blame.ignoreRevsFile` — repo-local only). Feature branch update: `git fetch origin && git rebase origin/main`. Clean `main`: `git pull --ff-only`. If plain `git pull` fails under `pull.ff only`, histories diverged — stop and inspect (do not force a merge pull). When rerere reuses a resolution, review with `git rerere diff` (textual reuse ≠ semantic correctness). Milestone closures: propose `vX.Y.Z-<slug>` or `milestone/<slug>` in handoff; Ryan tags; work from a tag via `git switch -c <branch> <tag>` (no fixed `recovery/` prefix). Stash: may stash **own** uncommitted work to unblock a branch switch; must **not** stash Ryan’s unrelated dirty files without execution-plan authorization (`git stash push -u -m "<reason>" -- <paths>` + handoff note if authorized). Full rules: `docs/plans/git-hygiene-baseline.md`.

**Codex-specific:** if `convmem ask` fails with a network error (sandbox blocks localhost), retry with:
```
bash -lc 'convmem ask "your question here"'
```
The `-l` flag sources `~/.zshrc`/`~/.bashrc` where Ollama's PATH is set. For permanent access in the convmem repo: `cp .codex/config.toml.example .codex/config.toml` to enable `network_access = true`.

**Session tracking (default — no hindsight test):** Assume **this conversation is worth tracking**. Two **separate** ingest targets — do **not** confuse them:

| Track | What it captures | When |
|-------|------------------|------|
| **A — Session chat** | What the model *said and did* in chat | **Every** substantive handoff |
| **B — Log artifact** | A `logs/*.md` file the model wrote | Only if such a file was created/updated |

Watch auto-indexes session files after debounce (~90s). Agents still **nudge both** before handoff so the next model is not waiting.

**A — Index your session chat (required at handoff):**

```bash
# Crush (willowyhollow-practice):
convmem index --file ~/WordPress/willowyhollow-practice/.crush/crush.db

# Kiro — this session's transcript (use latest sess_* under cwd or $HOME/.kiro/sessions):
convmem index --file ~/.kiro/sessions/<session-dir>/sess_<id>/messages.jsonl

# Cursor — agent transcript for this chat:
convmem index --file ~/.cursor/projects/<project>/agent-transcripts/<uuid>/<uuid>.jsonl

# Codex — full session (not history.jsonl prompts-only):
convmem index --file ~/.codex/sessions/<YYYY>/<MM>/<DD>/rollout-<timestamp>-<id>.jsonl

# Copilot CLI — session events (not session-store.db / session.db):
convmem index --file ~/.copilot/session-state/<uuid>/events.jsonl
```

Indexing **only** a `logs/*.md` file does **not** ingest your chat. If you wrote a log, run **A and B**.

**B — Index log artifacts (if you wrote `logs/*.md`):**

```bash
bash ~/Projects/convmem/scripts/sync-willowyhollow-findings-index.sh   # findings log
bash ~/Projects/convmem/scripts/sync-willowyhollow-audit-index.sh      # Codex audit log
# one command for A+B (Crush + Kiro + Codex rollout + findings + audit):
bash ~/Projects/convmem/scripts/sync-willowyhollow-handoff.sh
```

**Ryan phrasebook:**

| Ryan says | Means |
|-----------|--------|
| **Ingest your chat** / **index your session** | Track **A** only |
| **Index the log** | Track **B** only |
| **Ingest everything** / **full handoff** | **A then B** (both if a log exists) |
| **Find a stopping point** / **good stopping point** / **let's wrap up** / **park it** | **Soft close** — stabilize work, push commits, verbal summary, Track A. **No record block.** See `SESSION-CLOSE-RECORD.md § Stopping point`. |
| **Closing** / **end session** / **record block** | **Hard close** — Track A + output `convmem record` block for Ryan to run. |

Avoid **"index what you wrote"** alone — models treat that as the markdown log, skip chat.

**Crush:** you are **Crush lane** even when running Qwen / DeepSeek / Kimi weights. Say **Crush found it** — not the provider name. Default Crush model for ConvMem: **Qwen3.7-Max** (architecture / planning / synthesis); **Kimi K2.7 Code** only for intensive code generation. If `mcp_convmem_*` hangs or returns `context canceled`, cancel and use shell `convmem "…"` / `convmem ask "…"`.

1. **Search first** — `convmem "topic"` / `ask` before re-deriving from scratch.
2. **`record`** — one closing **conclusion** only (not per-finding). Detail stays in chat ingest + indexed logs.

**Project goal awareness (STATUS files).** If you are working on an active arc that has a `docs/plans/STATUS-<slug>.md`, **read it before starting work**. Your first substantive response must state:

> "**Goal:** [product goal]. **My role:** [what I'm here to do]. **The system currently:** [what exists and what's missing]. **Next action:** [the specific thing that advances the arc toward done]."

STATUS files are **arc briefs** — they give you a mental landscape of the design: how pieces connect, what's built, what's a stub, what doesn't exist yet, your exact role, and what "done" looks like for the whole arc (not just your slice). A model that finishes its slice but loses sight of the arc-level finish line is failing.

**When to create STATUS:** When authoring a new arc (ARCHITECTURE + EXECUTION plan), create a matching `docs/plans/STATUS-<slug>.md` using `STATUS-judgebench.md` as the template (10-section structure). The slug is kebab-case and must match the arc's ARCHITECTURE filename suffix (e.g. `ARCHITECTURE-shadow-ledger-phase0.md` → `STATUS-shadow-ledger-phase0.md`). In the same commit or PR, add the new file to the **Active STATUS files** list below and in `AGENTS.md`. If surfaces are regenerated in the same branch, the list propagates automatically; otherwise note the list update is needed.

**When to update STATUS:** After any milestone changes state (PR merged, gate passed, new blocker discovered), update the STATUS file in the same commit or as a follow-up. Stale STATUS is worse than no STATUS.

**How to update (departure protocol):** The STATUS file must remain a *current-state snapshot* — never a log, diary, or changelog. When updating:
- **Overwrite sections 3–6** to reflect reality now (move "on branch" → "on `main`", delete completed checklist items, rewrite "Your Role" for the *next* model).
- **Do not append session narrative.** Your work details belong in Track A (session ingest), not here.
- **One line in the Update Log** — date, name, milestone-level change.
- **The test:** Could a fresh model read *only* this file and orient itself? If your update makes that harder, undo it.

**Active STATUS files:**
- `docs/plans/STATUS-judgebench.md` — JudgeBench semantic calibration v1
- `docs/plans/STATUS-r2b-capture-auth.md` — R2b capture authorization
- `docs/plans/STATUS-shadow-ledger-phase0.md` — Shadow Ledger Phase 0 delta capture
- `docs/plans/STATUS-chroma-reconcile-tier-l.md` — Chroma Reconcile Tier L (**closed GREEN**; reference only)
- `docs/plans/STATUS-complete-data-backup-correction-v2.md` — Complete-data backup correction v2
- `docs/plans/STATUS-codeql-complex-therapy.md` — CodeQL Complex Therapy merge protection (**closed/PASS**; reference only)
- `docs/plans/STATUS-pinwheel-pytest-ci.md` — Pinwheel Pytest CI (**closed**; reference only)
- `docs/plans/STATUS-agent-run-ledger.md` — Runway Ledger Agent Run identity tracking (**closed**; reference only)
- `docs/plans/STATUS-dependability-provenance.md` — Dependability and provenance Trust Arc (**T3 closed**; later gates deferred)
- `docs/plans/STATUS-recovery-authority.md` — Recovery Authority T1/T2 execution (**landed via PR #234 and #236; T3 not authorized**)
- `docs/plans/STATUS-naturalistic-product-value.md` — Naturalistic ConvMem product-value evaluation (**G1–G5 landed; G6 Ryan-gated**)
- `docs/plans/STATUS-codex-jsonl-production-integration.md` — Arc Codex Kiro JSONL incremental production integration (**implementation merged; production canary Ryan-gated**)
- `docs/plans/STATUS-claude-watch-parity.md` — Claude on-demand indexing and rejected automatic capture (**closed `NO_GATE2_ROUTE`; reference only**)

**Cross-arc rollup:** `docs/inter-model/STATUS.md` — active vs closed arcs (not a per-arc brief).

**Arc identity (required).** Every session working on a named arc must **know and state its arc codename** (e.g. "Arc Trapdoor Hunt", "Arc Pinwheel Pytest CI"). Rules:

1. **Discover:** At session start (after Tier A), determine your arc from: Ryan's prompt, the branch name, the STATUS file, or the handoff doc. If none of these name an arc, **ask Ryan** before doing substantive work: *"Which arc is this session working on?"*
2. **Carry:** Once known, include `**Arc: <codename>**` in your first substantive response (after the Goal/Role/System/Next block if present).
3. **Stamp:** Include the arc codename in every TL;DR, forward announcement, and handoff doc header. Format: `[Arc <codename>]` prefix or inline bold.
4. **Boundary:** Do not perform work that belongs to a *different* named arc without Ryan's explicit authorization. If a task crosses arc boundaries, flag it: *"This touches Arc X but I'm working Arc Y — authorize?"*
5. **No arc = say so.** If the work is not part of any named arc (ad-hoc fix, routine maintenance), state `**Arc: none (ad-hoc)**` once and proceed normally.

Known arc codenames (update when new arcs are named):

| Codename | Subject | State |
|----------|---------|-------|
| Trapdoor Hunt | Dependability & provenance trust architecture | Active — review complete, awaiting lock |
| Full Fathom Five | Parent five-arc dependability roadmap (FF1–FF5) | Active — parent frozen |
| CI Kryptonite | Behavioral CI merge gate | **Closed** (PR #187 + #189) |
| Pinwheel Pytest CI | Reproducible pytest CI | **Closed** (#191 + disposable controls) |
| CodeQL Complex Therapy | CodeQL merge protection | **Closed** — technical controls PASS; Ryan-owned recurring attestation |
| Runway Ledger | Agent Run identity tracking | **CLOSED** — core implementation merged (#215); hook-enable soak passed and #216 merged; other clients are future slices, not unfinished Runway work |
| Codex | Kiro JSONL incremental production integration | Planning — Kiro review next |
| Recovery Authority | Provenance-aware complete-data recovery and rollback continuity | Active — T1 landed (PR #234); T2 landed (PR #236); T3 not authorized; V4k blocked on CG-2 Design A |
| Claude Watch Parity | Claude transcript indexing and automatic-capture evaluation | **Closed `NO_GATE2_ROUTE`** — Gate 1 on-demand supported; Gate 2 rejected |

<!-- TIER_A_END -->

---

## After Tier A — MCP tools (shell+MCP)

<!-- MCP_AFTER_TIER_A_START -->

After Tier A in a project repo, use read-only MCP `search_fast()`, `ask()`, `related()`, or `stats()`. Do **not** repeat `brief()`. Non-project modes follow MCP gates.

<!-- MCP_AFTER_TIER_A_END -->

---

## Tier B — MCP-only (no shell, MCP connected)

<!-- TIER_B_START -->

1. **`brief()` first** every session. Pass `project=<repo-slug>` to focus one repo (e.g. `pavlomassage-dev`, `willowyhollow-practice`, `convmem`). **If omitted:** infer from workspace — git repo basename, parent dir name, or tags in README/AGENTS.md; do not substitute a unrelated slug (e.g. do not use `willowyhollow-dev` when cwd is `pavlomassage-practice`).
2. **Check `unresolved_count`** in the brief response. If >0 and working on a client site, surface open issues before proceeding.
3. **Before answering history/architecture questions:** call `search_fast()` then `ask()` with citations.
4. **`related()`** walks the evidence chain for any ledger id (`dec_prop_…` or `obs_…`).
5. **If `ask()` fails with network error** (Codex sandbox): retry via `bash -lc 'convmem ask "..."'`.

**Read-only via MCP.** No propose_decision, add, index, or verify on MCP — durable writes are CLI `convmem record` + `--approve-last` only, run by Ryan. **Shell-capable agents:** may run `convmem index --file` for session tracking (Tier A); ask Ryan to run it if you have MCP only.

Prefer **`brief()` tool** for session start. If the client uses `resources/read`, **`memories://brief`** or **`memory://brief`** is available (same payload). Do not invent other memory URIs.

<!-- TIER_B_END -->

---

## Tier C — paste-only (ChatGPT webUI)

<!-- TIER_C_START -->

1. **Ask Ryan to run:** `convmem brief --stdout-only`
2. **Interpret the pasted output.** Cannot run CLI — do not pretend to call convmem.
3. **At session close:** suggest `convmem record` blocks using the format in SESSION-CLOSE-RECORD.md. Ryan will run them.

<!-- TIER_C_END -->

---

## Session close

<!-- SESSION_CLOSE_START -->

**Handoff is not a record.** Finishing a task, verifying bugs, switching models, or Ryan saying **ingest your chat** / **full handoff** → run **Track A** (`convmem index --file` session transcript). **Do not** output a `convmem record` block.

**Output `convmem record` only when Ryan literally says:** `record block`, `closing`, `end session`, or `record this`.

**Do not create markdown files** (`logs/*.md`, audit summaries) unless Ryan explicitly asked for a file or told you to append to an existing agreed log (e.g. findings log). **Exception:** Ryan-authorized implementation handoffs in `docs/inter-model/*-handoff.md` per **Handoff and resume contract** — use `HANDOFF-TEMPLATE.md`, update `LATEST.md`, push branch. To preserve work without a durable handoff → **Track A** session index only (weak substitute).

**Do not record session-start orientation alone** (`doctor` / `brief` / `unresolved` with no substantive work). That ritual is read-only context — not ledger-worthy unless Ryan says **closing**, **record block**, or you finished a decision/fix worth preserving.

**Never ask Ryan** what `convmem record` should capture — you already know the format. Look up `--relates-to` via `search_fast` / `convmem search` if needed; fallback for unrelated new work: `dec_prop_20260623_161428_c311`.

When Ryan closes or asks for a record block:

- Read `docs/inter-model/SESSION-CLOSE-RECORD.md`.
- `--relates-to` must be a real ledger id (`dec_prop_…` or `obs_…` from search_fast/ask/related).
- **Never** use topic slugs (`system-maintenance`), omit `--relates-to`, or use fake ids.
- Fallback for unrelated new work: `dec_prop_20260623_161428_c311`.
- Output a copy-paste shell block:

```bash
convmem record \
  --relates-to <ledger_id> \
  --summary "<one sentence>" \
  --rationale "<why this decision>" \
  --author <model-name>
convmem record --approve-last
```

Do not run convmem record -i directly — Ryan runs CLI commands. **Kiro:** add `--signer kiro-review` on `--approve-last` when signing durable facts.

<!-- SESSION_CLOSE_END -->

---

## Handoff and resume contract (cross-session work)

<!-- HANDOFF_RESUME_CONTRACT_START -->

**Chat is evidence; handoff docs are the contract.** Do not rely on conversation search to resume work. Use **LATEST → handoff doc → STATUS → git** (local discovery); cloud execution needs pushed branches + handoff on `origin`.

### Picking up work (session start, after Tier A)

When cwd is `~/Projects/convmem` or Ryan says **resume** / **what's in flight** / **continue**:

1. Read top entries in `docs/inter-model/LATEST.md` — look for `AUTHORIZED`, `not yet implemented`, `BLOCKED_ON_RYAN`, `local-only`, `unpushed`.
2. Glob recent `docs/inter-model/*-handoff.md` (same week first).
3. If an arc applies: read matching `docs/plans/STATUS-<slug>.md` (Section 4 incomplete + Section 10 Update Log).
4. `git fetch origin && git branch -a` — check unpushed local commits (invisible to cloud).
5. `convmem doctor` — heed `arc_staleness` warns when present (advisory).
6. Point Ryan at the handoff path; state **resume state** from the packet (`NOT_STARTED` | `IN_PROGRESS` | `BLOCKED_ON_RYAN` | `READY_FOR_PR`).

**Do not** start implementation from chat memory alone when a handoff doc exists.

### Leaving work (authorized or mid-flight)

When Ryan **authorizes** implementation for another lane, or you **pause** authorized work before done:

1. Write `docs/inter-model/<LANE>-YYYY-MM-DD-<slug>-handoff.md` using `docs/inter-model/HANDOFF-TEMPLATE.md` (copy structure; fill every section).
2. Add one bullet to **top** of `docs/inter-model/LATEST.md` under "Recently merged / settled": `AUTHORIZED (not yet implemented)` or current resume state + link.
3. Update arc `STATUS-*.md` Update Log (one line) if the arc has a STATUS file.
4. Push branch immediately; note SHA and flag `local-only` if not pushed.
5. Track A: nudge `convmem index --file` on this session transcript.

**Required handoff sections:** What to build · Integration point (file + line) · Spec/algorithm · Output contract · What NOT to build · Test expectations · Acceptance criteria · Branch convention · Resume state · Ryan GATE (if any).

### When handoff markdown is allowed

| Allowed | Not allowed |
|---------|-------------|
| Ryan-authorized cross-lane implementation brief | Ad-hoc `logs/*.md` audit summaries |
| Pausing authorized Execute with resume packet | Chat-only "I'll remember" with no LATEST line |
| Kiro/Codex design → Cursor Execute (charter) | Scope expansion beyond authorization |

<!-- HANDOFF_RESUME_CONTRACT_END -->

---

## Read-only guard

Agents may search, ask, brief, and related freely.

**Allowed without asking Ryan:** `convmem index --file <path> [--supersede]` to ensure **session tracking** (transcripts, `crush.db`, synced `docs/inter-model/*.md`) per Tier A above.

**Ryan-gated:** `convmem add`, bulk `convmem index` (no `--file`), `convmem verify`, and `convmem record --approve-last`. The evidence ledger is human-signed.

---

## Workflow routing (when unsure what to run)

<!-- WORKFLOW_ROUTING_START -->

**Cheat sheet:** `docs/MODEL-WORKFLOW.md` — read when lost.

| If cwd / task is… | Read first | Run |
|-------------------|------------|-----|
| Any session | — | `convmem doctor` → `brief` → `unresolved` |
| `~/Projects/convmem` + cross-project digest | `docs/CROSS-PROJECT-DIGEST-ATTEMPTS.md` | `scripts/cross-project-digest.sh --skip-ask`; smoke: `scripts/smoke-cross-project-digest.sh` |
| `~/Projects/convmem` + architecture | `docs/builder-reference/README.md` | matching digest, then code |
| `~/Projects/convmem-lab` | `docs/lab-reference/NOTES.md` | `scripts/convmem-lab.sh doctor`; `lab/scripts/compile-synthesis-brief.sh`; `lab/scripts/smoke-synthesis.sh` |
| Session close / record | `docs/inter-model/SESSION-CLOSE-RECORD.md` | **Only if Ryan asks** — output `convmem record` block; else Track A index only |
| Resume / in-flight work | `docs/inter-model/LATEST.md` → `*-handoff.md` → `STATUS-*.md` | After Tier A: LATEST top → handoff doc → git branches; not chat search |
| Authorize Execute for another lane | `docs/inter-model/HANDOFF-TEMPLATE.md` | Handoff doc + LATEST bullet + STATUS Update Log + push branch |

**Split:** `lab-reference/` = lab gates & synthesis smoke (lab repo). `builder-reference/` = prod architecture. Never mix prod/lab data paths. Lab: no MCP registration. `--propose` on prod digest: Ryan-gated.

**Codex / DeepSeek:** verify shipped work via `docs/CODEX-DEEPSEEK-VERIFY.md` (independent checklist — do not trust chat claims alone).

<!-- WORKFLOW_ROUTING_END -->

---

<!-- TEAM_CHARTER_START -->
## HITL team charter

| Work type | Default lane | Copilot audit lane |
|-----------|-------------|--------------------|
| Architecture / execution planning | **OpenAI Codex** | Not involved |
| Large implementation | **Cursor** | Not involved |
| Bug discovery / investigation | **Crush** | Escalate when warranted |
| Safety / isolation / code audit | **GitHub Copilot audit lane** | Primary; targeted scope only |
| Evidence verify / targeted recheck | **GitHub Copilot audit lane** | Targeted; no uncontested re-runs |
| Design review / sign-off | **Kiro** | Not involved |
| Conflict adjudication (scarce) | **Sol-High** | Separate resource; hard gate only |
| Ledger write / merge | **Ryan only** | Not involved |
| Bound brief → GitHub PR lifecycle | **PR Steward** (default Codex) | Not involved |

**Planning:** Codex authors approved architecture and execution plans; Cursor implements after Ryan authorization.

**PR Steward** — Delivery-role overlay (brief-bound; no merge/grant/ledger); Ryan grant only — never inferred or self-assigns.

**Conditional Copilot.** Independent safety/isolation audits or targeted verification only—not implementation, routine work, drafting, uncontested re-audits, or missing Cursor handoffs. **Sol-High** is a separate scarce resource, not the Copilot audit lane.

**Kiro** is non-implementing/review-required: only requested architecture/plan/review docs; never code/tests/scripts/config/generated/runtime. Implementation → Cursor.

**Sol-High hard gate (Copilot audit lane + Kiro, same target + same revision).**
Invoke only when **GitHub Copilot audit lane** and **Kiro** issue materially conflicting written **PASS or FAIL** verdicts on the **same artifact and revision**. Literal five-field prompt prefix:

```text
SOL-HIGH CONFLICT SUMMARY (required — all fields must be present)
Artifact: <PR number / branch tip SHA / file set — exact>
GitHub Copilot audit-lane verdict: <PASS|FAIL> — <one-line rationale>
Kiro verdict: <PASS|FAIL> — <one-line rationale>
Material proposition in conflict: <specific factual claim both verdicts cannot both be true>
Negative confirmation: not single-FAIL / deferral / abstention / silence / missing / incomplete / different revision — confirmed
```

`defer` is never a valid opposing verdict. Any missing field, deferral, abstention, silence, incomplete verdict, or different revision blocks Sol-High.

**Non-example (PR #52):** Copilot audit FAIL; Kiro defers → single-reviewer FAIL, not a conflict. Do not call Sol-High.

**Full charter:** `docs/inter-model/TEAM-CHARTER-2026-07-06.md`
<!-- TEAM_CHARTER_END -->

---

## Bounded autonomy

<!-- BOUNDED_AUTONOMY_START -->

Default for Routine-reversible work only in convmem. Kiro remains review-required. `Mode: review required` disables it; `Mode: bounded autonomy` opts in where higher rules permit. WordPress stays review-required pending separate probation. Other repos, architecture, security, and external-configuration work never inherit it.

Precedence (high→low): system/tool guards → lane must-nots + protocol → DB/secrets/external safety → exact brief authorizations → autonomy defaults. Lower cannot override higher.

Interrupt only for: security/privacy exposure; unauthorized external change; external cost/commitment; public API/schema change; out-of-lane action; ambiguous outcome. Else choose one path and continue.

Reuse existing DB-backup, lane, and record safeguards by reference.

External auth requires exact resource, operation, and final value (or named one-shot) in `Authorized external changes`; never infer from outcome.

Done: result, verification, largest material trade-off/risk, branch/push; Track A at handoff.

<!-- BOUNDED_AUTONOMY_END -->

---

## Response TL;DR

<!-- RESPONSE_TLDR_START -->

**MANDATORY: Every response MUST end with a TL;DR.** A response without a closing TL;DR is non-compliant — treat this like a missing `convmem doctor` call. No exceptions by model, lane, or task type.

**Format — scale to response length:**

| Response size | TL;DR format |
|---------------|-------------|
| Short (< 5 lines of substance) | One sentence: `**TL;DR:** …` |
| Medium (5–30 lines) | 1–2 sentences: `**TL;DR:** …` |
| Long (> 30 lines or multi-section) | `## TL;DR` heading with 2–4 bullet points |

**Content:** State what was done, decided, or answered — not a restatement of the question. Keep it proportional to complexity.

**Only exception:** bare single-line acknowledgments ("Done.", "Pushed.") where the entire response already is the summary.

**If you are about to submit a response without a TL;DR at the end, stop and add one.**

<!-- RESPONSE_TLDR_END -->

---

## Context brief (Who / What / When / Why / How)

<!-- CONTEXT_BRIEF_START -->

**MANDATORY when naming project artifacts.** Keep identifiers (PR numbers, SHAs, ledger ids, paths, thread ids) — they must stay copy-pasteable — but **never lead with bare ids alone**. For each substantive item you cite, give Ryan enough plain-language context that he can follow without opening the artifact.

**Use Who / What / When / Why / How** (skip a field only when it is obvious from surrounding sentences):

| Field | Answer |
|-------|--------|
| **Who** | Which lane/actor owns or produced it (Cursor, Kiro, Crush, Ryan, Copilot audit, Steward, …) |
| **What** | What the thing *is* in product terms (not the filename) |
| **When** | Freshness that matters (merged today, tip of open PR, stale vs main, posted before merge, …) |
| **Why** | Why it exists / why we are looking at it now |
| **How** | What it does or changes if acted on (merge lands X; rebase updates Y; approve grants Z) |

**Also label the id once:** `#67` → “R2b capture-auth implementation PR (`#67`)” — then WWWWH as needed.

**Scale:** One short clause for a passing mention; a compact five-line block (or a tight table) when the item is the topic of the turn. Do not dump WWWWH for every path in a `git status` list — only for decision-relevant items.

**Anti-patterns:** walls of SHAs/ids; “see `obs_…`” with no title; “tip `abc…`” with no branch/PR role; checklists of PRs that only list numbers.

<!-- CONTEXT_BRIEF_END -->

---

## Plan jargon glossary

When writing or substantially updating a plan document (`docs/plans/`, `docs/inter-model/`, `*.plan.md`), **append a `## Jargon TL;DR` table** at the very end defining every project-specific term, abbreviation, lane name, or phase code that a newcomer would not know. One sentence per term, link to source if it exists. Do not define universally-known terms. Full format: `.kiro/steering/plan-jargon-glossary.md`.

---

## Tool lanes by model

Compact charter above. Full table: `docs/AGENT-ROLES.md` and `docs/inter-model/TEAM-CHARTER-2026-07-06.md`.

---

## Recovery

See `docs/RECOVER.md`. The runtime corpus (ChromaDB, vector index) is outside Git. Project backup restores source code + MCP templates. To redeploy surfaces: `scripts/deploy-agent-protocol.sh`.
