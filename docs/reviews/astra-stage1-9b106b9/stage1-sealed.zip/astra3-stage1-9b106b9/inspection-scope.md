# Stage 1 inspection scope — Arc none (ad-hoc)

Target: `9b106b908b944f8bd4c3f417b576dc13884f2503`.

Verified bytes are not the same as reviewed semantics. All 116 archive entries were hashed; 82 repository files were compared against Git. Stage 2 entries were never extracted or semantically opened. Only the following content was inspected for conclusions.

- Root delivery instructions: README-FIRST.md and MESSAGE-1-STAGE-1.md.
- Both integration plans in stage1/repo/docs/plans: architecture in full; execution in full (a clipped required-command span was reread).
- Existing MCP implementation: mcp_server.py lines 1–115 and 675–950; read_scope.py in full; domains.py in full; site_filter.py in full; ledger_ids.py in full.
- Retrieval/state: query.py lines 240–350; ledger.py lines 155–200, 348–382, 415–497; unresolved.py lines 1–160; distill.py lines 160–185; ingest.py lines 960–990.
- Provenance: provenance.py lines 1–220, 251–305, 456–540, 656–920, 951–1130; relevant imports/signatures and fields located with rg; provenance_binding.py lines 1–90 and 244–302. Pure test execution exercised additional target functions.
- Storage boundary: chroma_readonly.py lines 1–110; chroma_write_store.py lines 1–100. Other bundled storage and adapter files were hash-verified, not independently audited line by line.
- Baseline tests: test_provenance.py (imports, selected source spans and test inventory inspected; all tests executed); test_site_filter.py in full, all tests executed. Other bundled tests were verified bytes only.
- Builder references: ousterhout-builder-digest.md lines 1–140; hard-parts-builder-digest.md lines 1–150; both searched for relevant ownership/boundary invariants. Neither is correctness evidence.
- Protocol: config/agent-protocol.md targeted search for approval/ownership rules. General corpus orientation deliberately skipped.
- Installed OpenClaw evidence: version, agent and gateway help captures; package.json lines 1–90; agent-tools.md lines 1–120; acp-agents.md lines 110–145; configuration-reference.md targeted documented port/env/logging sections around lines 2359–2410, 2580–2610, 2710–2735; memory/skill/config references searched. Full runtime distribution, dependencies, effective config and actual session inventory were not supplied or executed.
- Exact-target extra files: canonical_json.py in full; convmem.py approval and add CLI sections; propose_decision.py approval/indexing sections; observe.py lines 1–221. verify.py and atomic_files.py were extracted and hashed but not used for semantic conclusions.

No prior-review packet, prior-review canvas, history diff, or reviewer verdict artifact was read. The current plan's own administrative descriptions of past findings were necessarily visible; independence is partially contaminated.

No strict integration code exists at this target. No OpenClaw command, provider/model run, deployment, database mutation, session ingestion, or corpus search was performed. The one startup doctor did read live health metadata; zero-live-access therefore cannot be claimed for the whole session. All subsequent experiments used only disposable files/processes and the exact-target source copy.
