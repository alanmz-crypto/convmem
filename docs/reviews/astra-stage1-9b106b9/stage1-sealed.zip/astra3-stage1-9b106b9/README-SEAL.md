# Sealed Stage 1 — Arc none (ad-hoc)

Read STAGE-1-REVIEW.md first. It records the independent reconstruction, claims, hypotheses, initial verdicts, findings and second-order remedy attacks before Stage 2.

STAGE-1-SEALED.json binds the report digest, target and verdicts. STAGE-1.sha256 covers every regular file in this review directory except itself. Verify from this directory with `sha256sum -c STAGE-1.sha256`.

MANIFEST.sha256 is the original review-bundle manifest; it includes Stage 2 paths deliberately absent here. Do not use that original manifest as the manifest of this sealed derivative.

The seal is a procedural content-integrity record, not a cryptographic identity signature or an execution approval. After Message 2, create a separate addendum rather than altering this Stage 1 report. No Stage 2 content is present.

Diagnostic scripts are review probes, not proposed implementation code. The review discloses its initial live-health doctor exception and its partial history contamination.
