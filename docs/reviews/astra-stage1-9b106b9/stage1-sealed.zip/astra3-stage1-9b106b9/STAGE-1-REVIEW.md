# ConvMem + OpenClaw — Astra #3 Stage 1 review and remedy falsification

**Arc: none (ad-hoc integration). Stage 1 only. No execution authorization.**

- **Independence status: partially contaminated.** No Stage 2 artifact was opened. The current architecture itself states an earlier verdict and summarizes six earlier issues; perfect blindness is impossible.
- **Integrity and safety maturity: blocked.** The proposed boundary is promising, but consequential contradictions and incomplete enforcement contracts remain.
- **Incremental web-development value: unproven.** No matched outcome experiment was supplied or run.
- **BUILD GATE: blocked.**
- **TEST GATE: proceed for disposable, offline fixtures and fake-process tests only.** This is a readiness assessment, not an authorization. Installed OpenClaw, live-derived snapshots, staging websites, and provider runs require their later grants.
- **LIVE-DATA GATE: blocked**, for both integration reads and writes.
- **PROMOTION GATE: blocked.**
- **Three most consequential findings:** publication/rollback can undo supposedly permanent authority transitions; request-local graph reduction can turn conflict into pass; the promised source-byte provenance verification is stronger than the existing verifier actually performs.

**Grok is not yet ready to build because the following architectural decisions remain unresolved:** authority continuity and rollback, the scope of state reduction, source/view grounding for provenance, executable lifecycle control, and closure of activation inputs. These are described as F1–F5 below. F6 additionally blocks a claim that the integrated system already satisfies the stipulated approved-ingestion invariant.

This report proposes candidate changes. It does not amend the approved architecture, implement a fix, approve a proposal, or authorize Cursor/Grok, Kiro, Ryan, or OpenClaw to take an action. “Surviving solution” means a candidate survived the documented second-order desk attack, subject to its stated assumptions and tests. It does not mean demonstrated implementation correctness.

## 1. Evidence, revision, and scope actually inspected

The reviewed planning branch is **plan/2026-09-20-openclaw-convmem-final-readiness**, at exact commit **9b106b908b944f8bd4c3f417b576dc13884f2503**. Codex's two plans describe a fixture-only reader and future OpenClaw activation. They are the subject of this review, not evidence that the integration works.

Evidence identity:

- Supplied ZIP: openclaw-convmem-final-readiness-9b106b9.zip.
- ZIP SHA-256: 257e5df8bb166a9f02517f78e80e56504ce7c71d4d09acf381fe711570775d47.
- All **116** MANIFEST.sha256 entries matched; no unlisted regular archive file remained.
- Architecture SHA-256: ea40852867480a5b7ee81a736c9c9901f2cfa419d1b93bc49c5e62e289cc5166.
- Execution-plan SHA-256: e498395b6ffc70e6dfff1c5123d9a2c12f68105414ee9fb621ee7bdaa421b2af.
- Target Git tree: 6fa11526c9d559da715482face78c837fcf3bac5.
- All **82** bundled repository files were byte-identical to that commit. This is a content check, not a claim that every file received a semantic audit.
- The difference from code baseline 7809f20dc53d9dd19f765c3ec3214a3df54ca5bf contains only the two plans.
- The shared checkout was on an unrelated branch at 9193704fafcf376e20ac1bb717dc875bd1f77ce4. It was not switched or used as source evidence. Its HEAD remained unchanged at recheck.
- Review evidence capture began **2026-09-21 00:31:14 UTC**, September 20 in America/Chicago. The final seal carries the completion timestamp.
- No target corpus/database snapshot or executable integration configuration was supplied. The configuration revision is the normative text inside the two verified plans.
- Bundled OpenClaw evidence identifies version **2026.3.2**, help build **85377a2**. This is not a complete runtime/dependency distribution.
- Reviewer surface: Codex, OpenAI GPT-6 family, acting as Astra at the user's request. Exact serving-model build and reasoning tier were not exposed for independent verification.
- Diagnostic interpreter: Python 3.13.12; Linux 7.2.6-arch2-1; Unicode data 15.1.0; pytest 9.1.1. The diagnostic environment reports idna 3.11 and mcp 1.28.0; it is **not** the proposed strict deployment environment. No strict IDNA/MCP integration result is claimed.

**Boundary exception:** the standing session-start instruction caused one completed “convmem doctor” invocation before bundle inspection. It accessed live health metadata, including collection counts. Therefore this session cannot claim literally zero live reads. That output was excluded from frozen-target conclusions. There was no further corpus query, brief, unresolved search, index, add, record, approval, or live experiment. No zero-side-effect attestation is inferred for the startup command. All diagnostic execution after it used disposable files/processes and exact-target copies.

Stage 2 bytes were hashed only to satisfy whole-manifest verification. They were not extracted, displayed, or semantically inspected. The only unavoidable review-history exposure was the current plans' own administrative descriptions. General historical corpus orientation was deliberately skipped.

The [inspection inventory](inspection-scope.md), [command inventory](commands.json), [freeze record](freeze.json), and [source-equivalence record](source-equivalence.json) distinguish reviewed content, hash-only verification, commands actually executed, and missing evidence.

### Evidence key

References below use these verified local artifacts and exact line spans:

- **A:** [Current integration architecture](stage1/repo/docs/plans/ARCHITECTURE-openclaw-convmem-integration.md), especially §§6.5, 8, 9, 11 and 13.
- **E:** [Current fixture execution plan](stage1/repo/docs/plans/EXECUTION-openclaw-convmem-integration.md).
- **P:** [Existing pure provenance module](stage1/repo/provenance.py).
- **M:** [Existing MCP server](stage1/repo/mcp_server.py).
- **OC:** [Bundled OpenClaw configuration reference](stage1/installed-openclaw/docs/gateway/configuration-reference.md).
- **CLI:** [Exact-target ConvMem CLI](exact-target-extra/convmem.py).
- **Q:** [Exact-target proposal/approval module](exact-target-extra/propose_decision.py).

**Evidence classes:** Proven means a verified artifact contradiction or a directly reproduced bounded behavior. Strongly supported means the evidence establishes the mechanism but not an unimplemented integration exploit. Plausible but unverified identifies a hypothesis/candidate. Unknown means the necessary evidence does not exist in this packet.

### What actually ran

1. Byte/hash/revision verification described above. The first manifest script failed on a leading “./” path; normalization was corrected and all entries subsequently verified. No analysis used an unverified copy.
2. **31 tests passed** from the target's test_provenance.py and test_site_filter.py. The process used an empty HOME, no pytest plugin autoload, no conftest, no pytest cache, and an audit guard against network, subprocesses, and live project/config/data paths. No denied operation occurred. [Literal output](test-evidence/pure-tests.txt).
3. A disposable Linux process-tree probe: parent death killed the child with its configured SIGKILL, while the child's forked descendant survived in the same process group. The harness terminated and reaped its own processes. No OpenClaw process ran. [Probe output](test-evidence/pdeathsig-probe.txt).
4. A pure provenance probe against P: a synthetic trusted channel inventory plus syntactically valid but unbacked source/view hashes produced “verified/trusted”; an unmatched child input-view hash did too. No source/view bytes were supplied. This is a verifier-capability test, not an unprivileged attack on an authority inventory. [Probe output](test-evidence/provenance-grounding-probe.txt).
5. Finite evaluation of A's verification truth table found **three** cases where discarding checks changes a non-pass global state into pass. This is a specification witness, not an integration test. [Witnesses](test-evidence/selector-truth-table-witnesses.json).

No strict integration tests could run: the strict modules and connector are absent. No model/provider calls, OpenClaw starts, browser runs, website edits, database writes, deployments, or live-data migrations were attempted. The proposed remedies were not implemented. Additional research was limited to primary Linux documentation for the load-bearing process, clock and containment questions.

## 2. Independent system reconstruction

### Implemented core

The existing CLI and MCP surfaces retrieve from the shared ConvMem serving repository; the legacy domain setting is a convenience default, not an immutable ceiling. The MCP module loads home-derived configuration before profile selection. Its profile parser recognizes shell and otherwise falls back to full. Full exposes search/synthesis, brief/resource surfaces, unresolved and related. These facts follow from M:18–35, 74–78, 686–939 and read_scope.py:63–90.

Legacy retrieval mixes shared vector candidates, scope filtering, adaptive over-fetch, and exact-ledger priority lookup. Shared ledger identity maps are last-write-wins. Legacy unresolved reduces the global child graph before applying site/domain filters. Source paths and ordinary metadata can establish legacy site matches; distillation produces ordinary domain labels. These are implemented behaviors, not strict authorization guarantees. Evidence: query.py:266–346; ledger.py:364–382, 446–497; unresolved.py:21–56; site_filter.py:15–46; distill.py:178; ingest.py:960–979.

Pending decisions have a separate file queue. The current approval command previews and confirms a proposal, persists approval intent, then by default invokes indexing under a governed lock. The proposal file queue is not itself a Chroma proposal tool. However, the default approved-write route is not literally the invariant's separate “add --file” route; see F6. Evidence: Q:27–36, 538–610, 612–756; CLI:1320–1368.

The provenance substrate has strict envelope parsing, commitments, immutable in-memory authority snapshots, parent-commitment checks, conservative transformer caps, and bounded recursion. Those mechanisms have useful unit coverage. They do not, by themselves, fetch or verify source/view bytes. Evidence: P:89–175, 656–773, 958–1127; diagnostic results above.

### Specified integration

The proposal intentionally builds a separate strict read surface:

**Operator-owned scope/registry + fixture source batches + dispositions/provenance context → authority snapshot → deterministic state and bounded file projection → dedicated strict MCP server → fixed OpenClaw plugin → transient model session → supervisor-controlled local output.**

Ownership is deliberately asymmetric:

- The operator's approved files/CLI and underlying ledger retain durable authority.
- A proposed fixture publisher owns derived immutable snapshots and generation publication.
- The strict scope module owns authorization; the state module owns identities, approval matching and reduction.
- The reader owns lexical search and graph reads, without Chroma, embeddings or a publisher import.
- The connector translates exactly three aliases to three MCP tools and has no retrieval policy.
- The activation supervisor is intended to own process lifetime, session isolation and answer release.
- OpenClaw owns transient coordination and model interpretation only.
- Git/project-native artifacts remain the authority for actual repository/deployment state.
- Cursor/Grok 4.5 High is the future implementation writer; Kiro signs design/scope; Ryan authorizes; Codex verifies. None is authorized by this review.

The proposed durable read model contains immutable assertions, logical subject identities, source-event identities, exact dispositions, provenance references, graph edges, state labels and content-addressed manifests. Serving rows and activation sessions are derivatives. A snapshot is immutable, but immutable does not necessarily mean current or approved: those properties require the disputed transition rules below.

The proposed runtime offers search, unresolved, and related only. It has no write tool, brief resource, synthesis service inside ConvMem, native memory, capture, ACP/subagents, channel deployment or website execution. Its initial search is explicitly lexical. Calling this complete web-development orchestration would overstate its actual boundary. Evidence: A:241–271, 1078–1113, 1580–1776; E:23–36.

### Eight traces and their evidence state

1. **Session start:** operator validates pinned artifacts, creates fresh state, starts supervisor/gateway/connector, and cold-qualifies a strict projection before registering tools. Specified; not implemented or observed. Turn ingress and lifecycle enforcement remain incomplete (F4/F5).
2. **Direct/deep retrieval:** legacy semantic retrieval exists; proposed strict search is a separate lexical kernel. “Deep” lookup is a bounded related neighborhood. No strict paraphrase-recall promise exists.
3. **Observation → proposal → approval → write:** implemented legacy queue/approval/indexing path exists; strict fixtures simulate authoritative input. A live mapping from approved ledger records to strict dispositions/bindings is explicitly deferred. Pending proposals must not be read by the strict fixture builder.
4. **Agent tools:** fixed plugin → stdio strict server → authorized raw evidence. Designed; no effective installed-session inventory has been demonstrated.
5. **Cross-agent recovery:** a fresh successor could retrieve the same published evidence; there is no implemented task handoff, checkpoint adoption, authorized executor or recovery coordinator. A new session loses ephemeral context by design.
6. **Stale/contradictory information:** the proposal defines explicit states, conflict heads and expiry. Reduction scope and authority rollback nevertheless contradict those promises (F1/F2).
7. **Crash/retry/restart:** exact event/payload matching, fsync publication, CAS and fresh sessions are specified. Persistent admission history, ABA prevention and process-tree cleanup are incomplete.
8. **Verification/deployment/rollback:** evidence verification labels exist; website execution/deployment does not. Fixture projection rollback is not equivalent to deployment rollback, and must not undo governance history.

The only newly observed execution here concerns existing pure modules and Linux primitives. Proposed strict behavior is otherwise specified, assumed or unknown. A's explicit “current gaps” accurately warns against deploying the legacy MCP profile as though it were strict.

## 3. Claims and invariant ledger

### Claims

**C1 — Strict retrieval cannot cross the immutable audience boundary.**  
Mechanism: trusted registry, physical scoped projection, three tools, final row authorization. Benefit: unrelated client/project data never reaches the model. Required evidence: isolated projection tests and actual effective tool/resource inventory. Falsifier: a row outside the bound changes output, lookup result or available surface. **Status: plausible but unverified; no implementation.** A §§5–6.4, cases 1–27.

**C2 — Approved/current/verified mean distinct, defensible things.**  
Mechanism: dispositions, immutable assertions, typed state reducer. Benefit: stale preference or failed check does not guide new website work. Required evidence: multi-generation and cross-selector state equivalence. Falsifier: rollback resurrects approval or narrowing hides a failure. **Status: contradicted at specification level by F1/F2.**

**C3 — Provenance binds evidence to its actual source and consumed view.**  
Mechanism claimed: existing recursive verifier plus strict payload binding. Benefit: the owner can distinguish source-supported evidence from model interpretation. Required evidence: raw/view witness validation, not merely matching supplied commitments. Falsifier: unsupported source/view claims receive the stronger label. **Status: claimed verification is not implemented by the cited primitive; F3.**

**C4 — Expiry/revocation stop stale model work and output.**  
Mechanism: fresh state, locks, supervisor, deadlines, buffered output and parent-death signaling. Required evidence: defined controller protocol and actual process-tree/clock/backpressure tests. Falsifier: surviving descendants, reused profile slot, or output authorized after revocation. **Status: incomplete, with one primitive counterexample proven; F4.**

**C5 — A fresh activation contains no ambient credential/state input.**  
Mechanism: empty HOME/state, closed environment and pinned files. Required evidence: cwd/env/log/runtime-closure tests. Falsifier: CWD .env loading, shared persistence, or changed imported code with unchanged activation checks. **Status: incomplete; F5.**

**C6 — No retrieval-driven durable-memory feedback loop exists in this slice.**  
Mechanism: no write/capture/ingest/native-memory path. Benefit: repeated summaries cannot automatically become approved facts. Falsifier: tool-result content reaches any durable write or approval path. **Status: strong design property, unverified in runtime.** It does not prevent mistaken answers or later human copying.

**C7 — ConvMem improves continuity and website work.**  
Mechanism: a fresh agent retrieves approved historical constraints instead of asking Ryan to restate them. Required evidence: matched task outcomes with information-channel controls. Falsifier: equal/worse decisions, site substance, rework or costs. **Status: unknown/unproven.** No successful search can establish this claim.

**C8 — ConvMem reduces Ryan's total context-transfer burden.**  
Mechanism: reusable evidence replaces repeated briefings. Required evidence: briefing plus curation, approvals, binding, rebuild, session-reset and recovery minutes. Falsifier: maintenance offsets savings. **Status: unknown.**

**C9 — Cursor can start without making architecture decisions.**  
Mechanism: E's closed interfaces and allowed-file/test ownership. Required evidence: one consistent set of state, lifecycle and recovery contracts. Falsifier: implementation must choose between incompatible rules or invent a security boundary. **Status: disproven for this packet; F1–F5.**

### Invariants and how violations would be detected

- **File/CLI durable core; OpenClaw not authoritative:** preserved as intent. Detect with import/write-denial tests and mutation controls; no runtime proof yet.
- **Observe → Diagnose → Decide → Execute → Record:** the proposed slice covers evidence access and advice. Execution/recording remain external human-controlled phases. No silent end-to-end automation is justified.
- **Proposal isolation and no model self-approval:** pending files excluded and strict tools are read-only. Test pending-input rejection and attempted hidden write/approval calls. Existing global CLI access is an operator trust boundary, not a model-authentication proof.
- **Approved “add --file” path:** contradicted by the baseline default approval/indexing route; F6.
- **Provenance/scope/status/time/confidence/supersession survive:** fields are specified; F1–F3 show where their meanings are not yet preserved.
- **Memory is not automatically truth:** typed labels and the untrusted envelope help. Source confidence is not calibrated probability; origin integrity is not factual correctness.
- **No historical redistillation:** strict lexical projection avoids it. The legacy distillation pipeline still exists outside this slice and must not be imported.
- **No automatic integration ingestion or uncontrolled execution:** specified, not runtime-verified. Existing legacy watch/refine services are not proof of integration capture authorization.
- **Immutable/disposable experiments, one implementation writer, reviewer read-only:** respected after the disclosed startup exception; no implementation work occurred.
- **Human authority over consequential actions:** retained. A readiness recommendation cannot grant a live-data, deployment or approval capability.

## 4. Minimum-sufficient architecture

The minimum useful core is an operator-approved, versioned file evidence set with stable assertion identities, provenance, explicit state, safe deterministic reads, and a CLI. A model/runtime connector is an adapter to that core. Neither Chroma nor OpenClaw is necessary to establish the core's authority semantics.

For this particular design:

- Scope binding and a dedicated strict entry point are justified: the legacy profile demonstrably is not an authorization ceiling.
- The immutable file projection is justified for a small bounded prototype: it permits deterministic cold verification and excludes the global-index candidate universe. Its cost is full rebuilds, bounded capacity and weaker lexical recall.
- Separate state and publisher/reader responsibilities are justified, but duplicate governance semantics are a maintenance cost until their relationship to the existing ledger is frozen.
- Three tools are a defensible initial interface. Related must distinguish display context from the full state dependency graph.
- The connector exists only to adapt OpenClaw's installed plugin interface. It contributes no demonstrated retrieval, memory or decision benefit.
- The supervisor is justified only if strong revocation and no-tool-inference shutdown are requirements. It currently carries more guarantees than its concrete contract supports.
- Seventeen schemas, multiple content-addressed artifacts and an activation stack are substantial cost for an unproven read-only benefit. Each must have a testable invariant, not merely a name.
- ACP, background tasks, capture, channels, native memory, automatic refresh and hosted-model routes can remain absent. No supplied evidence justifies adding them.
- OpenClaw can be removed while testing the file reader, state semantics and most authority failures. A file/CLI reader consumed by an ordinary agent remains a useful comparison condition.
- Do not replace the whole architecture. The primary failures are at state/publication, proof and lifecycle boundaries; they do not establish that file/CLI-first evidence is fundamentally mistaken.

The core CLI and the narrow integration should remain separately useful. A requirement to run the whole OpenClaw stack merely to inspect an approved fact would undermine the stable-core principle.

## 5. Assumptions, contradictions, and initial risk hypotheses

### Assumption ledger

**Operator-controlled files are authentic approval/configuration artifacts.** Used by scope, registry and disposition trust. If false, actor strings and hashes do not authenticate anything. Evidence: A:625–684 explicitly chooses operator filesystem control. **Confidence: conditional.** It is a legitimate trust assumption, not a cryptographic proof.

**All source records in a registration belong to its audience.** Used before parsing source content. If false, a correct parser can publish the wrong audience's text. Evidence: E:90–98 excludes mixed-audience sources; production resolver/migration absent. **Confidence: unproven for real data.**

**The active pointer is sufficient to preserve authority over time.** Used by build/rollback. If false, old facts or approvals reappear. Evidence: A:807–827 versus 1030–1076. **Confidence: false under the specified rollback; F1.**

**Dropping checks is conservative.** Used by effective-selector unresolved. If false, a hidden failing check produces false pass. Evidence: A:848–875, 1386–1397, case 18. **Confidence: false; F2.**

**Existing provenance verification proves raw and input-view bindings.** Used to assign strict assurance. Evidence: A:685–734 versus P's actual algorithm. **Confidence: false as stated; F3.**

**Parent-death signaling plus a process group guarantees tree cleanup.** Used by supervisor death handling. **Confidence: false as a sufficient primitive; demonstrated locally.** Actual installed child behavior remains unknown.

**A fresh state directory and empty environment close all ambient inputs.** Used by activation security. **Confidence: false as a sufficient specification.** Bundled OpenClaw docs identify CWD .env and default shared logging; imported runtime code is outside the named binary digest.

**Lexical retrieval remains useful enough on real web tasks.** Used by expected value. **Confidence: unknown.** Determinism is not recall or utility evidence.

**Snapshot rebuild/approval/session hygiene costs less owner effort than repeated handoffs.** Used by the human-benefit claim. **Confidence: unknown.**

**Disposable tests can be isolated from the host.** Used for current evidence. **Confidence: demonstrated only for the narrow pure tests/probes run here.** Not a conformance verdict on the future integration.

### Initial high-risk hypotheses, recorded before history access

H1: correct local reduction is undone by snapshot replacement or rollback.  
H2: omission/narrowing or a bounded neighborhood changes the truth state of a returned assertion.  
H3: provenance identity/commitments are mistaken for verified source/view content.  
H4: lifecycle rules have no complete executable control and containment mechanism.  
H5: ambient runtime inputs survive the claimed isolation boundary.  
H6: evaluation rewards retrieval or asymmetric access rather than useful work and net owner savings.

H1–H5 yielded the findings below. H6 remains an experiment-design risk, not a fabricated harmful outcome.

**Initial verdicts:** integrity/safety blocked; incremental value unproven; build readiness blocked. These verdicts and all findings are sealed before Stage 2.

## 6. Prioritized findings, failure scenarios, and attacked remedies

### F1 — Cross-generation authority continuity and rollback are inconsistent

#### Finding

**Proven specification contradiction; high consequence; category 3 for BUILD.** A valid supersession is permanent “within and after” its first snapshot (A:807–827), but rollback may activate any retained, qualified, unexpired same-owner snapshot (A:1055–1063). The latter can predate a revocation or supersession. A valid old snapshot is not a valid current authority state.

Concrete scenario: S1 approves decision D; S2 contains the valid revocation of D; both snapshots remain unexpired. The operator invokes the specified rollback with S2's generation as expected and S1 as target. The listed checks pass, but D becomes approved again in a fresh session. There is no new assertion or disposition restoring it. The same problem applies to superseded observations. A:2310–2318 separately prohibits resurrection and rollback changing authority reduction. That prohibition exposes the contract contradiction; this finding does not claim a conforming implementation is permitted to ignore it.

There is a second continuity hole: a forward bundle is a selected immutable view, but no predecessor inclusion/delta rule requires retaining previously admitted assertions/dispositions. Conversely, rechecking every retained disposition against the *currently* active predecessor would reject legitimate older dispositions as stale. Their admission basis must be distinguished from the basis for a new transition.

Finally, the pointer has an epoch but caller CAS binds only generation. A → B → rollback A allows a caller holding the original A generation to pass a later generation-only comparison. The epoch is not an ABA guard unless compared. Evidence: A:655–683, 819–827, 1030–1076; E:251–265, 388–402.

#### Root cause

Immutable snapshot validity, authority-history advancement and serving-version selection are conflated. Cold qualification proves internal consistency of a chosen history, not that it preserves all already-admitted governance transitions.

#### Candidate remedy

Use a monotonic authority lineage and permit rollback of a serving derivative only when it preserves the latest admitted authority snapshot. Bind CAS to the full prior pointer identity, including epoch.

#### Remedy attack

Merely retaining all files is insufficient: a pointer can still select an earlier history. A tombstone only in the projection is another source of truth and can disappear on rebuild. Revalidating old transitions against the latest basis makes ordinary multi-generation history impossible. An external mutable “do not resurrect” list creates split recovery.

A candidate with one mutable authority pointer and one independently committed serving pointer also fails under a crash between their commits.

#### Surviving solution

Keep the existing file core, but define one atomic publication record containing a monotonic admitted-authority watermark and the selected serving generation. The watermark is a continuity fact about approved source history, not a second approval authority.

For forward publication, a new authority manifest commits to its parent authority manifest and precisely enumerates additions. Previously admitted record/disposition bytes are conserved. Only newly admitted dispositions are checked against the immediate parent state. Retained dispositions preserve their original valid admission, and their subject payloads cannot change.

For a fixture rollback, the target must derive from the **same admitted authority snapshot** as the current watermark. A target with older authority is denied even if intact and unexpired. If no compatible generation exists, remain unavailable and rebuild; do not restore obsolete authority for availability. Reversing meaning requires a newly approved forward assertion/disposition.

This handles the original scenario by denying S2 → S1 authority rollback. D remains revoked. A deliberately independent test scenario uses a new fixture root/identity; it is not represented as continuity-preserving rollback.

#### Alternatives and trade-offs

Reactivating an older snapshot is simpler and cheap, but fails correctness, authority and provenance. Copying tombstones into an overlay complicates concurrency/recovery and introduces another source of truth. A cumulative lineage plus same-authority serving rollback preserves invariants, file/CLI compatibility and the OpenClaw boundary; it adds parent qualification and retained-history cost. It has a smaller failure surface than dual independently committed authorities, requires moderate schema/publisher work, and denies availability when safe recovery is impossible. Security improves because stale approvals cannot reappear through an operator recovery shortcut.

#### Required contract changes

- New authority-manifest version: add exact parent snapshot and parent-manifest digest, monotonic authority sequence, and canonical added-assertion/added-disposition arrays. Include them in snapshot identity.
- Define genesis separately; no prior-history omission is legal in forward publication.
- Preserve original disposition admission basis; validate new transitions against the qualified parent.
- Publication command accepts an expected pointer digest or the exact tuple of owner, epoch, generation and authority watermark; compare under the existing exclusive lock.
- Rollback changes serving generation only; reject an authority-watermark regression.
- Cold recovery validates the lineage and one atomic pointer; ambiguous durability serves nothing.
- Scope/binding identity migrations remain a separate reviewed operation, not a new-owner trick to bypass continuity.

Owner: strict state module and fixture publisher. Legacy data is not migrated by this remedy. Existing synthetic fixtures must be regenerated under the revised schema.

#### Validation

Three-plus-generation histories retaining old dispositions; approve/revoke/rollback; long supersession chains; omitted prior transition; changed old payload; A → B → A stale CAS; concurrent joins; crash before/after pointer rename/fsync. A negative control that removes lineage conservation must resurrect D and fail the test. Independently recompute reduction at every admitted revision.

#### Residual uncertainty

Production snapshot admission must bind to the real approved ledger/disposition cutoff, not just a synthetic fixture bundle. No live migration or safe history-pruning contract exists. Storage growth and cold-validation cost need bounded fixtures before any production design.

### F2 — Partial-graph reduction can hide a failure and create false pass

#### Finding

**Proven specification witness; high consequence; category 3 for BUILD.** A materializes state from the qualified authority graph (A:848–875, 1008–1016) but instructs unresolved to recompute status from the caller's narrowed graph (A:1386–1397). Case 18 tests only the conservative direction—hiding the sole pass. It does not test hiding fail or inconclusive.

Concrete valid binding: observation O in coding.ui; an independent pass check in coding.ui; an independent fail check in coding.security. All belong to the same authorized coding-bound projection. The frozen truth table gives O “conflict.” Requesting coding.ui removes the fail; the local reducer gives “pass,” and unresolved can omit O. No new verification or approval occurred.

The finite calculation found the same escalation for {pass,inconclusive} and {pass,fail,inconclusive}. The reader must either violate the local-graph rule, change the emitted frozen state, or apply inconsistent inclusion and display semantics.

A related ambiguity reinforces the problem: A:1550 says state reduction occurs on the neighborhood graph, although a depth-limited display neighborhood need not include every state-affecting verification. Also, A:868–870 does not consistently specify whether a conflicting observation head with pass remains unresolved.

#### Root cause

An authorized query filter or bounded display graph is treated as a state-evaluation boundary. Selection of evidence for display is not equivalent to the complete evidence required to determine state.

#### Candidate remedy

Compute canonical state once from the entire immutable, authorized bound snapshot. Apply selectors and neighborhood limits only to which records are displayed.

#### Remedy attack

A global graph across all projects would leak or use unauthorized evidence. The remedy must therefore use only the already authorized physical bound projection. A naive whole-graph related response would exceed bounds or expand protocol hubs. The fix must not turn display completeness into unbounded traversal.

A separate “local verification state” could be safe if unmistakably qualified, but the present success schema has no such semantics; adding a misleading second pass field is unnecessary.

#### Surviving solution

All three tools emit the same canonical authority/verification state for the same assertion and snapshot. That state is reduced from the complete bound projection; caller narrowing cannot alter it. The model was already authorized to retrieve the excluded coding.security row by omitting the selector, so this does not widen its audience.

Unresolved's predicate is exact: include every conflicting observation head, and include each current observation head whose canonical verification state is not pass. Historical rows are excluded. In the failure scenario, O remains conflict and unresolved.

Related may return bounded context, but it must not recompute truth from that context. Its edge rules must explicitly distinguish contextual relates_to, verification targets, and supersession. Include the target's state-relevant current verification heads where a full explanatory response is promised; otherwise deny under the existing whole-response cap. Do not silently label a partial view as a complete proof.

#### Alternatives and trade-offs

Rejecting descendant selectors is simpler but loses useful filtering and changes the interface. Query-relative state requires new provenance/context labels and enlarges the failure surface. Canonical bound state best preserves correctness, authority, provenance, concurrency, recovery and file-core compatibility. It needs less runtime computation, keeps OpenClaw non-authoritative, and requires modest reader/test changes. Its security assumption is explicit: the immutable bound, not a voluntary selector, defines access authority. Bounded explanatory responses can be unavailable rather than misleading.

#### Required contract changes

- Replace §8.2's effective-graph reduction and case 18 with canonical-state invariance.
- State and inclusion use the same qualified full-bound reduction.
- Freeze unresolved's exact predicate and deterministic ordering before limit/byte truncation.
- State fields in related are copied from qualified rows, never recomputed from a truncated display graph.
- Freeze which typed edges provide related context and verification explanation.
- Keep physical audience isolation, final row checks, response bounds and whole-neighborhood denial.

Owner: strict state module, reader and tool serialization. No live data migration; rederive fixture state/expected results.

#### Validation

For every check-result subset, every allowable domain narrowing, and all three tools, assert identical state for any returned assertion. Test hidden fail, hidden inconclusive, conflicting heads with pass, verifications connected only by target_assertion_id, and checks outside display depth. Change out-of-bound records and prove no effect. A local-reduction mutation must reproduce the false-pass witness.

#### Residual uncertainty

This preserves semantics but does not establish that check results are factually reliable. Qualification of verification producers, stale measurements and real website-specific success criteria remain separate evidence questions.

### F3 — Provenance commitment verification is overstated as source/view verification

#### Finding

**Proven implementation/specification mismatch; high consequence; category 3 for BUILD.** A:685–734 says the existing verifier verifies root locators/raw/input-view hashes and parent input-view links. Its context schema carries envelopes, commitments and channel/policy inventories, but no source/view byte witnesses.

P:251–302 checks hash syntax. P:1039–1068 checks parent commitment and recursive ancestry, but never compares exact_input_view_sha256 to a supplied consumed view. P:1109–1127 checks the channel tuple for a root's assurance; it does not read or recompute raw source/view bytes.

The pure probe supplied a trusted synthetic channel and unbacked raw/view hashes; verification returned trusted. The same happened for a child with an unmatched input-view hash. This does **not** prove an untrusted caller can modify the operator inventory. It proves that the cited primitive establishes a narrower property than the strict plan promises.

The strict output_sha256 check is useful: it binds the chosen provenance envelope to the exact source-record payload. It does not establish the truth of that envelope's root/view assertions.

#### Root cause

Integrity of an admitted statement about provenance is confused with independent grounding of that statement. A content hash proves equality only when there are authoritative bytes or a properly scoped capture attestation against which to compare it.

#### Candidate remedy

Preserve existing envelopes byte-for-byte. Add a strict qualification layer that validates immutable source/view witnesses before assigning the stronger strict assurance label.

#### Remedy attack

Adding bytes whose hashes match is still not proof that the transformer consumed them. A model can create a self-consistent but fictional lineage. A new signing string is not capture authority. Fetching live paths during validation would break snapshot isolation, add TOCTOU/network exposure and make recovery non-repeatable.

Merely relabeling trusted as verified would retain the problem. Rewriting old envelopes to add missing evidence would violate provenance continuity.

#### Surviving solution

Qualify two separate properties: existing commitment/ancestry verification, and grounding in a reviewed immutable capture inventory. Keep that inventory a supporting evidence artifact of the same source snapshot, not a new decision authority.

For fixtures, exact captured source and input-view bytes are embedded in or content-addressed beneath the immutable fixture authority root. A capture entry binds the source identity, locator, event, raw bytes, selected view, relevant parent commitment and the approved deterministic selection recipe or operator-controlled capture receipt. The strict qualifier recomputes hashes and verifies that the entry refers to this assertion/edge and registration.

A claimed lineage without that grounding never receives the stronger “verified” mapping. Missing grounding degrades to untrusted; an explicit mismatch fails the generation. LLM transformations remain capped at agent even with fully grounded inputs. No statement becomes factually true merely because its origin was verified.

This is a credible bounded fixture candidate. For production, if no independently trusted capture receipt or reproducible view derivation exists, **no sufficiently safe bounded solution for the stronger consumed-input claim was established**. Preserve the claim as unverified instead of inventing authority.

#### Alternatives and trade-offs

Trusting the existing inventory as an attestation is simplest and operationally cheap, but must explicitly promise attested lineage rather than byte-verified consumption; it does not satisfy the current stronger claim. Modifying the legacy provenance module would expand protected scope and migration risk. A strict wrapper over immutable evidence preserves the file/CLI core, old commitments and OpenClaw's read-only boundary. It adds moderate schema/fixture work and storage, but avoids live reads and makes concurrency/recovery deterministic. Its security depends on capture ownership; it cannot solve forged input history by self-hashing alone.

#### Required contract changes

- Version the strict provenance context to add a closed grounding inventory, with explicit binding to source registration/event/assertion or parent-child edge.
- Specify immutable byte payloads, their hashes, selection/capture receipt identity and accepted grounding method; reject unknown methods.
- Require exact identity/commitment/hash correspondence and complete ancestry for the stronger assurance.
- Change the origin_assurance mapping to require both existing verification and grounding qualification; retain conservative transformer caps.
- Preserve old envelopes and UUIDs; no reminting or normalization.
- Bound grounding bytes within a reviewed total fixture budget; never dereference arbitrary locators or URLs.
- Make “origin verified” explicitly distinct from “claim correct” and “decision approved.”

Owner: strict evidence-state qualification and publisher/cold validator. The protected legacy provenance API need not change. The exact new schema and fixture vectors require another architecture revision before Cursor begins.

#### Validation

Swap roots, locators, registrations, event keys and parent/view links while preserving syntactically valid digests. Tamper witness bytes, omit receipts, reuse a receipt for another assertion, and create a fake same-text lineage. All must deny or degrade as specified. Test genuine grounded synthetic roots, LLM caps and exact replay. A negative control that skips grounding must reproduce the probe's unsupported assurance.

#### Residual uncertainty

Production capture authenticity and evidence retention are unresolved. The current diagnostic establishes a capability limit, not fraudulent historical records in the live corpus. No live provenance audit was performed.

### F4 — Lifecycle and revocation guarantees lack a complete executable control contract

#### Finding

**Proven specification incompleteness plus a proven primitive limit; category 3 for BUILD and blocker to runtime testing.** The supervisor must handle each local turn, yet its only start interface has no turn input, and its only defined control-socket operations are status and revoke (A:1206–1243). There is no specified turn submission/cancellation protocol, cross-turn concurrency rule, release linearization, revocation receipt schema, or stable profile-lock identity across changing owner digests.

The owner digest changes with scope/registry bytes (A:929–935). A scope correction therefore cannot be serialized by owner locks alone. The named “sole exclusive profile-activation lock” needs a stable profile slot independent of those changing values.

The process-group guarantee is also too strong for the cited mechanism. Parent-death SIGKILL is process-directed and its setting is cleared across fork. The disposable probe killed the direct child while the same-group descendant survived. [Linux parent-death-signal specification](https://man7.org/linux/man-pages/man2/PR_SET_PDEATHSIG.2const.html). A dead supervisor cannot subsequently issue its group kill.

Clock choice is not fixed. Linux CLOCK_MONOTONIC excludes suspend time; CLOCK_BOOTTIME includes it. Wall-clock rollback combined with suspend can defeat an implementation that chooses the former without further detection. [Linux clock semantics](https://man7.org/linux/man-pages/man3/clock_gettime.3.html).

#### Root cause

Lifecycle requirements are described as outcomes without specifying the complete control plane and an independently surviving enforcement owner. Locks, process groups and deadlines are not interchangeable guarantees.

#### Candidate remedy

Freeze one operator-only turn/control protocol, one stable profile slot, and a lifecycle state machine. Use a trusted outer process manager/containment primitive for descendant cleanup, rather than requiring the dying supervisor to clean up itself.

#### Remedy attack

A watchdog owned by the same dying process has the same failure. Applying parent-death signals only to currently known direct children does not cover forks, native helpers, detach/reparent races or future runtime changes. Process-group enumeration races with forks and PID reuse. A cgroup alone is not self-killing when its supervisor dies: something outside the failure domain must trigger cleanup.

“Check expiry, then write stdout” also has a check/release race and backpressure. It cannot literally guarantee that no already-authorized byte is observed after a later expiry. The design must define an authorization linearization point rather than promise retroactive control over delivered bytes.

#### Surviving solution

A credible candidate is an **operator-owned stable profile slot plus an outer managed process unit**, containing the supervisor, gateway, agent and connector descendants. Its manager outlives the supervisor, disables restart, kills the entire unit on supervisor failure, and attests emptiness before a new activation can occupy the slot. Linux cgroup v2 supports whole-descendant termination, including fork races; that primitive does not by itself supply the manager policy. [Kernel cgroup contract](https://docs.kernel.org/admin-guide/cgroup-v2.html).

The inner supervisor still owns turn serialization, snapshot checks and output authorization. Define states NEW → ACTIVE → REVOKING → SEALED; no reverse transition. Define a closed local request protocol for turn, cancel, status and revoke, authenticated by the operator-only socket boundary. One active turn per activation avoids concurrent mutation of a shared model session.

Revoke and response-release commit serialize through that owner. If revoke/lease loss wins, no response is committed. If a complete result's release commit wins while the lease is valid, it was authorized then; later client observation is not retroactive authorization. A client renders only a committed complete response, not partial buffered bytes. This clarification must be explicitly reviewed; it is not silently substituted for the current literal “no byte after lease loss” claim.

Use CLOCK_BOOTTIME for elapsed lease expiry, plus wall-clock expiry and explicit backwards-clock detection; validate as_of/built_at against activation time and seal on inconsistent clock history.

**No fully established bounded solution exists within the packet's present allowed mechanisms.** The outer manager, containment permissions, stable slot path, exact protocol and release semantics must be selected and reviewed. Do not hide those choices in Cursor's implementation or postpone their architecture to Gate D.

#### Alternatives and trade-offs

EOF and process groups are low-cost but weaker under crash/fork. Per-process wrappers reduce cost but add hidden coupling to every runtime spawn. A manager-owned containment unit is stronger for correctness, concurrency, recovery and security, while preserving authority outside OpenClaw and preserving file/CLI data ownership. It adds platform/operational prerequisites and a new trusted enforcement component. A short-lived one-turn runtime reduces session complexity but still needs cleanup. The choice is justified by the required guarantee, not novelty; if the guarantee can be explicitly reduced, that is a separate reviewed decision.

#### Required contract changes

- Add a stable operator profile-slot identity/path independent of scope, registry, snapshot and activation IDs.
- Bind slot ownership, manager/unit identity and reviewed containment policy into activation identity.
- Freeze turn/cancel/status/revoke request/response fields, bounds, terminal states, one-turn concurrency, disconnect behavior and idempotence. Request IDs correlate actions; they do not confer authority.
- Define a closed revocation receipt binding slot, activation, pointer identity, terminal reason and verified descendant emptiness.
- Specify exact lock order across slot and owner publication locks; pointer updates require a valid receipt and exclusive owner lock.
- Freeze BOOTTIME and clock-anomaly behavior, startup parent-death race handling, and fail-closed recovery after supervisor death.
- Define complete-response release and revocation ordering; never accept raw arbitrary agent JSON as proof of successful authorized tool work.
- Add the reviewed manager integration/configuration to scope explicitly, or keep runtime implementation blocked. Fake-process tests must exercise the same interface.

#### Validation

Kill supervisor before/after spawning, fork a descendant, detach a child, race revocation with result completion, block the output consumer, cancel queued turns, change scope so owner_digest changes, restart after an incomplete seal, and simulate suspend plus wall-clock rollback. Assert no new activation until old descendants are gone. Repeat with installed OpenClaw only under Gate D authorization. Current probe is a negative witness, not validation of this candidate.

#### Residual uncertainty

Manager availability, privileges, actual runtime descendants, output format, endpoint selection and manager failure behavior are unknown. A mere cgroup name or test mock cannot establish actual containment.

### F5 — Fresh activation does not close all ambient input and persistence paths

#### Finding

**Strongly supported design gap; category 3 for BUILD.** The connector pins its cwd, but the supervisor's gateway/agent launch contract pins environment and argv without fixing cwd (A:1180–1215). Bundled OC:2584–2602 explicitly loads CWD .env; an empty HOME and freshly constructed environment do not prevent that later load.

Concrete scenario: the operator starts the supervisor from a checkout containing .env. Gateway/agent inherit that cwd. OpenClaw loads missing variables from it despite the initial environment allowlist. Provider or other ambient configuration can enter through a path the contract does not pin. No live .env was opened to test this.

OC:2717–2729 also describes a shared default log file under /tmp/openclaw, outside fresh state. Thus fresh state alone is not an inventory of persistence or audit exposure.

Finally, a launcher/binary hash and version do not cover the imported implementation. The supplied package names openclaw.mjs as its entry and dist/index.js as its main module; the activation has no digest for the full OpenClaw/dependency closure. Similarly, a Python executable plus requirements text does not establish the actual installed dependency bytes. Evidence: bundled package.json:19–40; A:1141–1169.

#### Root cause

The design freezes selected launch arguments and configuration but not the complete set of runtime inputs and writable sinks. Empty environment is a starting condition, not a property of subsequent loader behavior.

#### Candidate remedy

Make activation a closed launch over an immutable runtime artifact, fixed empty cwd, exact config, explicit local endpoint, private persistence roots and enforceable egress policy.

#### Remedy attack

Setting cwd without disabling/removing ambient .env/skills/bootstrap inputs leaves later file races. Hashing only package metadata misses imported code changes. Recursively hashing the whole host is neither necessary nor a manageable trust model. A config-only egress promise does not constrain a misconfigured client or library.

A single content digest also does not authenticate the operator; filesystem ownership and reviewed promotion remain the trust root.

#### Surviving solution

Pin one immutable runtime distribution and its actual imported dependency closure at a reviewed root, plus the relevant interpreter/Node runtime identity. The operating system and explicitly named native runtime components remain stated TCB assumptions.

Both gateway and agent run from a fixed empty activation directory, with no source checkout mounted as cwd. Set and validate env.shellEnv=false, disallow inline env additions, and ensure every documented .env discovery location is absent or fixed under that empty root. Logs, sessions, caches and temporary files have explicit activation-local paths, permissions and retention.

The exact local model endpoint, gateway port and absence of alternate/fallback endpoints are validated inputs to the same activation. Network deny/allow policy needs a named enforcement owner outside the model, not an environment convention. Gateway and client endpoint configuration must agree.

This closes the original cwd route by construction and makes a changed imported runtime artifact invalidate activation. It does not claim prompt injection or a compromised trusted OS is solved.

#### Alternatives and trade-offs

More prompt/config advice is simplest but fails the boundary. A full bespoke container platform adds unnecessary operational complexity unless needed for enforcement. A sealed runtime plus fixed directories and an existing reviewed OS containment policy is the smallest credible candidate. It preserves authority, provenance, file/CLI compatibility and the OpenClaw boundary; costs include artifact storage, release packaging and startup verification. Concurrency/recovery improve through per-activation state. Security depends on immutable mounts/ownership and actual egress enforcement; implementation complexity is moderate, with deployment prerequisites still unresolved.

#### Required contract changes

- Bind gateway/agent cwd, runtime-distribution digest, dependency closure and private log/temp roots in the activation contract or in a fully hashed launch-policy artifact.
- Freeze exact cwd and env-loader disabling behavior; no inherited working directory.
- Pin actual runtime artifacts, not only version strings, launcher bytes or requirements text; qualify loaders and import paths before untrusted data.
- Make gateway.port match the activation's chosen port for the client as well as the gateway; reject remote fallback configuration.
- Name the egress-policy owner and exact endpoint permissions. Strict child/connector have no network permission.
- Enumerate all persistent sinks and prove they remain in the activation root or explicitly reviewed audit storage.
- Extend exact-config tests and Gate D probes; changing these inputs requires a new activation.

#### Validation

Start the launcher from a poisoned disposable cwd containing .env, bootstrap files, skills and unrelated config; verify none is consumed. Change an imported dependency while holding launcher/version constant and require rejection. Observe actual file/network access, logs and endpoints in the later isolated runtime. Test attempted same-ID plugin substitution, readonly files, restarts and stale state. Fake environment assertions alone do not pass Gate D.

#### Residual uncertainty

Installed OpenClaw source/loader closure and effective config were not included. No real credential leakage or unexpected network call was observed. Exact OS egress/packaging choices require review.

### F6 — The stipulated approved-ingestion invariant is not the implemented default

#### Finding

**Proven baseline/requirement contradiction; live-integration blocker, not by itself a reason to forbid a hermetic reader.** The review requires approved proposals to use the authorized “convmem add --file” path and prohibits automatic ingestion. The target's default approval path instead confirms, approves and indexes in one command.

CLI:1328–1354 branches to approve_and_ingest unless no_index; Q:734–755 then calls ingest_approved_ledger directly. CLI:1135–1138 advertises add --file only as the skipped-index alternative. This is ingestion following an explicit approval command, not autonomous approval. That distinction matters, but it does not make the literal stated route true.

#### Root cause

The review invariant, legacy operating protocol and proposed strict approval artifacts have not been reconciled into one authoritative approved-write contract.

#### Candidate remedy

Keep strict fixtures entirely separate. Before live integration, route approved decision admission through one explicit file/CLI contract that validates the exact approved artifact and preserves existing recovery semantics.

#### Remedy attack

Simply changing help text does not remove the second route. Using no-index followed by a generic add is not sufficient proof: generic ingestion must not treat caller-controlled status or signer fields as approval. Moving approval into OpenClaw would violate the boundary. Removing existing recovery logic would trade a route mismatch for lost or duplicated writes.

#### Surviving solution

**No sufficiently safe bounded solution was established within this fixture plan.** A separate approved-write architecture must either implement the invariant through a shared guarded file admission boundary or obtain an explicit owner decision changing the invariant. This review does not choose the latter or silently weaken the user's constraint.

The preferred direction, if the invariant remains, is an explicit operator-run add path consuming an already approved artifact bound to proposal identity, semantic content hash, scope, authority and expected prior state; all callers use the same governed recovery mechanism. This is a candidate for a separate review, not an instruction to edit the protected CLI/proposal modules.

#### Alternatives and trade-offs

An explicit two-step CLI can preserve human authority and file-core compatibility but adds owner effort and a crash interval requiring recovery. A confirmed combined command is simpler operationally but contradicts the exact current requirement unless Ryan explicitly revises it. OpenClaw admission is unacceptable for security/authority. A shared governed admission module reduces duplicate failure surfaces but changes protected code, migration and test scope. None should be slipped into the reader build.

#### Required contract changes

Freeze the allowed approval-to-index route, actor authorization, exact artifact binding, completion/recovery states and prohibition on forged proposal/status fields. Assign it a separate scope and migration review. Pending proposals remain outside durable retrieval throughout.

#### Validation

Exact approved artifact succeeds through the sole authorized route; pending/changed/rejected/forged artifacts fail; crash between approval and projection resumes without duplicate approval or silently losing intent. Negative controls must show that copied signer/status strings are insufficient.

#### Residual uncertainty

No live command was run. The discrepancy is established from source, not from a newly observed unauthorized write. The strict fixture reader remains read-only if its boundary is implemented correctly.

## 7. Closed-loop memory contamination

The initial strict runtime can consume evidence and produce text, but it has no specified automatic path from that text back into durable memory. That cuts the automatic Observation → interpretation → write → retrieval loop at the write boundary. It is a real architectural advantage if runtime inventory and capture-negative tests confirm it.

Three loops remain possible outside that boundary:

1. Ryan or another lane copies a model summary into an approved record without the original caveats.
2. A later production materializer treats repeated transcript-derived claims as independent evidence.
3. A stale/rolled-back snapshot makes a revoked direction appear current again without redistillation.

F1 blocks the third; F3 constrains the second; the first requires explicit approval artifacts preserving derivation and source references. Repetition, multiple model names, high source confidence or identical prose must never upgrade integrity or approval. Shared roots must not be counted as independent corroboration. An approval records a decision, not retroactive proof that every supporting assertion was true.

The current lexical kernel can still rank repetitive authorized content highly and an orchestrating model can overgeneralize. The untrusted envelope and removed tools contain action consequences; they do not guarantee accurate synthesis. That belongs in the value and hostile-evidence experiments.

## 8. Baseline-versus-ConvMem value analysis

No supplied result establishes the central causal claim. The baseline unit tests establish neither retrieval usefulness nor better web-development work. The strict kernel deliberately trades semantic recall for deterministic isolation, so performance of the existing vector/ask pipeline cannot be transferred to this reader.

Nothing in Stage 1 demonstrates that OpenClaw adds value over an ordinary agent using the same files, GitHub snapshot and handoff. Nothing demonstrates that a fresh OpenClaw agent with the strict reader outperforms the same runtime without it. Value is **unproven, not disproven**.

### Smallest decisive experiment

First run an eight-run falsification pilot: two representative tasks, ConvMem off/on, two fresh counterbalanced repetitions. Use the same frozen local model/runtime/tier, prompt, permissions, ordinary files and budgets. This pilot can expose a bad mechanism or missing information channel; a positive pilot is still insufficient for broad value claims.

Then use the plan's **eight tasks × two repetitions × two arms = 32 runs** ecological screen. Do not build four systems. Add ordinary-runtime A/C arms only if OpenClaw's separate incremental contribution is actually claimed.

Task set should cover:

1. Current owner preference versus an explicitly superseded preference.
2. A rejected visual/content direction and the reason it was rejected.
3. Client-specific services/about-page content with lineage, concrete qualifications and meaningful fit.
4. A technical constraint affecting a bounded implementation plan or patch artifact.
5. Contradictory verification and an unresolved security/accessibility question.
6. Multi-record synthesis with explicit source/provenance requests.
7. Vague/paraphrased retrieval where lexical failure can matter.
8. Recovery by a successor that receives no predecessor transcript.

At least one output must be a real bounded plan or patch/content artifact that an independent evaluator can assess. The read-only OpenClaw profile need not gain execution tools: an external, separately authorized fixture harness can apply/render an output artifact in a disposable site copy. That harness is evaluation machinery, not an OpenClaw authority expansion.

### Controls and scoring

Freeze all information channels: supplied handoff, GitHub snapshot, files, prompts, AGENTS/TOOLS/skills, environment, network, shell history, logs, native memory, caches and session state. Seed Agent A with realistic preferences, decisions, rejections, constraints and unresolved issues; successor B gets no A transcript.

The isolation condition uses deliberate canaries to detect leakage. The ecological condition keeps ordinary project artifacts realistic and identical between arms; do not cripple the baseline by withholding a handoff that the real workflow normally supplies. A treatment-only extra facts advantage must be reported separately from better retrieval of equally available facts.

A concrete candidate rubric, to preregister before any outcome is seen:

- Safety/authority violations are disqualifying, not averaged away.
- Current-state accuracy and honoring current decisions: 25%.
- Useful plan/patch correctness and verification: 25%.
- Website substance, specificity, credibility, lineage and fit: 20%.
- Accessibility/performance/security/SEO-schema: 15%.
- Provenance, contradictions and uncertainty handling: 15%.

Blind graders receive anonymized artifacts and a frozen gold evidence set. Record time, tokens, tool calls, rework, clarification exchanges, human intervention and owner minutes separately. Proposed practical-effect screen: at least a 10-point improvement on the 100-point quality rubric, no safety regression, and at least 20% lower median total owner minutes. These are proposed thresholds for owner review, not pre-existing project facts. Report paired outcomes and uncertainty; two repetitions are a screen, not a population estimate.

A run failure counts as a result unless a predeclared infrastructure exclusion applies equally to both arms. Stop immediately on cross-audience disclosure, unauthorized state change or deployment. Do not rerun selectively until a favorable answer appears.

## 9. Human context-transfer analysis

The design could reduce repeated explanation by making decisions and unresolved evidence retrievable across fresh sessions. It does not yet eliminate Ryan as the person who:

- decides what is approved;
- supplies authentic source registrations and resolves mixed-audience material;
- approves/rebuilds a new snapshot;
- stops/restarts sessions after corrections;
- moves useful outcomes into an authorized execution lane;
- checks provenance and recovers failed state.

Measure **total owner minutes = briefing + copying + clarification + curation + approval + registration + rebuild + session hygiene + recovery + correction**. Also measure context copied between agents and interventions needed to restore continuity. Separate one-time setup from ongoing work, but amortize setup explicitly rather than hiding it.

The present evidence cannot answer whether the system removes this work or relocates it into ConvMem maintenance. Its strong manual publication and session-reset requirements make this uncertainty load-bearing for product value, though not an excuse to weaken authority.

## 10. Security and authority assessment

The narrow read-only profile has sensible containment goals: no shell/browser/filesystem/session/write tools; no native memory; fixed child launch; scoped physical candidates; hostile retrieved text treated as data; no external channels or hosted inference. These reduce blast radius and are preferable to prompt-only permissions.

However:

- The model can still produce a wrong recommendation or false natural-language completion claim. Valid JSON and completed transport do not prove factual or task completion.
- OS file ownership is the chosen approval root. A same-UID compromised trusted process is not magically isolated by mode 0400/0600 alone. The precise OS threat boundary must be explicit.
- F4/F5 leave process, ambient credential and persistence enforcement incomplete.
- Private citation references aid operator audit but are not themselves evidence and must not be accepted as authority.
- Truncated documents retain a marker, but omitted qualifiers can still mislead the model. The value/security tests must include qualifiers beyond the cut point.
- No runtime sender/perimeter claim can be made before the later channel design.
- Revocation cannot make a human or model forget text already legitimately disclosed. It controls future authorization and session reuse.

No actual cross-project disclosure, credential exposure, malicious plugin execution or production compromise was observed during this review.

## 11. Readiness gates and issue classification

### BUILD GATE — blocked

Evidence: the exact source has no strict implementation; F1–F5 require decisions about schema, authority, state, lifecycle or isolation. E:450–472's claim that categories 3 and 4 are empty is not supported.

Required before proceeding: a revised consolidated architecture incorporating or rejecting each candidate explicitly, frozen schemas/transition semantics, lifecycle/launch policy and updated acceptance cases. Another independent review must find no category-3 or fixture-safety category-4 item. Kiro then signs the exact revision; Ryan alone grants Execute.

Rollback for a later build remains disposal of an isolated implementation workspace or reviewed revert. It cannot be used to claim live-data rollback safety.

### TEST GATE — proceed, narrowly

Safe offline pure-module tests, disposable fixtures, reference calculations and fake-child tests are technically appropriate. This review already performed only the bounded tests listed in §1.

This does not pass the installed-runtime smoke, authorize a live-derived shadow snapshot, or authorize staging/external systems. Tests of F4 must contain/reap their own synthetic descendants. Any test capable of importing live config, provider endpoints or writer paths needs an independently enforced denial boundary.

Required evidence: literal commands, exact inputs, actual skips/failures, negative controls and filesystem/network isolation. No provider/model spending is authorized here.

### LIVE-DATA GATE — blocked

Required: safe approved source snapshot, binding completeness and mixed-source adjudication, F1/F3 authority/provenance continuity, F6 route reconciliation, separately approved migration, backup and rollback preserving the latest authority watermark. Read-only access still discloses data and needs the exact Ryan grant. Kiro and independent verification remain required.

### PROMOTION GATE — blocked

Required: all prior safety gates, actual installed runtime/perimeter proof, positive preregistered value evidence, website-specific verification, exact external-change authorization and operational rollback. No channel/production/hosted-model deployment is in this build slice. Website rollback and data rollback must be specified separately.

### Remaining issues by category

1. **Implementation details:** private helper names, internal data structures and test-file organization after the external contracts are frozen.
2. **Non-blocking uncertainties for a fixed disposable experiment only:** real-world recall, observed latency within defined fixture bounds, local-model quality and measured product value. They block benefits/promotional claims. If resolving one requires changed interfaces or authority, it moves to category 3.
3. **Architecture decisions still required:** F1–F5; exact authoritative reducer scope; cumulative admission/rollback/CAS; grounding schema and assurance semantics; stable activation slot and turn protocol; actual containment owner; release semantics and clocks; closed launch/runtime/persistence policy.
4. **Safety/integrity blockers for later runtime/live use:** unproven OS/network containment, unavailable actual runtime inventories, no approved live migration/snapshot and no promotion authorization; F6's unreconciled write invariant. There is no need to pretend that writing inert fixture tests itself touches production.

Categories 3 and 4 are therefore **not empty**. No implementation contract is issued.

## 12. Remedy-falsification result

F1 survives as a candidate only with cumulative admission, non-regressing authority watermark, one atomic publication state and epoch-bound CAS. A retained old snapshot alone is rejected.

F2 survives as a candidate only when all returned state remains a property of the full authorized snapshot, not a query or display subset. It explicitly changes the existing case-18 expectation.

F3 survives for bounded fixtures only with independently grounded immutable witnesses and conservative degradation. Production consumed-input authenticity remains a blocker where no trustworthy capture evidence exists.

F4 has credible candidate mechanisms, but **no complete safe bounded solution is established under the present packet**. Selecting and freezing the outer containment/control contract is still architectural work.

F5 survives as a candidate with a closed launch/runtime artifact and explicit private sinks/egress owner. It is not established by empty HOME or an initial environment assertion.

F6 has **no in-scope fixture remedy**. A separate approved-ingestion contract is required; the invariant must not be silently weakened.

None of these results authorizes implementation, and none demonstrates the combined system's value.

## 13. Comparison with Claude/Opus, Sol, and prior reviews

**Deferred by protocol.** No Stage 2 review, response, corrective diff or prior-review canvas was read. The current plans necessarily disclosed that earlier issues existed and were said to be corrected; those assertions were not used as evidence of correctness.

After Message 2, classify every significant prior issue against this sealed report as independently found, genuinely resolved, still unresolved, false alarm, newly introduced by a fix, or not decidable. Any new Stage 2 conclusion must be an explicit addendum; do not rewrite this Stage 1 artifact to appear more independent.

## 14. Implementation-contract disposition and later conformance checklist

No BUILD PASS means **no bounded implementation contract is issued**. The next authorized architectural synthesizer can use the exact changes/tests above without rediscovering the failure mechanisms. Cursor/Grok must not convert these candidates directly into code.

There is no post-implementation integration artifact to audit. The later independent verifier must:

- reconstruct the exact submitted implementation from scratch;
- compare changed files/dependencies to the signed scope and baseline;
- verify authority/lineage conservation, disposition admission and ABA-safe CAS;
- prove cross-selector/cross-tool canonical state and typed-edge behavior;
- test grounding, payload binding, replay and provenance degradation;
- enumerate imports, writers, resources, tools and actual runtime prompt sources;
- prove cwd, env, dependencies, endpoint and persistence closure;
- test process-tree cleanup, stable slot ownership, clocks, release/revoke races and crash recovery;
- run every assigned acceptance case with an enforcement-removal negative control;
- repeat actual-runtime cases under a separate grant, without counting mocks as runtime proof;
- verify no code silently migrates live IDs, changes legacy behavior or adds capture/execution;
- report exact versions/digests, failures, skips, bounds and residual uncertainties.

## 15. Required experiments and acceptance evidence

Priority order:

1. **Specification reconciliation:** finite state examples for F1/F2 and a fully specified lifecycle/grounding contract. This is architecture work, not a model benchmark.
2. **Pure fixture tests:** independent reference reduction, canonical vectors, schema rejection, input/proof substitution and deterministic bounds.
3. **Publication fault matrix:** every authority/projection/pointer persistence boundary, stale CAS, rollback, lineage omission and restart.
4. **Fake-runtime containment matrix:** exact turn/control protocol, slot migration, descendant forks, backpressure, cancellation, clocks and cleanup.
5. **Installed-runtime evidence:** only after separate authorization; exact config validation, three-tool inventory, zero extra prompt/skill/hook/memory/capture surface, runtime artifact identity, local endpoint/egress and private persistence.
6. **Value trials:** isolation leakage pilot followed by the matched ecological screen; count net owner effort and assess real web artifacts.
7. **Live migration design:** separately approved source snapshot, binding/provenance completeness, writer census, sanctioned admission path and authority-preserving recovery.

No result from an earlier numbered item substitutes for a later one.

## 16. Residual unknowns and final Stage 1 answer

Unknowns include actual OpenClaw behavior under the final effective configuration; complete imported runtime identity; the local model's competence; real source registration/binding coverage; production capture authenticity; safe history retention/pruning; measured latency/recall; website quality/substance; net owner savings; and live migration/rollback. Their resolving evidence is identified above. No absence of a discovered flaw is counted as safety evidence.

The combined architecture has a useful minimal idea: a file/CLI-first evidence core exposed through a narrow, read-only runtime adapter. The supplied target does not yet make that idea implementation-complete. Its consequential remaining flaws are authority rollback/continuity, query-relative state, overclaimed provenance verification, and incomplete lifecycle/activation closure. The invariant mismatch in the legacy approval path additionally prevents an integrated compliance claim.

The most fundamental decisions to reconsider are **whether current authority can move backward with a serving pointer**, **whether a query subset may redefine state**, **what “verified provenance” actually proves**, and **which owner enforces process/session revocation after supervisor failure**. None requires replacing the entire evidence core. Some cannot be fixed safely by a local implementation choice.

There is no demonstrated incremental value over ordinary context, files, handoffs and GitHub for real web development, and no demonstrated reduction in Ryan's total context-transfer work. Controlled evidence may establish that value later; retrieval/API success cannot.

It is safe to continue the specifically isolated diagnostic/fixture work described here. It is not appropriate to hand this packet to Grok as architecture-complete, start the installed runtime under assumed guarantees, read/write live corpus data, or promote it to external/production use. Revised contracts, adversarial implementation evidence, actual runtime qualification and matched product-value trials are still required.

**Stage 1 stops here. Message 2 is required before any history challenge.**

I finished: [Arc none] Stage 1 reconstruction, attack, candidate remedies and initial readiness assessment.  
Next step: Ryan supplies Message 2; challenge prior history against this sealed Stage 1.  
Next lane: Ryan, then Codex Astra.  
See my work: this report and its accompanying SHA-256 seal.

**TL;DR:** [Arc none] BUILD is blocked by unresolved authority, state, provenance and lifecycle decisions. Isolated fixture testing remains appropriate; live use and promotion remain blocked. Product value is unproven. Stage 2 has not been read.
