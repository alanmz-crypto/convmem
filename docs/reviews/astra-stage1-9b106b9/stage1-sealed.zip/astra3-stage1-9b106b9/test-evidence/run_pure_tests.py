
import sys, os, pathlib, json
base=pathlib.Path('/tmp/astra3-stage1-9b106b9')
sys.path.insert(0,str(base/'stage1/repo'))
forbidden=[]
def audit(event,args):
    if event.startswith(('socket.connect','socket.bind','socket.getaddrinfo','subprocess.Popen','os.system')):
        forbidden.append(event); raise RuntimeError('review isolation denied '+event)
    if event=='open' and isinstance(args[0],(str,bytes)):
        p=os.path.abspath(os.fsdecode(args[0]))
        banned=('/home/lauer/.config/','/home/lauer/.local/','/home/lauer/.codex/','/home/lauer/Projects/convmem/')
        if p.startswith(banned):
            forbidden.append(p); raise RuntimeError('live path denied')
sys.addaudithook(audit)
import pytest
print('Python:',sys.version)
print('Pytest:',pytest.__version__)
print('Isolation: empty HOME; disabled plugin autoload; no conftest; no cacheprovider; network/subprocess/live-path audit guards')
result=pytest.main(['-q','--noconftest','-p','no:cacheprovider','-c','/dev/null','--rootdir='+str(base/'stage1/repo'),str(base/'stage1/repo/tests/test_provenance.py'),str(base/'stage1/repo/tests/test_site_filter.py')])
print('Denied operations:',json.dumps(forbidden))
raise SystemExit(result)
