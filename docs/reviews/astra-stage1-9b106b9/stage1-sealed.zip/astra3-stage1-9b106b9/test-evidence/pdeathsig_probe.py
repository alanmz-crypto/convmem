
import ctypes,os,signal,time,json,select
libc=ctypes.CDLL(None,use_errno=True)
assert libc.prctl(36,1,0,0,0)==0  # caller subreaps only its disposable descendants
r,w=os.pipe();sup=os.fork()
if sup==0:
    os.close(r);os.setsid()
    gateway=os.fork()
    if gateway==0:
        assert libc.prctl(1,signal.SIGKILL,0,0,0)==0
        grandchild=os.fork()
        if grandchild==0:
            setting=ctypes.c_int()
            assert libc.prctl(2,ctypes.byref(setting),0,0,0)==0
            os.write(w,(json.dumps({'role':'grandchild','pid':os.getpid(),'pgid':os.getpgrp(),'pdeathsig':setting.value})+'\n').encode())
            time.sleep(0.5)
            os.write(w,b'{"grandchild_survived_supervisor_death":true}\n')
            time.sleep(3);os._exit(0)
        os.write(w,(json.dumps({'role':'gateway','pid':os.getpid(),'pgid':os.getpgrp()})+'\n').encode())
        time.sleep(5);os._exit(0)
    time.sleep(5);os._exit(0)
os.close(w);raw=b'';items=[];gateway=None;grandchild=None
try:
    deadline=time.monotonic()+2
    while len(items)<2 and time.monotonic()<deadline:
        ready,_,_=select.select([r],[],[],0.2)
        if ready:
            raw+=os.read(r,4096)
            while b'\n' in raw:
                line,raw=raw.split(b'\n',1);items.append(json.loads(line))
    assert len(items)==2,items
    gateway=next(x['pid'] for x in items if x['role']=='gateway')
    grandchild=next(x['pid'] for x in items if x['role']=='grandchild')
    os.kill(sup,signal.SIGKILL);os.waitpid(sup,0)
    deadline=time.monotonic()+2
    while not any(x.get('grandchild_survived_supervisor_death') for x in items) and time.monotonic()<deadline:
        ready,_,_=select.select([r],[],[],0.2)
        if ready:
            raw+=os.read(r,4096)
            while b'\n' in raw:
                line,raw=raw.split(b'\n',1);items.append(json.loads(line))
    gw_pid,gw_status=os.waitpid(gateway,os.WNOHANG)
    result={'probe':'Linux primitive only; no OpenClaw process started','observations':items,'gateway_killed_by_pdeathsig':gw_pid==gateway and os.WIFSIGNALED(gw_status) and os.WTERMSIG(gw_status)==signal.SIGKILL,'grandchild_survived':any(x.get('grandchild_survived_supervisor_death') for x in items)}
    print(json.dumps(result,indent=2));assert result['gateway_killed_by_pdeathsig'] and result['grandchild_survived']
finally:
    try:os.killpg(sup,signal.SIGKILL)
    except ProcessLookupError:pass
    while True:
        try:os.waitpid(-1,0)
        except ChildProcessError:break
    os.close(r)
