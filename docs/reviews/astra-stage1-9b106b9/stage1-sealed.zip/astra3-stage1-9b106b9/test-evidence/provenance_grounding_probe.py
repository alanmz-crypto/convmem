
import sys,json
sys.path.insert(0,'/tmp/astra3-stage1-9b106b9/stage1/repo')
from provenance import ProvenanceRegistry,base_envelope,root_binding,input_binding,sha256_hex
r=ProvenanceRegistry(); evidence=sha256_hex('synthetic channel inventory')
r._monitor_authority.register_verified_channel(origin_class='synthetic',channel_class='fixture-auth',channel_locator='fixture://channel',channel_evidence_sha256=evidence)
root=r.mint(base_envelope(root_bindings=[root_binding(source_identity='fixture/source',record_locator='missing-record',raw_record_sha256='0'*64,input_view_sha256='1'*64,origin_class='synthetic',origin_assurance='verified',channel_class='fixture-auth',channel_locator='fixture://channel',channel_evidence_sha256=evidence)],producer_class='trusted_tool',producer_assurance='verified'))
child=r.mint(base_envelope(input_bindings=[input_binding(root,exact_input_view_sha256='2'*64)],producer_class='trusted_tool',producer_assurance='verified',transformer_class='root'))
results=[]
for label,rec in [('root with syntactically valid but unbacked raw/view hashes',root),('child with unmatched exact input-view hash',child)]:
    v=r.verify(rec.assertion_id);results.append({'case':label,'verified':v.verified,'integrity':v.effective_integrity,'reason':v.reason})
print(json.dumps({'kind':'Existing pure verifier behavior, not a strict integration exploit; caller controls trusted synthetic inventory','any_raw_or_view_bytes_supplied':False,'results':results},indent=2))
assert all(x['verified'] and x['integrity']=='trusted' for x in results)
