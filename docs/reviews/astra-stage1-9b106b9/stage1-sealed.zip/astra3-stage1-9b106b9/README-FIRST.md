# OpenClaw ↔ ConvMem final build-readiness review bundle

## Exact target

- Arc: none (ad-hoc integration)
- Authoring lane: Codex architecture/planning only
- Branch: `plan/2026-09-20-openclaw-convmem-final-readiness`
- Commit: `9b106b908b944f8bd4c3f417b576dc13884f2503`
- Parent: `2424857a2df505b262645143a35eb024ccca3586`
- Architecture SHA-256: `ea40852867480a5b7ee81a736c9c9901f2cfa419d1b93bc49c5e62e289cc5166`
- Execution-plan SHA-256: `e498395b6ffc70e6dfff1c5123d9a2c12f68105414ee9fb621ee7bdaa421b2af`
- Code baseline: `7809f20dc53d9dd19f765c3ec3214a3df54ca5bf`
- Installed OpenClaw evidence: `2026.3.2`
- Implementation, configuration, live-data, model-run, and promotion authority: none

`MANIFEST.sha256` covers every file except itself. The bundled `repo/` source is
the previously verified code baseline; only the two plans changed between the
parent and target. A local reviewer may inspect additional files with `git show
9b106b9:<path>`, but must not substitute a shared-checkout draft or later commit.

## Two-stage boundary

Use Ryan's full independent-review prompt first, then send the text in
`MESSAGE-1-STAGE-1.md`. During Stage 1, inspect only `stage1/` and the exact target
commit. Do not open `stage2/`. The current plans contain administrative references
to earlier review, so perfect blindness is impossible and must not be claimed.

After Stage 1 has been recorded and sealed and the reviewer explicitly asks for
the history packet, send `MESSAGE-2-STAGE-2.md`. Stage 2 contains the prior Astra
review, sealed evidence, revision history, and the exact corrective diff.

## Stage 1 reading order

1. `stage1/repo/docs/plans/ARCHITECTURE-openclaw-convmem-integration.md`
2. `stage1/repo/docs/plans/EXECUTION-openclaw-convmem-integration.md`
3. relevant bundled source, tests, builder references, and protocol
4. `stage1/installed-openclaw/` documentation and executable probes

The target is still a specification. No strict reader, publisher, connector, or
supervisor has been implemented. Passing tests against the existing repository
cannot prove the proposed integration.

## Decision requested

Try to falsify whether the packet is now implementation-complete for an isolated,
disposable fixture build. In particular, decide whether any category-3
architecture decision or category-4 fixture-build safety blocker remains after
the C1–C6 corrections. Separately assess product value; it remains explicitly
unproven until the later matched experiment.

Do not implement, configure, migrate, access the live corpus, run provider/model
calls, install the connector, start OpenClaw, send external messages, or treat
documentation as implementation evidence. A review PASS grants no execution
authority; Kiro and Ryan retain their stated gates.
